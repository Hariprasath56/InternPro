
<?php

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . '/config/database.php';

$error = '';
$email = '';

if (isset($_SESSION['user_id'], $_SESSION['role'])) {
    if (in_array($_SESSION['role'], ['company', 'recruiter'], true)) {
        header('Location: company/dashboard.php');
    } elseif ($_SESSION['role'] === 'student') {
        header('Location: student/dashboard.php');
    } else {
        // Unknown role: do not redirect to a protected dashboard.
        session_unset();
        session_regenerate_id(true);
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim((string) ($_POST['email'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');

    if ($email === '' || $password === '') {
        $error = 'Please fill in all fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        try {
            $stmt = $pdo->prepare(
                'SELECT id, name, email, password, role
                 FROM users
                 WHERE email = :email
                 LIMIT 1'
            );

            $stmt->execute(['email' => $email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (
                $user &&
                isset($user['password']) &&
                password_verify($password, (string) $user['password'])
            ) {
                $role = (string) ($user['role'] ?? '');

                if (!in_array($role, ['student', 'company', 'recruiter'], true)) {
                    $error = 'This account has an unsupported role. Please contact support.';
                } else {
                    session_regenerate_id(true);

                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['name'] = $user['name'];
                    $_SESSION['role'] = $role;

                    if (in_array($role, ['company', 'recruiter'], true)) {
                        header('Location: company/dashboard.php');
                    } else {
                        header('Location: student/dashboard.php');
                    }
                    exit;
                }
            } else {
                // A generic message avoids revealing whether an email exists.
                $error = 'Invalid email or password. Please try again or register.';
            }
        } catch (PDOException $e) {
            error_log('InternPro login database error: ' . $e->getMessage());
            $error = 'We could not process your login right now. Please try again later.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#071E3D">
    <meta name="description" content="Sign in to InternPro to explore internships and manage your applications.">

    <title>Login | InternPro Portal</title>

    <link rel="icon" type="image/png" href="assets/logooo.png.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700&family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        :root {
            color-scheme: dark;
            --navy: #071E3D;
            --navy-deep: #041224;
            --ocean: #0D3B66;
            --cyan: #00B4D8;
            --blue: #0096C7;
            --white: #FFFFFF;
            --muted: #B9CDDE;
            --glass: rgba(255,255,255,.055);
            --glass-border: rgba(255,255,255,.14);
            --danger: #FF9292;
            --ease: cubic-bezier(.2,.75,.25,1);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        html {
            min-height: 100%;
            scroll-behavior: smooth;
        }

        body {
            min-height: 100vh;
            min-height: 100dvh;
            position: relative;
            isolation: isolate;
            overflow-x: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 84px 20px 35px;
            color: var(--white);
            background:
                radial-gradient(ellipse at 12% 15%, rgba(0,150,199,.22), transparent 37%),
                radial-gradient(ellipse at 88% 82%, rgba(0,180,216,.15), transparent 34%),
                linear-gradient(135deg, var(--navy-deep), var(--ocean) 55%, var(--navy));
            font-family: 'Poppins', sans-serif;
        }

        body::before {
            content: "";
            position: fixed;
            inset: 0;
            z-index: -3;
            pointer-events: none;
            background-image:
                linear-gradient(rgba(0,180,216,.045) 1px, transparent 1px),
                linear-gradient(90deg, rgba(0,180,216,.045) 1px, transparent 1px);
            background-size: 42px 42px;
            mask-image: linear-gradient(to bottom, #000, transparent 95%);
            animation: gridDrift 24s linear infinite;
        }

        body::after {
            content: "";
            position: fixed;
            inset: 0;
            z-index: 5;
            pointer-events: none;
            opacity: .22;
            background: repeating-linear-gradient(
                to bottom,
                transparent 0,
                transparent 4px,
                rgba(0,0,0,.12) 5px
            );
        }

        a, button, input {
            font: inherit;
        }

        a {
            color: inherit;
        }

        button, a {
            -webkit-tap-highlight-color: transparent;
        }

        a:focus-visible,
        button:focus-visible,
        input:focus-visible {
            outline: 2px solid var(--cyan);
            outline-offset: 4px;
        }

        ::selection {
            color: var(--white);
            background: rgba(0,180,216,.45);
        }

        #particleCanvas {
            position: fixed;
            inset: 0;
            z-index: -2;
            width: 100%;
            height: 100%;
            pointer-events: none;
            opacity: .55;
        }

        .background-glow {
            position: fixed;
            z-index: -1;
            top: 50%;
            left: 50%;
            width: min(650px, 90vw);
            aspect-ratio: 1;
            border-radius: 50%;
            pointer-events: none;
            background: radial-gradient(circle, rgba(0,180,216,.12), rgba(13,59,102,.06) 45%, transparent 72%);
            transform: translate(-50%, -50%);
            animation: glowPulse 8s ease-in-out infinite alternate;
        }

        .ambient-label {
            position: fixed;
            top: 12%;
            left: 50%;
            z-index: -1;
            pointer-events: none;
            user-select: none;
            white-space: nowrap;
            transform: translateX(-50%);
            color: rgba(255,255,255,.025);
            font-size: clamp(42px, 8vw, 112px);
            font-weight: 800;
            letter-spacing: .1em;
        }

        .ambient-code {
            position: fixed;
            bottom: 6%;
            left: 4%;
            z-index: -1;
            pointer-events: none;
            color: rgba(0,180,216,.22);
            font: 11px/1.9 'JetBrains Mono', monospace;
            letter-spacing: .04em;
        }

        .ambient-code span {
            display: block;
        }

        .ambient-code span::before {
            content: "> ";
            color: var(--cyan);
        }

        .back-home {
            position: absolute;
            top: 24px;
            left: 25px;
            z-index: 10;
            display: inline-flex;
            align-items: center;
            gap: 9px;
            padding: 10px 14px;
            border: 1px solid transparent;
            border-radius: 10px;
            color: #E7F4FC;
            text-decoration: none;
            font-size: 13px;
            transition: color .3s, background .3s, border-color .3s, box-shadow .3s;
        }

        .back-home:hover {
            color: var(--cyan);
            background: rgba(0,180,216,.08);
            border-color: rgba(0,180,216,.24);
            box-shadow: 0 0 24px rgba(0,180,216,.08);
        }

        .icon {
            width: 19px;
            height: 19px;
            flex: 0 0 auto;
            display: inline-block;
            vertical-align: middle;
            fill: none;
            stroke: currentColor;
            stroke-width: 1.8;
            stroke-linecap: round;
            stroke-linejoin: round;
            transition: transform .3s var(--ease), filter .3s, color .3s;
        }

        a:hover .icon,
        button:hover .icon {
            color: var(--cyan);
            filter: drop-shadow(0 0 6px rgba(0,180,216,.7));
            transform: translateY(-2px) scale(1.06);
        }

        .back-home:hover .icon {
            transform: translateX(-3px);
        }

        .login-container {
            position: relative;
            z-index: 2;
            width: 100%;
            max-width: 460px;
            animation: containerEnter .8s var(--ease) both;
        }

        .login-card {
            position: relative;
            overflow: hidden;
            padding: 36px 38px 30px;
            border: 1px solid var(--glass-border);
            border-radius: 22px;
            background: linear-gradient(145deg, rgba(255,255,255,.075), rgba(255,255,255,.025));
            -webkit-backdrop-filter: blur(22px);
            backdrop-filter: blur(22px);
            box-shadow: 0 24px 70px rgba(0,0,0,.28), inset 0 1px 0 rgba(255,255,255,.055), 0 0 35px rgba(0,180,216,.055);
            transition: border-color .35s, box-shadow .35s, transform .35s var(--ease);
        }

        .login-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 10%;
            width: 80%;
            height: 1px;
            background: linear-gradient(90deg, transparent, var(--cyan), transparent);
            opacity: .8;
        }

        .login-card::after {
            content: "";
            position: absolute;
            top: -120%;
            left: -60%;
            width: 40%;
            height: 300%;
            pointer-events: none;
            background: linear-gradient(90deg, transparent, rgba(0,180,216,.05), transparent);
            transform: rotate(24deg);
            animation: cardSweep 9s ease-in-out infinite;
        }

        .login-card:hover {
            border-color: rgba(0,180,216,.3);
            box-shadow: 0 28px 80px rgba(0,0,0,.32), 0 0 40px rgba(0,180,216,.09), inset 0 1px 0 rgba(255,255,255,.07);
        }

        .login-card > * {
            position: relative;
            z-index: 1;
        }

        .brand-logo {
            width: 76px;
            height: 76px;
            margin: 0 auto 17px;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            border: 1px solid rgba(0,180,216,.34);
            border-radius: 22px;
            background: linear-gradient(145deg, rgba(0,180,216,.17), rgba(0,150,199,.05));
            box-shadow: 0 0 28px rgba(0,180,216,.11), inset 0 0 18px rgba(0,180,216,.06);
            transition: transform .4s var(--ease), box-shadow .35s;
        }

        .brand-logo::before {
            content: "";
            position: absolute;
            inset: -6px;
            border: 1px dashed rgba(0,180,216,.25);
            border-radius: 27px;
            animation: logoOrbit 24s linear infinite;
        }

        .brand-logo img {
            width: 54px;
            height: 54px;
            object-fit: contain;
            border-radius: 10px;
            transition: transform .35s var(--ease), filter .35s;
        }

        .brand-logo:hover {
            transform: translateY(-3px);
            box-shadow: 0 0 35px rgba(0,180,216,.22);
        }

        .brand-logo:hover img {
            transform: scale(1.08) rotate(-4deg);
            filter: drop-shadow(0 0 7px rgba(0,180,216,.35));
        }

        .brand-name {
            margin-bottom: 7px;
            text-align: center;
            font-size: 29px;
            line-height: 1.3;
            font-weight: 800;
            letter-spacing: -.8px;
        }

        .brand-name span {
            color: var(--cyan);
            text-shadow: 0 0 22px rgba(0,180,216,.2);
        }

        .subtitle {
            margin-bottom: 24px;
            text-align: center;
            color: var(--muted);
            font-size: 13px;
            line-height: 1.7;
        }

        .system-status {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 8px;
            margin-bottom: 26px;
            color: #B9EAF3;
            font: 10px 'JetBrains Mono', monospace;
            letter-spacing: .08em;
            text-transform: uppercase;
        }

        .status-dot {
            width: 7px;
            height: 7px;
            border-radius: 50%;
            background: var(--cyan);
            box-shadow: 0 0 12px var(--cyan);
            animation: statusPulse 2s ease-in-out infinite;
        }

        .form-heading {
            margin-bottom: 18px;
            color: #F2F8FC;
            font-size: 16px;
            font-weight: 600;
        }

        .form-group {
            margin-bottom: 18px;
        }

        .field-label {
            display: block;
            margin-bottom: 8px;
            color: #DDEAF4;
            font-size: 12px;
            font-weight: 500;
        }

        .input-wrap {
            position: relative;
        }

        .input-icon {
            position: absolute;
            top: 50%;
            left: 14px;
            width: 18px;
            height: 18px;
            color: #85AFC7;
            transform: translateY(-50%);
            pointer-events: none;
            transition: color .25s, filter .25s;
        }

        .input-wrap:focus-within .input-icon {
            color: var(--cyan);
            filter: drop-shadow(0 0 5px rgba(0,180,216,.5));
        }

        .field-input {
            width: 100%;
            min-height: 49px;
            padding: 13px 44px 13px 43px;
            border: 1px solid rgba(255,255,255,.13);
            border-radius: 11px;
            outline: none;
            background: rgba(3,18,37,.43);
            color: var(--white);
            font-size: 13px;
            transition: border-color .3s, box-shadow .3s, background .3s;
        }

        .field-input::placeholder {
            color: #8099AE;
            opacity: 1;
        }

        .field-input:hover {
            border-color: rgba(0,180,216,.28);
        }

        .field-input:focus {
            border-color: var(--cyan);
            background: rgba(3,18,37,.7);
            box-shadow: 0 0 0 3px rgba(0,180,216,.09), 0 0 20px rgba(0,180,216,.05);
        }

        .password-toggle {
            position: absolute;
            top: 50%;
            right: 9px;
            width: 34px;
            height: 34px;
            display: grid;
            place-items: center;
            border: 0;
            border-radius: 8px;
            background: transparent;
            color: #8FAFC5;
            cursor: pointer;
            transform: translateY(-50%);
            transition: color .25s, background .25s;
        }

        .password-toggle:hover {
            color: var(--cyan);
            background: rgba(0,180,216,.08);
        }

        .password-toggle .icon {
            width: 17px;
            height: 17px;
        }

        .form-options {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            margin: -3px 0 21px;
        }

        .text-link {
            color: #8DDFF0;
            text-decoration: none;
            font-size: 12px;
            transition: color .25s, text-shadow .25s;
        }

        .text-link:hover {
            color: var(--white);
            text-shadow: 0 0 12px rgba(0,180,216,.4);
        }

        .login-button {
            width: 100%;
            min-height: 49px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            padding: 13px 18px;
            border: 1px solid rgba(255,255,255,.13);
            border-radius: 11px;
            background: linear-gradient(110deg, #0077B6, #0096C7 55%, #00B4D8);
            color: var(--white);
            font-size: 13px;
            font-weight: 700;
            cursor: pointer;
            box-shadow: 0 8px 24px rgba(0,150,199,.18);
            transition: transform .3s var(--ease), box-shadow .3s, filter .3s;
        }

        .login-button:hover {
            transform: translateY(-2px);
            filter: brightness(1.08);
            box-shadow: 0 12px 30px rgba(0,180,216,.26);
        }

        .login-button:active {
            transform: translateY(0) scale(.99);
        }

        .login-button .icon {
            width: 18px;
            height: 18px;
        }

        .error-message {
            display: flex;
            align-items: flex-start;
            gap: 10px;
            margin-bottom: 19px;
            padding: 12px 13px;
            border: 1px solid rgba(255,119,119,.3);
            border-radius: 10px;
            background: rgba(255,80,80,.075);
            color: var(--danger);
            font-size: 12px;
            line-height: 1.6;
            animation: errorEnter .35s ease both;
        }

        .error-message .icon {
            width: 17px;
            height: 17px;
            margin-top: 1px;
        }

        .register-prompt {
            margin-top: 22px;
            text-align: center;
            color: var(--muted);
            font-size: 12px;
            line-height: 1.8;
        }

        .register-prompt a {
            margin-left: 3px;
            color: var(--cyan);
            font-weight: 600;
            text-decoration: none;
            transition: color .25s, text-shadow .25s;
        }

        .register-prompt a:hover {
            color: var(--white);
            text-shadow: 0 0 12px rgba(0,180,216,.45);
        }

        .security-note {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 7px;
            margin-top: 24px;
            color: #8DA7BA;
            font: 10px 'JetBrains Mono', monospace;
            letter-spacing: .02em;
        }

        .security-note .icon {
            width: 14px;
            height: 14px;
            color: var(--cyan);
        }

        .footer {
            margin-top: 18px;
            text-align: center;
            color: rgba(221,238,248,.52);
            font-size: 10px;
        }

        @keyframes gridDrift {
            from { background-position: 0 0; }
            to { background-position: 42px 42px; }
        }

        @keyframes containerEnter {
            from { opacity: 0; transform: translateY(22px) scale(.985); }
            to { opacity: 1; transform: translateY(0) scale(1); }
        }

        @keyframes logoOrbit {
            to { transform: rotate(360deg); }
        }

        @keyframes cardSweep {
            0%, 65%, 100% { left: -60%; }
            35% { left: 125%; }
        }

        @keyframes glowPulse {
            from { opacity: .65; scale: .96; }
            to { opacity: 1; scale: 1.04; }
        }

        @keyframes statusPulse {
            0%, 100% { opacity: 1; box-shadow: 0 0 12px var(--cyan); }
            50% { opacity: .55; box-shadow: 0 0 4px var(--cyan); }
        }

        @keyframes errorEnter {
            from { opacity: 0; transform: translateY(-5px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 520px) {
            body {
                padding: 78px 15px 26px;
            }

            .back-home {
                top: 15px;
                left: 12px;
                padding: 9px 10px;
            }

            .login-card {
                padding: 30px 22px 25px;
                border-radius: 18px;
            }

            .brand-logo {
                width: 68px;
                height: 68px;
                border-radius: 19px;
            }

            .brand-logo img {
                width: 48px;
                height: 48px;
            }

            .brand-name {
                font-size: 26px;
            }

            .subtitle {
                font-size: 12px;
            }

            .ambient-code {
                display: none;
            }
        }

        @media (max-width: 350px) {
            .login-card {
                padding: 26px 17px 22px;
            }

            .form-options {
                align-items: flex-start;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                scroll-behavior: auto !important;
                animation-duration: .01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: .01ms !important;
            }

            #particleCanvas {
                display: none;
            }
        }
    </style>
</head>

<body>
    <canvas id="particleCanvas" aria-hidden="true"></canvas>
    <div class="background-glow" aria-hidden="true"></div>
    <div class="ambient-label" aria-hidden="true">INTERNPRO</div>

    <div class="ambient-code" aria-hidden="true">
        <span>system.initialize()</span>
        <span>secure.session = true</span>
        <span>access.control.enabled</span>
    </div>

    <a class="back-home" href="index.php" aria-label="Return to InternPro home page">
        <svg class="icon" viewBox="0 0 24 24" aria-hidden="true">
            <path d="M19 12H5"></path>
            <path d="m12 19-7-7 7-7"></path>
        </svg>
        <span>Back to Home</span>
    </a>

    <main class="login-container">
        <section class="login-card" aria-labelledby="loginTitle">
            <div class="brand-logo">
                <img
                    src="assets/logooo.png.png"
                    alt="InternPro logo"
                    width="54"
                    height="54"
                    onerror="this.style.display='none';"
                >
            </div>

            <h1 class="brand-name" id="loginTitle">Intern<span>Pro</span></h1>
            <p class="subtitle">Your career journey starts here.</p>

            <div class="system-status">
                <span class="status-dot" aria-hidden="true"></span>
                <span>Secure access portal</span>
            </div>

            <h2 class="form-heading">Welcome back 👋</h2>

            <?php if ($error !== ''): ?>
                <div class="error-message" role="alert" aria-live="polite">
                    <svg class="icon" viewBox="0 0 24 24" aria-hidden="true">
                        <circle cx="12" cy="12" r="9"></circle>
                        <path d="M12 8v4"></path>
                        <path d="M12 16h.01"></path>
                    </svg>
                    <span><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></span>
                </div>
            <?php endif; ?>

            <form method="POST" action="login.php" id="loginForm" autocomplete="on">
                <div class="form-group">
                    <label class="field-label" for="email">Email address</label>

                    <div class="input-wrap">
                        <svg class="icon input-icon" viewBox="0 0 24 24" aria-hidden="true">
                            <rect x="3" y="5" width="18" height="14" rx="2"></rect>
                            <path d="m3 7 9 6 9-6"></path>
                        </svg>

                        <input
                            class="field-input"
                            type="email"
                            id="email"
                            name="email"
                            placeholder="you@example.com"
                            value="<?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?>"
                            autocomplete="username"
                            maxlength="254"
                            required
                            autofocus
                        >
                    </div>
                </div>

                <div class="form-group">
                    <label class="field-label" for="password">Password</label>

                    <div class="input-wrap">
                        <svg class="icon input-icon" viewBox="0 0 24 24" aria-hidden="true">
                            <rect x="4" y="10" width="16" height="11" rx="2"></rect>
                            <path d="M8 10V7a4 4 0 0 1 8 0v3"></path>
                        </svg>

                        <input
                            class="field-input"
                            type="password"
                            id="password"
                            name="password"
                            placeholder="Enter your password"
                            autocomplete="current-password"
                            required
                        >

                        <button
                            class="password-toggle"
                            type="button"
                            id="togglePassword"
                            aria-label="Show password"
                            aria-pressed="false"
                        >
                            <svg class="icon" id="eyeIcon" viewBox="0 0 24 24" aria-hidden="true">
                                <path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"></path>
                                <circle cx="12" cy="12" r="3"></circle>
                            </svg>
                        </button>
                    </div>
                </div>

                <div class="form-options">
                    <a class="text-link" href="forgot-password.php">Forgot password?</a>
                </div>

                <button class="login-button" type="submit" id="loginButton">
                    <span>Sign In</span>
                    <svg class="icon" viewBox="0 0 24 24" aria-hidden="true">
                        <path d="M5 12h14"></path>
                        <path d="m12 5 7 7-7 7"></path>
                    </svg>
                </button>
            </form>

            <p class="register-prompt">
                Don't have an account?
                <a href="register.php">Create account</a>
            </p>

            <div class="security-note">
                <svg class="icon" viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z"></path>
                    <path d="m9 12 2 2 4-4"></path>
                </svg>
                <span>Protected sign-in</span>
            </div>
        </section>

        <p class="footer">
            &copy; <?= date('Y') ?> InternPro. Build your future.
        </p>
    </main>

    <script>
        (() => {
            'use strict';

            const passwordInput = document.getElementById('password');
            const togglePassword = document.getElementById('togglePassword');
            const eyeIcon = document.getElementById('eyeIcon');
            const loginForm = document.getElementById('loginForm');
            const loginButton = document.getElementById('loginButton');
            const canvas = document.getElementById('particleCanvas');
            const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

            togglePassword.addEventListener('click', () => {
                const showing = passwordInput.type === 'password';

                passwordInput.type = showing ? 'text' : 'password';
                togglePassword.setAttribute('aria-label', showing ? 'Hide password' : 'Show password');
                togglePassword.setAttribute('aria-pressed', String(showing));

                eyeIcon.innerHTML = showing
                    ? '<path d="M3 3l18 18"></path><path d="M10.6 10.6a2 2 0 0 0 2.8 2.8"></path><path d="M9.9 5.2A10.8 10.8 0 0 1 12 5c6.4 0 10 7 10 7a17 17 0 0 1-3 3.8"></path><path d="M6.2 6.2C3.5 8.1 2 12 2 12s3.6 7 10 7a10 10 0 0 0 4-.8"></path>'
                    : '<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"></path><circle cx="12" cy="12" r="3"></circle>';

                passwordInput.focus();
            });

            loginForm.addEventListener('submit', () => {
                if (!loginForm.checkValidity()) {
                    return;
                }

                loginButton.disabled = true;
                loginButton.style.opacity = '0.85';
                loginButton.querySelector('span').textContent = 'Signing in...';
            });

            // Lightweight animated particle network.
            // It is disabled when the visitor requests reduced motion.
            if (!canvas || reducedMotion) {
                return;
            }

            const ctx = canvas.getContext('2d');
            if (!ctx) return;

            let width = 0;
            let height = 0;
            let particles = [];
            let animationFrame = 0;
            let lastFrame = 0;
            const frameInterval = 1000 / 30;

            function resizeCanvas() {
                const dpr = Math.min(window.devicePixelRatio || 1, 2);

                width = window.innerWidth;
                height = window.innerHeight;

                canvas.width = Math.round(width * dpr);
                canvas.height = Math.round(height * dpr);
                ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

                const count = Math.min(65, Math.max(24, Math.floor(width / 22)));

                particles = Array.from({ length: count }, () => ({
                    x: Math.random() * width,
                    y: Math.random() * height,
                    vx: (Math.random() - 0.5) * 0.35,
                    vy: (Math.random() - 0.5) * 0.35,
                    radius: Math.random() * 1.5 + 0.5
                }));
            }

            function draw(timestamp) {
                if (document.hidden) {
                    animationFrame = 0;
                    return;
                }

                if (timestamp - lastFrame < frameInterval) {
                    animationFrame = requestAnimationFrame(draw);
                    return;
                }

                lastFrame = timestamp;
                ctx.clearRect(0, 0, width, height);

                for (let i = 0; i < particles.length; i++) {
                    const p = particles[i];

                    p.x += p.vx;
                    p.y += p.vy;

                    if (p.x < 0 || p.x > width) p.vx *= -1;
                    if (p.y < 0 || p.y > height) p.vy *= -1;

                    ctx.beginPath();
                    ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
                    ctx.fillStyle = 'rgba(56, 189, 248, 0.55)';
                    ctx.fill();

                    for (let j = i + 1; j < particles.length; j++) {
                        const q = particles[j];
                        const dx = p.x - q.x;
                        const dy = p.y - q.y;
                        const distance = Math.sqrt(dx * dx + dy * dy);

                        if (distance < 105) {
                            ctx.beginPath();
                            ctx.moveTo(p.x, p.y);
                            ctx.lineTo(q.x, q.y);
                            ctx.strokeStyle = `rgba(0, 180, 216, ${0.12 * (1 - distance / 105)})`;
                            ctx.lineWidth = 0.7;
                            ctx.stroke();
                        }
                    }
                }

                animationFrame = requestAnimationFrame(draw);
            }

            function startAnimation() {
                if (!document.hidden && !animationFrame) {
                    lastFrame = 0;
                    animationFrame = requestAnimationFrame(draw);
                }
            }

            function stopAnimation() {
                if (animationFrame) {
                    cancelAnimationFrame(animationFrame);
                    animationFrame = 0;
                }
            }

            document.addEventListener('visibilitychange', () => {
                if (document.hidden) {
                    stopAnimation();
                } else {
                    startAnimation();
                }
            });

            window.addEventListener('resize', resizeCanvas, { passive: true });

            resizeCanvas();
            startAnimation();
        })();
    </script>
</body>
</html>
