
<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (
    !isset($_SESSION['user_id']) ||
    ($_SESSION['role'] ?? '') !== 'student'
) {
    header('Location: ../login.php');
    exit;
}

$user_id = (int) $_SESSION['user_id'];

$username = $_SESSION['name']
    ?? $_SESSION['username']
    ?? 'Student';

$user_data = [];
$profile = [];
$database_available = false;

// =====================================================
// DATABASE CONNECTION
// =====================================================

try {
    // Matches your actual directory structure:
    // internship-portal/config/database.php
    $config_path = __DIR__ . '/../config/database.php';

    if (!is_file($config_path)) {
        throw new RuntimeException(
            'Database configuration file was not found.'
        );
    }

    require_once $config_path;

    if (!isset($pdo) || !$pdo instanceof PDO) {
        throw new RuntimeException(
            'The PDO database connection is unavailable.'
        );
    }

    $database_available = true;

    // Retrieve the logged-in user's information.
    $stmt = $pdo->prepare(
        'SELECT * FROM users WHERE id = ? LIMIT 1'
    );

    $stmt->execute([$user_id]);

    $user_data = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

    if (!empty($user_data['name'])) {
        $username = $user_data['name'];
    }

    // Retrieve the user's profile if one exists.
    $profile_stmt = $pdo->prepare(
        'SELECT * FROM student_profiles
         WHERE user_id = ?
         LIMIT 1'
    );

    $profile_stmt->execute([$user_id]);

    $profile = $profile_stmt->fetch(PDO::FETCH_ASSOC) ?: [];

} catch (Throwable $e) {
    // Do not expose database details to visitors.
    error_log(
        'InternPro student dashboard error: '
        . $e->getMessage()
    );
}

/**
 * Escape dynamic output before displaying it in HTML.
 */
function dashboardEscape($value): string
{
    return htmlspecialchars(
        (string) ($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

$name_parts = preg_split('/\s+/', trim((string) $username));
$first_name = $name_parts[0] ?? 'Student';

if ($first_name === '') {
    $first_name = 'Student';
}

$display_name = dashboardEscape($first_name);
$full_name = dashboardEscape($username);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <meta
        name="description"
        content="Manage your InternPro student profile, explore internships, and track applications."
    >

    <meta name="theme-color" content="#020b1a">

    <title>Student Dashboard | InternPro</title>

    <!-- Correct logo and favicon path from student/ -->
    <link
        rel="icon"
        type="image/jpeg"
        href="../assets/logo.jpg"
    >

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link
        rel="preconnect"
        href="https://fonts.gstatic.com"
        crossorigin
    >

    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&display=swap"
        rel="stylesheet"
    >

    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
    >

    <style>
        :root {
            --navy-950: #020b1a;
            --navy-900: #071e3d;
            --navy-850: #0a2a50;
            --navy-800: #0d3b66;

            --blue: #0077b6;
            --cyan: #00b4d8;
            --cyan-light: #38bdf8;
            --cyan-bright: #67e8f9;

            --text: #f8fafc;
            --muted: #94a3b8;

            --border: rgba(148, 163, 184, 0.16);
            --glass: rgba(7, 30, 61, 0.68);

            --radius-lg: 23px;
            --radius-md: 16px;

            --transition: 0.28s ease;
        }

        *,
        *::before,
        *::after {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        html {
            scroll-behavior: smooth;
            scroll-padding-top: 100px;
        }

        body {
            min-height: 100vh;
            overflow-x: hidden;
            color: var(--text);
            font-family: 'Poppins', sans-serif;
            line-height: 1.6;

            background:
                radial-gradient(
                    ellipse at 8% 8%,
                    rgba(0, 180, 216, 0.15),
                    transparent 34%
                ),
                radial-gradient(
                    ellipse at 95% 75%,
                    rgba(0, 119, 182, 0.15),
                    transparent 34%
                ),
                linear-gradient(
                    135deg,
                    var(--navy-950),
                    var(--navy-900) 52%,
                    #041326
                );
        }

        body::before {
            content: "";
            position: fixed;
            inset: 0;
            z-index: -2;
            pointer-events: none;
            opacity: 0.23;

            background-image:
                linear-gradient(
                    rgba(56, 189, 248, 0.055) 1px,
                    transparent 1px
                ),
                linear-gradient(
                    90deg,
                    rgba(56, 189, 248, 0.055) 1px,
                    transparent 1px
                );

            background-size: 48px 48px;
            mask-image: linear-gradient(
                to bottom,
                black,
                transparent 90%
            );
        }

        a {
            color: inherit;
            text-decoration: none;
        }

        button {
            font: inherit;
        }

        a:focus-visible,
        button:focus-visible {
            outline: 2px solid var(--cyan-bright);
            outline-offset: 5px;
        }

        /* Animated background orbs */

        .ambient {
            position: fixed;
            z-index: -1;
            width: 330px;
            height: 330px;
            border-radius: 50%;
            pointer-events: none;
            filter: blur(95px);
            opacity: 0.12;
            animation: ambientFloat 13s ease-in-out infinite alternate;
        }

        .ambient-one {
            top: 12%;
            left: -170px;
            background: var(--cyan);
        }

        .ambient-two {
            right: -180px;
            bottom: 4%;
            background: var(--blue);
            animation-delay: -5s;
        }

        /* Navigation */

        .site-header {
            position: sticky;
            top: 0;
            z-index: 100;
            padding: 12px 5%;

            border-bottom: 1px solid rgba(148, 163, 184, 0.12);

            background: rgba(2, 11, 26, 0.86);
            backdrop-filter: blur(22px);
            -webkit-backdrop-filter: blur(22px);
        }

        .navbar {
            width: min(1400px, 100%);
            min-height: 52px;
            margin: 0 auto;

            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 22px;
        }

        .brand {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            flex-shrink: 0;
        }

        
.brand img {
    width: 46px;
    height: 46px;
    object-fit: cover;
    object-position: center;
    border-radius: 50%;
    border: 2px solid rgba(56, 189, 248, 0.65);
    background: #071e3d;
    box-shadow:
        0 0 0 3px rgba(0, 180, 216, 0.08),
        0 0 15px rgba(0, 180, 216, 0.18);
    transition:
        transform 0.3s ease,
        border-color 0.3s ease,
        box-shadow 0.3s ease;
}

.brand:hover img {
    transform: rotate(-7deg) scale(1.08);
    border-color: #67e8f9;
    box-shadow:
        0 0 0 4px rgba(0, 180, 216, 0.12),
        0 0 23px rgba(0, 180, 216, 0.45);
}


        .brand-name {
            font-family: 'Space Grotesk', sans-serif;
            font-size: 1.45rem;
            font-weight: 700;
            letter-spacing: -0.8px;
        }

        .brand-name span {
            color: var(--cyan-light);
        }

        .nav-links {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
        }

        .nav-link {
            position: relative;

            display: inline-flex;
            align-items: center;
            gap: 8px;

            padding: 11px 13px;
            border: 1px solid transparent;
            border-radius: 12px;

            color: var(--muted);
            font-size: 0.84rem;
            font-weight: 500;

            transition:
                color var(--transition),
                background var(--transition),
                border-color var(--transition),
                transform var(--transition);
        }

        .nav-link i {
            font-size: 1rem;

            transition:
                transform var(--transition),
                color var(--transition),
                filter var(--transition);
        }

        .nav-link:hover {
            color: var(--text);
            background: rgba(56, 189, 248, 0.07);
            border-color: var(--border);
            transform: translateY(-2px);
        }

        .nav-link:hover i {
            color: var(--cyan-light);
            transform: translateY(-2px) rotate(-5deg);
            filter: drop-shadow(
                0 0 7px rgba(0, 180, 216, 0.6)
            );
        }

        .nav-link.active {
            color: var(--cyan-bright);
            border-color: rgba(0, 180, 216, 0.2);
            background: rgba(0, 180, 216, 0.09);
        }

        .nav-link.active::after {
            content: "";
            position: absolute;
            bottom: -13px;
            left: 25%;

            width: 50%;
            height: 2px;
            border-radius: 5px;

            background: var(--cyan);
            box-shadow: 0 0 12px rgba(0, 180, 216, 0.75);
        }

        .logout-link {
            color: #d8e9f8;
            border-color: rgba(56, 189, 248, 0.2);
        }

        .logout-link:hover {
            background: rgba(0, 180, 216, 0.12);
            border-color: rgba(0, 180, 216, 0.5);
        }

        .menu-toggle {
            display: none;

            width: 44px;
            height: 44px;

            align-items: center;
            justify-content: center;

            border: 1px solid var(--border);
            border-radius: 12px;

            color: var(--text);
            background: rgba(7, 30, 61, 0.85);
            cursor: pointer;
        }

        .menu-toggle i {
            font-size: 1.35rem;
            transition: transform var(--transition);
        }

        .menu-toggle:hover i {
            color: var(--cyan-light);
            transform: rotate(90deg);
        }

        /* Main layout */

        .container {
            width: min(1200px, 90%);
            margin: 0 auto;
        }

        .main-content {
            padding: 56px 0 78px;
        }

        /* Welcome hero */

        .hero {
            position: relative;
            isolation: isolate;
            overflow: hidden;

            padding: clamp(28px, 5vw, 55px);

            border: 1px solid rgba(56, 189, 248, 0.22);
            border-radius: 30px;

            background:
                radial-gradient(
                    circle at 87% 18%,
                    rgba(0, 180, 216, 0.15),
                    transparent 32%
                ),
                linear-gradient(
                    135deg,
                    rgba(13, 59, 102, 0.76),
                    rgba(4, 18, 36, 0.93)
                );

            box-shadow:
                0 25px 70px rgba(0, 0, 0, 0.2),
                inset 0 1px rgba(255, 255, 255, 0.035);

            animation: fadeUp 0.7s ease both;
        }

        .hero::before {
            content: "";
            position: absolute;
            z-index: -1;
            top: -120px;
            right: -80px;

            width: 330px;
            height: 330px;

            border: 1px solid rgba(56, 189, 248, 0.12);
            border-radius: 50%;

            box-shadow:
                0 0 0 35px rgba(56, 189, 248, 0.025),
                0 0 0 70px rgba(56, 189, 248, 0.018);

            animation: orbit 28s linear infinite;
        }

        .hero::after {
            content: "";
            position: absolute;
            right: 0;
            bottom: 0;

            width: 45%;
            height: 2px;

            background: linear-gradient(
                90deg,
                transparent,
                var(--cyan),
                transparent
            );

            opacity: 0.6;
        }

        .hero-content {
            position: relative;
            z-index: 1;
            max-width: 760px;
        }

        .eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 9px;

            margin-bottom: 19px;
            padding: 7px 12px;

            border: 1px solid rgba(56, 189, 248, 0.23);
            border-radius: 30px;

            color: var(--cyan-bright);
            background: rgba(0, 180, 216, 0.07);

            font-size: 0.74rem;
            font-weight: 600;
            letter-spacing: 1.1px;
            text-transform: uppercase;
        }

        .eyebrow i {
            animation: iconPulse 2.5s ease-in-out infinite;
        }

        .hero h1 {
            max-width: 750px;
            margin-bottom: 17px;

            font-family: 'Space Grotesk', sans-serif;
            font-size: clamp(2.05rem, 5vw, 3.8rem);
            font-weight: 700;
            line-height: 1.13;
            letter-spacing: -1.8px;
        }

        .gradient-text {
            color: var(--cyan-light);

            background: linear-gradient(
                100deg,
                var(--cyan),
                var(--cyan-bright),
                var(--cyan-light)
            );

            -webkit-background-clip: text;
            background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .hero-description {
            max-width: 610px;
            margin-bottom: 27px;

            color: #a9bdd0;
            font-size: 0.97rem;
            line-height: 1.9;
        }

        .hero-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
        }

        /* Buttons */

        .btn {
            display: inline-flex;
            min-height: 48px;

            align-items: center;
            justify-content: center;
            gap: 10px;

            padding: 12px 19px;

            border: 1px solid transparent;
            border-radius: 13px;

            font-size: 0.87rem;
            font-weight: 600;

            transition:
                transform var(--transition),
                box-shadow var(--transition),
                border-color var(--transition),
                background var(--transition);
        }

        .btn i {
            font-size: 1.08rem;
            transition: transform var(--transition);
        }

        .btn:hover {
            transform: translateY(-3px);
        }

        .btn:hover i {
            transform: translateX(3px);
        }

        .btn-primary {
            color: #021522;

            background: linear-gradient(
                110deg,
                var(--cyan),
                var(--cyan-light)
            );

            box-shadow: 0 8px 25px rgba(0, 180, 216, 0.15);
        }

        .btn-primary:hover {
            box-shadow: 0 12px 32px rgba(0, 180, 216, 0.27);
        }

        .btn-secondary {
            color: var(--text);
            border-color: rgba(148, 163, 184, 0.24);
            background: rgba(255, 255, 255, 0.035);
        }

        .btn-secondary:hover {
            border-color: rgba(56, 189, 248, 0.45);
            background: rgba(56, 189, 248, 0.07);
        }

        /* Section headings */

        .section {
            margin-top: 52px;
        }

        .section-heading {
            display: flex;
            align-items: end;
            justify-content: space-between;
            gap: 20px;
            margin-bottom: 22px;
        }

        .section-kicker {
            display: block;
            margin-bottom: 7px;

            color: var(--cyan);
            font-size: 0.73rem;
            font-weight: 700;
            letter-spacing: 1.8px;
            text-transform: uppercase;
        }

        .section-heading h2 {
            font-family: 'Space Grotesk', sans-serif;
            font-size: clamp(1.5rem, 3vw, 2.05rem);
            font-weight: 700;
            letter-spacing: -0.7px;
        }

        .section-heading p {
            margin-top: 6px;
            color: var(--muted);
            font-size: 0.9rem;
        }

        /* Action cards */

        .action-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 17px;
        }

        .action-card {
            position: relative;

            display: flex;
            min-width: 0;
            min-height: 238px;

            flex-direction: column;
            align-items: flex-start;
            overflow: hidden;

            padding: 24px 21px;

            border: 1px solid var(--border);
            border-radius: var(--radius-lg);

            background: var(--glass);
            box-shadow: 0 12px 34px rgba(0, 0, 0, 0.12);

            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);

            transition:
                transform var(--transition),
                border-color var(--transition),
                box-shadow var(--transition),
                background var(--transition);

            animation: fadeUp 0.65s ease both;
        }

        .action-card:nth-child(2) {
            animation-delay: 0.08s;
        }

        .action-card:nth-child(3) {
            animation-delay: 0.16s;
        }

        .action-card:nth-child(4) {
            animation-delay: 0.24s;
        }

        .action-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: -120%;

            width: 75%;
            height: 1px;

            background: linear-gradient(
                90deg,
                transparent,
                var(--cyan-light),
                transparent
            );

            transition: left 0.65s ease;
        }

        .action-card:hover::before {
            left: 140%;
        }

        .action-card:hover {
            transform: translateY(-7px);

            border-color: rgba(56, 189, 248, 0.4);
            background: rgba(10, 42, 80, 0.82);

            box-shadow:
                0 22px 45px rgba(0, 0, 0, 0.2),
                0 0 28px rgba(0, 180, 216, 0.055);
        }

        .action-icon {
            display: flex;
            width: 54px;
            height: 54px;
            flex-shrink: 0;

            align-items: center;
            justify-content: center;

            margin-bottom: 20px;

            border: 1px solid rgba(56, 189, 248, 0.19);
            border-radius: 17px;

            color: var(--cyan-light);

            background: linear-gradient(
                145deg,
                rgba(0, 180, 216, 0.15),
                rgba(0, 119, 182, 0.07)
            );

            transition:
                transform var(--transition),
                box-shadow var(--transition),
                color var(--transition),
                background var(--transition);
        }

        .action-icon i {
            font-size: 1.45rem;
            transition: transform var(--transition);
        }

        .action-card:hover .action-icon {
            transform: translateY(-3px) rotate(-4deg);
            color: var(--cyan-bright);
            background: rgba(0, 180, 216, 0.17);
            box-shadow: 0 0 22px rgba(0, 180, 216, 0.13);
        }

        .action-card:hover .action-icon i {
            transform: scale(1.13) rotate(5deg);
        }

        .action-card h3 {
            margin-bottom: 8px;
            font-family: 'Space Grotesk', sans-serif;
            font-size: 1.06rem;
            font-weight: 700;
        }

        .action-card p {
            margin-bottom: 22px;
            color: var(--muted);
            font-size: 0.82rem;
            line-height: 1.8;
        }

        .card-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-top: auto;

            color: var(--cyan-light);
            font-size: 0.82rem;
            font-weight: 600;
        }

        .card-link i {
            transition: transform var(--transition);
        }

        .action-card:hover .card-link i {
            transform: translateX(5px);
        }

        /* Journey section */

        .journey-card {
            position: relative;
            overflow: hidden;

            padding: clamp(23px, 4vw, 37px);

            border: 1px solid var(--border);
            border-radius: var(--radius-lg);

            background: linear-gradient(
                120deg,
                rgba(7, 30, 61, 0.9),
                rgba(10, 42, 80, 0.6)
            );
        }

        .journey-card::after {
            content: "";
            position: absolute;
            right: -100px;
            bottom: -160px;

            width: 280px;
            height: 280px;

            border: 1px solid rgba(56, 189, 248, 0.12);
            border-radius: 50%;

            box-shadow: 0 0 0 35px rgba(56, 189, 248, 0.025);
            pointer-events: none;
        }

        .journey-steps {
            position: relative;

            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 20px;

            margin-top: 27px;
        }

        .journey-step {
            position: relative;
            z-index: 1;
            min-width: 0;
            padding: 4px 0;
        }

        .journey-step:not(:last-child)::after {
            content: "";
            position: absolute;
            top: 21px;
            left: 53px;

            width: calc(100% - 40px);
            height: 1px;

            background: linear-gradient(
                90deg,
                rgba(0, 180, 216, 0.6),
                rgba(56, 189, 248, 0.08)
            );
        }

        .step-number {
            display: flex;
            width: 43px;
            height: 43px;

            align-items: center;
            justify-content: center;

            margin-bottom: 15px;

            border: 1px solid rgba(56, 189, 248, 0.27);
            border-radius: 14px;

            color: var(--cyan-bright);
            background: rgba(0, 180, 216, 0.08);

            transition:
                transform var(--transition),
                background var(--transition),
                box-shadow var(--transition);
        }

        .step-number i {
            font-size: 1.15rem;
            transition: transform var(--transition);
        }

        .journey-step:hover .step-number {
            transform: translateY(-4px);
            background: rgba(0, 180, 216, 0.17);
            box-shadow: 0 0 20px rgba(0, 180, 216, 0.12);
        }

        .journey-step:hover .step-number i {
            transform: scale(1.12) rotate(-6deg);
        }

        .journey-step h3 {
            margin-bottom: 5px;
            font-size: 0.92rem;
            font-weight: 600;
        }

        .journey-step p {
            max-width: 205px;
            color: var(--muted);
            font-size: 0.79rem;
            line-height: 1.8;
        }

        /* Profile reminder */

        .profile-callout {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 25px;

            margin-top: 26px;
            padding: 24px 27px;

            border: 1px solid rgba(0, 180, 216, 0.2);
            border-radius: var(--radius-md);

            background: rgba(0, 180, 216, 0.055);

            animation: fadeUp 0.8s ease both;
        }

        .callout-content {
            display: flex;
            align-items: center;
            gap: 17px;
        }

        .callout-icon {
            display: flex;
            width: 49px;
            height: 49px;
            flex-shrink: 0;

            align-items: center;
            justify-content: center;

            border: 1px solid rgba(56, 189, 248, 0.18);
            border-radius: 15px;

            color: var(--cyan-light);
            background: rgba(0, 180, 216, 0.1);

            transition: transform var(--transition);
        }

        .callout-icon i {
            font-size: 1.35rem;
            transition: transform var(--transition);
        }

        .profile-callout:hover .callout-icon {
            transform: rotate(-5deg) scale(1.04);
        }

        .profile-callout:hover .callout-icon i {
            transform: scale(1.12);
        }

        .callout-content h3 {
            margin-bottom: 4px;
            font-family: 'Space Grotesk', sans-serif;
            font-size: 1rem;
        }

        .callout-content p {
            color: var(--muted);
            font-size: 0.82rem;
        }

        /* Footer */

        .site-footer {
            padding: 24px 5%;
            border-top: 1px solid rgba(148, 163, 184, 0.1);
            color: var(--muted);
            background: rgba(2, 11, 26, 0.42);
            text-align: center;
            font-size: 0.8rem;
        }

        .site-footer span {
            color: var(--cyan-light);
        }

        .site-footer i {
            display: inline-block;
            color: var(--cyan);
            transition: transform var(--transition);
        }

        .site-footer:hover i {
            transform: scale(1.2);
        }

        /* Scroll reveal */

        .reveal {
            opacity: 0;
            transform: translateY(18px);

            transition:
                opacity 0.65s ease,
                transform 0.65s ease;
        }

        .reveal.visible {
            opacity: 1;
            transform: translateY(0);
        }

        /* Animations */

        @keyframes fadeUp {
            from {
                opacity: 0;
                transform: translateY(17px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes ambientFloat {
            from {
                transform: translate3d(0, 0, 0);
            }

            to {
                transform: translate3d(35px, -25px, 0);
            }
        }

        @keyframes orbit {
            to {
                transform: rotate(360deg);
            }
        }

        @keyframes iconPulse {
            0%, 100% {
                transform: scale(1);
            }

            50% {
                transform: scale(1.12);
            }
        }

        /* Tablet */

        @media (max-width: 1050px) {
            .site-header {
                padding-inline: 4%;
            }

            .nav-link {
                padding: 10px 9px;
                font-size: 0.79rem;
            }

            .action-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            .action-card {
                min-height: 220px;
            }
        }

        /* Mobile navigation */

        @media (max-width: 760px) {
            .site-header {
                padding: 10px 5%;
            }

            .navbar {
                position: relative;
                flex-wrap: wrap;
            }

            .brand-name {
                font-size: 1.3rem;
            }

            .brand img {
                width: 39px;
                height: 39px;
            }

            .menu-toggle {
                display: inline-flex;
            }

            .nav-links {
                position: absolute;
                top: calc(100% + 12px);
                right: 0;
                left: 0;

                display: none;
                align-items: stretch;
                flex-direction: column;
                gap: 5px;

                padding: 12px;

                border: 1px solid var(--border);
                border-radius: 17px;

                background: rgba(2, 11, 26, 0.97);
                box-shadow: 0 18px 45px rgba(0, 0, 0, 0.35);

                backdrop-filter: blur(20px);
                -webkit-backdrop-filter: blur(20px);
            }

            .nav-links.open {
                display: flex;
                animation: fadeUp 0.22s ease both;
            }

            .nav-link {
                padding: 12px 14px;
                font-size: 0.88rem;
            }

            .nav-link.active::after {
                display: none;
            }

            .main-content {
                padding-top: 35px;
            }

            .hero {
                border-radius: 23px;
            }

            .hero h1 {
                letter-spacing: -1px;
            }

            .section {
                margin-top: 40px;
            }

            .journey-steps {
                grid-template-columns: repeat(2, minmax(0, 1fr));
                row-gap: 28px;
            }

            .journey-step:nth-child(2)::after {
                display: none;
            }

            .profile-callout {
                align-items: flex-start;
                flex-direction: column;
            }

            .profile-callout .btn {
                width: 100%;
            }
        }

        /* Small mobile screens */

        @media (max-width: 480px) {
            .container {
                width: 91%;
            }

            .main-content {
                padding-top: 25px;
                padding-bottom: 55px;
            }

            .hero {
                padding: 26px 21px;
                border-radius: 20px;
            }

            .hero h1 {
                font-size: 2rem;
            }

            .hero-description {
                font-size: 0.88rem;
            }

            .hero-actions {
                flex-direction: column;
            }

            .hero-actions .btn {
                width: 100%;
            }

            .section-heading {
                align-items: flex-start;
                flex-direction: column;
                gap: 10px;
            }

            .action-grid {
                grid-template-columns: 1fr;
                gap: 13px;
            }

            .action-card {
                min-height: auto;
                padding: 22px;
            }

            .action-card p {
                margin-bottom: 18px;
            }

            .journey-card {
                padding: 22px 18px;
            }

            .journey-steps {
                gap: 22px 14px;
            }

            .journey-step:not(:last-child)::after {
                display: none;
            }

            .journey-step h3 {
                font-size: 0.85rem;
            }

            .journey-step p {
                font-size: 0.76rem;
            }

            .profile-callout {
                padding: 21px 18px;
            }

            .callout-content {
                align-items: flex-start;
                gap: 12px;
            }

            .callout-content p {
                font-size: 0.78rem;
            }
        }

        /* Accessibility */

        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                scroll-behavior: auto !important;
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important;
            }

            .reveal {
                opacity: 1;
                transform: none;
            }
        }
    </style>
</head>

<body>
    <div class="ambient ambient-one" aria-hidden="true"></div>
    <div class="ambient ambient-two" aria-hidden="true"></div>

    <header class="site-header">
        <nav class="navbar" aria-label="Main navigation">

            <a
                class="brand"
                href="dashboard.php"
                aria-label="InternPro student dashboard"
            >
                <img
                    src="../assets/logo.jpg"
                    alt="InternPro logo"
                    width="43"
                    height="43"
                    onerror="this.style.display='none';"
                >

                <span class="brand-name">Intern<span>Pro</span></span>
            </a>

            <button
                class="menu-toggle"
                id="menuToggle"
                type="button"
                aria-label="Open navigation menu"
                aria-controls="navLinks"
                aria-expanded="false"
            >
                <i class="bi bi-list" aria-hidden="true"></i>
            </button>

            <div class="nav-links" id="navLinks">

                <a
                    class="nav-link active"
                    href="dashboard.php"
                    aria-current="page"
                >
                    <i class="bi bi-grid-1x2-fill" aria-hidden="true"></i>
                    <span>Dashboard</span>
                </a>

                <a class="nav-link" href="profile.php">
                    <i class="bi bi-person-circle" aria-hidden="true"></i>
                    <span>My Profile</span>
                </a>

                <a class="nav-link" href="internships.php">
                    <i class="bi bi-briefcase-fill" aria-hidden="true"></i>
                    <span>Internships</span>
                </a>

                <a class="nav-link" href="applications.php">
                    <i
                        class="bi bi-file-earmark-check-fill"
                        aria-hidden="true"
                    ></i>
                    <span>Applications</span>
                </a>

                <a class="nav-link logout-link" href="../logout.php">
                    <i class="bi bi-box-arrow-right" aria-hidden="true"></i>
                    <span>Logout</span>
                </a>

            </div>
        </nav>
    </header>

    <main class="container main-content">

        <!-- Welcome section -->

        <section class="hero" aria-labelledby="welcomeHeading">
            <div class="hero-content">

                <div class="eyebrow">
                    <i class="bi bi-stars" aria-hidden="true"></i>
                    Your career starts here
                </div>

                <h1 id="welcomeHeading">
                    Welcome back,
                    <span class="gradient-text"><?= $display_name ?></span>
                </h1>

                <p class="hero-description">
                    Ready to take the next step in your career?
                    Discover opportunities, strengthen your profile,
                    and keep your internship journey moving forward.
                </p>

                <div class="hero-actions">
                    <a class="btn btn-primary" href="internships.php">
                        <i class="bi bi-search" aria-hidden="true"></i>
                        Explore Internships
                        <i
                            class="bi bi-arrow-up-right"
                            aria-hidden="true"
                        ></i>
                    </a>

                    <a class="btn btn-secondary" href="applications.php">
                        <i
                            class="bi bi-clipboard-check"
                            aria-hidden="true"
                        ></i>
                        Track Applications
                    </a>
                </div>

            </div>
        </section>

        <!-- Quick actions -->

        <section
            class="section reveal"
            aria-labelledby="quickActionsHeading"
        >
            <div class="section-heading">
                <div>
                    <span class="section-kicker">Your workspace</span>
                    <h2 id="quickActionsHeading">Quick Actions</h2>
                    <p>
                        Everything you need to move your career forward.
                    </p>
                </div>
            </div>

            <div class="action-grid">

                <a class="action-card" href="internships.php">
                    <div class="action-icon">
                        <i
                            class="bi bi-briefcase-fill"
                            aria-hidden="true"
                        ></i>
                    </div>

                    <h3>Discover Internships</h3>

                    <p>
                        Explore available opportunities and find roles
                        that match your skills and interests.
                    </p>

                    <span class="card-link">
                        Browse opportunities
                        <i class="bi bi-arrow-right" aria-hidden="true"></i>
                    </span>
                </a>

                <a class="action-card" href="profile.php">
                    <div class="action-icon">
                        <i
                            class="bi bi-person-badge-fill"
                            aria-hidden="true"
                        ></i>
                    </div>

                    <h3>Build Your Profile</h3>

                    <p>
                        Keep your personal information, skills and
                        professional details up to date.
                    </p>

                    <span class="card-link">
                        Manage your profile
                        <i class="bi bi-arrow-right" aria-hidden="true"></i>
                    </span>
                </a>

                <a class="action-card" href="applications.php">
                    <div class="action-icon">
                        <i
                            class="bi bi-file-earmark-check-fill"
                            aria-hidden="true"
                        ></i>
                    </div>

                    <h3>Track Applications</h3>

                    <p>
                        Review the current status of your applications
                        and stay informed about your progress.
                    </p>

                    <span class="card-link">
                        View applications
                        <i class="bi bi-arrow-right" aria-hidden="true"></i>
                    </span>
                </a>

                <a class="action-card" href="profile.php">
                    <div class="action-icon">
                        <i
                            class="bi bi-rocket-takeoff-fill"
                            aria-hidden="true"
                        ></i>
                    </div>

                    <h3>Move Forward</h3>

                    <p>
                        Highlight your strengths and prepare your
                        profile for your next opportunity.
                    </p>

                    <span class="card-link">
                        Improve your profile
                        <i class="bi bi-arrow-right" aria-hidden="true"></i>
                    </span>
                </a>

            </div>
        </section>

        <!-- Internship journey -->

        <section
            class="section reveal"
            aria-labelledby="journeyHeading"
        >
            <div class="section-heading">
                <div>
                    <span class="section-kicker">Your next chapter</span>
                    <h2 id="journeyHeading">Your Internship Journey</h2>
                    <p>
                        A simple path from preparation to opportunity.
                    </p>
                </div>
            </div>

            <div class="journey-card">
                <div class="journey-steps">

                    <div class="journey-step">
                        <div class="step-number">
                            <i
                                class="bi bi-person-check-fill"
                                aria-hidden="true"
                            ></i>
                        </div>

                        <h3>01. Build</h3>
                        <p>
                            Complete your profile and highlight your skills.
                        </p>
                    </div>

                    <div class="journey-step">
                        <div class="step-number">
                            <i class="bi bi-search" aria-hidden="true"></i>
                        </div>

                        <h3>02. Discover</h3>
                        <p>
                            Find internships that match your career goals.
                        </p>
                    </div>

                    <div class="journey-step">
                        <div class="step-number">
                            <i
                                class="bi bi-send-fill"
                                aria-hidden="true"
                            ></i>
                        </div>

                        <h3>03. Apply</h3>
                        <p>
                            Submit applications to opportunities you like.
                        </p>
                    </div>

                    <div class="journey-step">
                        <div class="step-number">
                            <i
                                class="bi bi-graph-up-arrow"
                                aria-hidden="true"
                            ></i>
                        </div>

                        <h3>04. Grow</h3>
                        <p>
                            Follow your application progress and prepare
                            for the next step.
                        </p>
                    </div>

                </div>
            </div>
        </section>

        <!-- Profile reminder -->

        <section class="profile-callout reveal" aria-label="Profile reminder">

            <div class="callout-content">
                <div class="callout-icon">
                    <i
                        class="bi bi-lightning-charge-fill"
                        aria-hidden="true"
                    ></i>
                </div>

                <div>
                    <h3>Make your profile stand out</h3>
                    <p>
                        A clear, up-to-date profile helps employers
                        understand your strengths.
                    </p>
                </div>
            </div>

            <a class="btn btn-primary" href="profile.php">
                Update Profile
                <i class="bi bi-arrow-right" aria-hidden="true"></i>
            </a>

        </section>

    </main>

    <footer class="site-footer">
        <p>
            &copy; <?= date('Y') ?>
            <span>InternPro</span>.
            Built for your next opportunity
            <i
                class="bi bi-lightning-charge-fill"
                aria-hidden="true"
            ></i>
        </p>
    </footer>

    <script>
        (() => {
            'use strict';

            const menuToggle = document.getElementById('menuToggle');
            const navLinks = document.getElementById('navLinks');

            // Responsive mobile navigation.
            if (menuToggle && navLinks) {
                const menuIcon = menuToggle.querySelector('i');

                function closeMenu() {
                    navLinks.classList.remove('open');

                    menuToggle.setAttribute(
                        'aria-expanded',
                        'false'
                    );

                    menuToggle.setAttribute(
                        'aria-label',
                        'Open navigation menu'
                    );

                    if (menuIcon) {
                        menuIcon.className = 'bi bi-list';
                    }
                }

                menuToggle.addEventListener('click', () => {
                    const isOpen = navLinks.classList.toggle('open');

                    menuToggle.setAttribute(
                        'aria-expanded',
                        String(isOpen)
                    );

                    menuToggle.setAttribute(
                        'aria-label',
                        isOpen
                            ? 'Close navigation menu'
                            : 'Open navigation menu'
                    );

                    if (menuIcon) {
                        menuIcon.className = isOpen
                            ? 'bi bi-x-lg'
                            : 'bi bi-list';
                    }
                });

                navLinks.querySelectorAll('a').forEach((link) => {
                    link.addEventListener('click', closeMenu);
                });

                document.addEventListener('click', (event) => {
                    if (
                        !navLinks.contains(event.target) &&
                        !menuToggle.contains(event.target)
                    ) {
                        closeMenu();
                    }
                });

                document.addEventListener('keydown', (event) => {
                    if (event.key === 'Escape') {
                        const wasOpen =
                            navLinks.classList.contains('open');

                        closeMenu();

                        if (wasOpen) {
                            menuToggle.focus();
                        }
                    }
                });

                window.addEventListener('resize', () => {
                    if (window.innerWidth > 760) {
                        closeMenu();
                    }
                });
            }

            // Animate sections as they enter the viewport.
            const revealElements =
                document.querySelectorAll('.reveal');

            const reduceMotion = window.matchMedia(
                '(prefers-reduced-motion: reduce)'
            ).matches;

            if (
                'IntersectionObserver' in window &&
                !reduceMotion
            ) {
                const observer = new IntersectionObserver(
                    (entries, currentObserver) => {
                        entries.forEach((entry) => {
                            if (entry.isIntersecting) {
                                entry.target.classList.add('visible');

                                currentObserver.unobserve(entry.target);
                            }
                        });
                    },
                    {
                        threshold: 0.12,
                        rootMargin: '0px 0px -35px 0px'
                    }
                );

                revealElements.forEach((element) => {
                    observer.observe(element);
                });
            } else {
                revealElements.forEach((element) => {
                    element.classList.add('visible');
                });
            }
        })();
    </script>
</body>
</html>
