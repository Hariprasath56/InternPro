
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/database.php';

if (
    !isset($_SESSION['user_id']) ||
    !isset($_SESSION['role']) ||
    $_SESSION['role'] !== 'student'
) {
    header('Location: ../login.php');
    exit;
}

if (!isset($pdo) || !($pdo instanceof PDO)) {
    http_response_code(500);
    exit('Database connection is unavailable.');
}

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

$userId = (int) $_SESSION['user_id'];
$internshipId = filter_input(INPUT_GET, 'internship_id', FILTER_VALIDATE_INT);

if (!$internshipId || $internshipId < 1) {
    $internshipId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postedInternshipId = filter_input(INPUT_POST, 'internship_id', FILTER_VALIDATE_INT);

    if ($postedInternshipId && $postedInternshipId > 0) {
        $internshipId = $postedInternshipId;
    }
}

$error = '';
$success = '';
$coverLetter = '';
$studentId = null;
$internship = null;
$student = null;
$existingApplication = null;
$csrfToken = '';

if (empty($_SESSION['apply_csrf_token'])) {
    $_SESSION['apply_csrf_token'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['apply_csrf_token'];

function applyEscape($value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
}

try {
    $studentStmt = $pdo->prepare(
        'SELECT id, user_id FROM students WHERE user_id = :user_id LIMIT 1'
    );
    $studentStmt->execute(['user_id' => $userId]);
    $student = $studentStmt->fetch();

    if ($student) {
        $studentId = (int) $student['id'];
    } else {
        $error = 'Your student record could not be found. Please complete your student registration before applying.';
    }

    if (!$error && $internshipId && $internshipId > 0) {
        $internshipStmt = $pdo->prepare(
            'SELECT i.* FROM internships i WHERE i.id = :internship_id LIMIT 1'
        );
        $internshipStmt->execute(['internship_id' => $internshipId]);
        $internship = $internshipStmt->fetch();

        if (!$internship) {
            $error = 'This internship could not be found. It may have been removed.';
        } else {
            $applicationStmt = $pdo->prepare(
                'SELECT id, status FROM applications
                 WHERE student_id = :student_id
                 AND internship_id = :internship_id
                 LIMIT 1'
            );
            $applicationStmt->execute([
                'student_id' => $studentId,
                'internship_id' => $internshipId
            ]);
            $existingApplication = $applicationStmt->fetch();
        }
    } elseif (!$error) {
        $error = 'No valid internship was selected. Return to the internships page and choose an opportunity.';
    }

    if (
        $_SERVER['REQUEST_METHOD'] === 'POST' &&
        $studentId &&
        $internship &&
        !$existingApplication
    ) {
        $submittedToken = (string) ($_POST['csrf_token'] ?? '');

        if (!hash_equals($csrfToken, $submittedToken)) {
            $error = 'Your session token has expired. Refresh the page and try again.';
        } else {
            $coverLetter = trim((string) ($_POST['cover_letter'] ?? ''));

            if (mb_strlen($coverLetter) > 10000) {
                $error = 'Your cover letter must be 10,000 characters or fewer.';
            }

            $resumePath = null;
            $resumeFile = $_FILES['resume'] ?? null;

            if (!$error && $resumeFile && $resumeFile['error'] !== UPLOAD_ERR_NO_FILE) {
                if ($resumeFile['error'] !== UPLOAD_ERR_OK) {
                    $error = 'The resume upload failed. Please try again.';
                } elseif (!is_uploaded_file($resumeFile['tmp_name'])) {
                    $error = 'The uploaded resume could not be verified.';
                } elseif ($resumeFile['size'] > 5 * 1024 * 1024) {
                    $error = 'Your resume must be 5 MB or smaller.';
                } else {
                    $extension = strtolower(
                        pathinfo($resumeFile['name'], PATHINFO_EXTENSION)
                    );

                    $allowedExtensions = ['pdf', 'doc', 'docx'];

                    $fileInfo = new finfo(FILEINFO_MIME_TYPE);
                    $mimeType = $fileInfo->file($resumeFile['tmp_name']);

                    $allowedMimeTypes = [
                        'pdf' => ['application/pdf'],
                        'doc' => ['application/msword', 'application/octet-stream'],
                        'docx' => [
                            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                            'application/zip',
                            'application/octet-stream'
                        ]
                    ];

                    if (
                        !in_array($extension, $allowedExtensions, true) ||
                        !in_array($mimeType, $allowedMimeTypes[$extension] ?? [], true)
                    ) {
                        $error = 'Upload your resume as a PDF, DOC, or DOCX file.';
                    } else {
                        $uploadDirectory = __DIR__ . '/../uploads/resumes/';

                        if (
                            !is_dir($uploadDirectory) &&
                            !mkdir($uploadDirectory, 0755, true) &&
                            !is_dir($uploadDirectory)
                        ) {
                            $error = 'The resume upload directory could not be created.';
                        } elseif (!is_writable($uploadDirectory)) {
                            $error = 'The resume upload directory is not writable.';
                        } else {
                            $safeFileName = bin2hex(random_bytes(20)) . '.' . $extension;
                            $destination = $uploadDirectory . $safeFileName;

                            if (move_uploaded_file($resumeFile['tmp_name'], $destination)) {
                                $resumePath = 'uploads/resumes/' . $safeFileName;
                            } else {
                                $error = 'Your resume could not be saved. Please try again.';
                            }
                        }
                    }
                }
            }

            if (!$error) {
                try {
                    $pdo->beginTransaction();

                    $verifyStmt = $pdo->prepare(
                        'SELECT id FROM internships WHERE id = :internship_id LIMIT 1'
                    );
                    $verifyStmt->execute(['internship_id' => $internshipId]);

                    if (!$verifyStmt->fetch()) {
                        throw new RuntimeException('This internship is no longer available.');
                    }

                    $duplicateStmt = $pdo->prepare(
                        'SELECT id FROM applications
                         WHERE student_id = :student_id
                         AND internship_id = :internship_id
                         LIMIT 1'
                    );
                    $duplicateStmt->execute([
                        'student_id' => $studentId,
                        'internship_id' => $internshipId
                    ]);

                    if ($duplicateStmt->fetch()) {
                        throw new RuntimeException('You have already applied for this internship.');
                    }

                    $insertStmt = $pdo->prepare(
                        "INSERT INTO applications
                         (internship_id, student_id, resume_path, cover_letter, status)
                         VALUES
                         (:internship_id, :student_id, :resume_path, :cover_letter, 'applied')"
                    );

                    $insertStmt->execute([
                        'internship_id' => $internshipId,
                        'student_id' => $studentId,
                        'resume_path' => $resumePath,
                        'cover_letter' => $coverLetter !== '' ? $coverLetter : null
                    ]);

                    $pdo->commit();

                    unset($_SESSION['apply_csrf_token']);
                    $_SESSION['apply_success_message'] = 'Your application has been submitted successfully.';

                    header('Location: applications.php?submitted=1');
                    exit;
                } catch (Throwable $exception) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }

                    if ($resumePath !== null) {
                        $savedFile = __DIR__ . '/../' . $resumePath;
                        if (is_file($savedFile)) {
                            unlink($savedFile);
                        }
                    }

                    if ($exception instanceof RuntimeException) {
                        $error = $exception->getMessage();
                    } else {
                        error_log('InternPro application submission error: ' . $exception->getMessage());
                        $error = 'Your application could not be submitted. Please try again.';
                    }
                }
            }
        }
    }
} catch (Throwable $exception) {
    error_log('InternPro apply page error: ' . $exception->getMessage());
    http_response_code(500);
    $error = 'Unable to load this application page. Please try again later.';
}

$alreadyApplied = is_array($existingApplication);
$companyName = '';

if ($internship) {
    foreach (['company_name', 'company', 'employer_name'] as $companyField) {
        if (!empty($internship[$companyField]) && is_string($internship[$companyField])) {
            $companyName = $internship[$companyField];
            break;
        }
    }

    if ($companyName === '' && isset($internship['company_id'])) {
        try {
            $companyStmt = $pdo->prepare(
                'SELECT * FROM companies WHERE id = :company_id LIMIT 1'
            );
            $companyStmt->execute(['company_id' => (int) $internship['company_id']]);
            $company = $companyStmt->fetch();

            if ($company) {
                foreach (['company_name', 'name', 'name_of_company'] as $nameField) {
                    if (!empty($company[$nameField])) {
                        $companyName = (string) $company[$nameField];
                        break;
                    }
                }
            }
        } catch (Throwable $exception) {
            error_log('InternPro company display error: ' . $exception->getMessage());
        }
    }
}

if ($companyName === '') {
    $companyName = 'Hiring Company';
}

$internshipTitle = (string) ($internship['title'] ?? 'Internship');
$internshipLocation = (string) ($internship['location'] ?? 'Location not specified');
$internshipMode = (string) ($internship['work_mode'] ?? 'Not specified');
$internshipType = (string) ($internship['internship_type'] ?? 'Not specified');
$internshipDescription = (string) ($internship['description'] ?? '');
$internshipCategory = (string) ($internship['category'] ?? 'Internship');
$internshipStipend = $internship['stipend'] ?? null;
$internshipDeadline = $internship['application_deadline'] ?? $internship['deadline'] ?? null;

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="#041224">
<title>Apply for Internship | InternPro</title>
<link rel="icon" type="image/jpeg" href="../assets/logo.jpg">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
:root{--navy:#071e3d;--deep:#041224;--blue:#0d3b66;--bright:#0077b6;--cyan:#00b4d8;--sky:#38bdf8;--white:#f4f8ff;--muted:#9fb4cc;--line:rgba(56,189,248,.18);--glass:rgba(9,34,64,.78);--danger:#ff647c;--success:#42e6b4}
*{box-sizing:border-box}
html{scroll-behavior:smooth}
body{margin:0;min-height:100vh;background:radial-gradient(ellipse at 12% 12%,rgba(0,180,216,.13),transparent 35%),radial-gradient(ellipse at 88% 28%,rgba(0,119,182,.15),transparent 38%),linear-gradient(135deg,#041224,#071e3d 65%,#031326);color:var(--white);font-family:'Poppins',sans-serif;overflow-x:hidden}
body:before{content:"";position:fixed;inset:0;pointer-events:none;opacity:.16;background-image:linear-gradient(rgba(56,189,248,.12) 1px,transparent 1px),linear-gradient(90deg,rgba(56,189,248,.12) 1px,transparent 1px);background-size:44px 44px;mask-image:linear-gradient(to bottom,#000,transparent 85%);z-index:-1}
a{color:inherit;text-decoration:none}
button,input,textarea{font:inherit}
button,a,input,textarea{outline-offset:4px}
.navbar{position:sticky;top:0;z-index:20;background:rgba(3,15,31,.92);backdrop-filter:blur(18px);border-bottom:1px solid rgba(56,189,248,.12)}
.nav-inner{max-width:1440px;margin:auto;padding:15px 5%;min-height:82px;display:flex;align-items:center;justify-content:space-between;gap:24px}
.brand{display:flex;align-items:center;gap:12px;font-family:'Space Grotesk',sans-serif;font-weight:700;font-size:25px;letter-spacing:-1px;white-space:nowrap}
.brand img{width:54px;height:54px;object-fit:contain;border-radius:50%;border:1px solid rgba(0,180,216,.55);box-shadow:0 0 20px rgba(0,180,216,.18);transition:transform .35s,box-shadow .35s}
.brand img:hover{transform:rotate(-7deg) scale(1.07);box-shadow:0 0 28px rgba(0,180,216,.4)}
.brand span{color:var(--cyan)}
.nav-links{display:flex;align-items:center;gap:9px;flex-wrap:wrap}
.nav-links a{display:flex;align-items:center;gap:9px;padding:14px 16px;border:1px solid transparent;border-radius:13px;color:#a7b9d0;font-size:14px;font-weight:600;transition:color .25s,background .25s,border-color .25s,transform .25s}
.nav-links a i{transition:transform .25s,color .25s}
.nav-links a:hover i{transform:translateY(-2px) scale(1.12);color:var(--cyan)}
.nav-links a:hover,.nav-links a.active{color:var(--cyan);background:rgba(0,180,216,.09);border-color:rgba(0,180,216,.2)}
.nav-links a:hover{transform:translateY(-2px)}
.nav-links .logout{border-color:var(--line);color:#d7e8f9}
.page{width:min(1320px,92%);margin:42px auto 80px}
.hero{position:relative;isolation:isolate;overflow:hidden;padding:clamp(30px,5vw,62px);border:1px solid rgba(56,189,248,.28);border-radius:32px;background:linear-gradient(125deg,rgba(16,61,101,.82),rgba(4,24,45,.94));box-shadow:0 24px 80px rgba(0,0,0,.16);animation:rise .7s ease both}
.hero:before,.hero:after{content:"";position:absolute;z-index:-1;border:1px solid rgba(0,180,216,.12);border-radius:50%;pointer-events:none}
.hero:before{width:360px;height:360px;right:-80px;top:-210px;box-shadow:0 0 0 25px rgba(0,180,216,.025),0 0 0 55px rgba(0,180,216,.02)}
.hero:after{width:160px;height:160px;right:9%;bottom:-125px}
.eyebrow{display:inline-flex;align-items:center;gap:10px;padding:10px 15px;border:1px solid rgba(0,180,216,.32);border-radius:30px;background:rgba(0,180,216,.08);color:#53dff4;font-size:12px;font-weight:800;letter-spacing:1.3px;text-transform:uppercase}
.eyebrow i{animation:iconFloat 2.5s ease-in-out infinite}
h1,h2,h3,p{margin-top:0}
h1{font-family:'Space Grotesk',sans-serif;font-size:clamp(34px,5vw,58px);line-height:1.13;letter-spacing:-2px;margin:22px 0 14px}
h1 span{background:linear-gradient(90deg,var(--cyan),var(--sky));background-clip:text;-webkit-background-clip:text;color:transparent}
.hero p{max-width:760px;color:#a9bfd7;line-height:1.9;margin-bottom:0;font-size:15px}
.section-heading{display:flex;align-items:flex-end;justify-content:space-between;gap:20px;margin:38px 0 18px}
.section-heading h2{font-family:'Space Grotesk',sans-serif;font-size:28px;letter-spacing:-.8px;margin:0 0 6px}
.section-heading p{color:var(--muted);font-size:13px;margin:0}
.layout{display:grid;grid-template-columns:minmax(0,1.3fr) minmax(300px,.7fr);gap:24px;align-items:start;margin-top:28px}
.card{border:1px solid var(--line);border-radius:24px;background:var(--glass);backdrop-filter:blur(16px);box-shadow:0 18px 55px rgba(0,0,0,.14);overflow:hidden;animation:rise .65s ease both}
.card-head{padding:23px 26px;border-bottom:1px solid rgba(56,189,248,.13);display:flex;align-items:center;gap:13px}
.head-icon{display:grid;place-items:center;width:45px;height:45px;flex:0 0 45px;border-radius:14px;color:var(--cyan);background:rgba(0,180,216,.1);border:1px solid rgba(0,180,216,.19);transition:transform .3s,box-shadow .3s}
.card:hover .head-icon{transform:translateY(-2px) rotate(-4deg);box-shadow:0 0 18px rgba(0,180,216,.14)}
.card-head h2{font-size:18px;margin:0 0 3px}
.card-head p{font-size:12px;color:var(--muted);margin:0}
.card-body{padding:26px}
.field{margin-bottom:22px}
.field label{display:block;margin-bottom:9px;color:#d9e9f8;font-size:13px;font-weight:600}
.optional{color:#7896b5;font-size:11px;font-weight:400}
.input-wrap{position:relative}
.input-wrap>i{position:absolute;left:16px;top:17px;color:var(--cyan);transition:transform .25s}
input[type=text],input[type=email],input[type=url],input[type=file],textarea{width:100%;border:1px solid rgba(112,161,202,.22);border-radius:13px;background:rgba(2,15,31,.7);color:var(--white);padding:15px 16px;transition:border-color .25s,box-shadow .25s,background .25s}
.input-wrap input{padding-left:45px}
textarea{min-height:170px;resize:vertical;line-height:1.7}
input:focus,textarea:focus{border-color:var(--cyan);box-shadow:0 0 0 3px rgba(0,180,216,.1);background:rgba(2,15,31,.9)}
input::placeholder,textarea::placeholder{color:#6f89a5}
input[type=file]{font-size:12px;color:#9bb4cc}
input[type=file]::file-selector-button{border:0;border-radius:8px;background:rgba(0,180,216,.14);color:#6ce8f7;padding:9px 12px;margin-right:12px;cursor:pointer;transition:background .2s}
input[type=file]::file-selector-button:hover{background:rgba(0,180,216,.24)}
.hint{font-size:11px;color:#7f9ab7;margin:8px 0 0;line-height:1.6}
.counter{font-size:11px;color:#7795b5;text-align:right;margin-top:6px}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:10px;min-height:49px;padding:13px 19px;border:1px solid transparent;border-radius:13px;font-size:13px;font-weight:700;cursor:pointer;transition:transform .25s,box-shadow .25s,background .25s,border-color .25s}
.btn i{transition:transform .25s}
.btn:hover{transform:translateY(-3px)}
.btn:hover i{transform:translateX(3px)}
.btn-primary{color:#031628;background:linear-gradient(110deg,var(--cyan),#32b9ef);box-shadow:0 8px 24px rgba(0,180,216,.13)}
.btn-primary:hover{box-shadow:0 12px 30px rgba(0,180,216,.25)}
.btn-secondary{color:#d7e8f9;background:rgba(16,48,79,.6);border-color:var(--line)}
.btn-secondary:hover{border-color:rgba(0,180,216,.45)}
.btn-block{width:100%}
.btn:disabled{opacity:.6;cursor:wait;transform:none}
.actions{display:flex;gap:12px;flex-wrap:wrap;margin-top:28px}
.alert{display:flex;gap:12px;align-items:flex-start;padding:15px 17px;margin-bottom:20px;border-radius:14px;font-size:13px;line-height:1.65;animation:rise .35s ease both}
.alert i{margin-top:3px}
.alert-error{border:1px solid rgba(255,100,124,.3);background:rgba(255,100,124,.08);color:#ffb5c1}
.alert-success{border:1px solid rgba(66,230,180,.28);background:rgba(66,230,180,.08);color:#8af3ce}
.internship-summary{position:sticky;top:105px}
.summary-cover{padding:25px;background:radial-gradient(circle at 95% 0,rgba(0,180,216,.16),transparent 48%),linear-gradient(135deg,rgba(13,59,102,.72),rgba(4,18,36,.8));border-bottom:1px solid var(--line)}
.summary-category{display:inline-flex;padding:7px 11px;border-radius:9px;background:rgba(0,180,216,.1);border:1px solid rgba(0,180,216,.2);color:#5ce2f4;font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.8px}
.summary-cover h2{font-family:'Space Grotesk',sans-serif;font-size:24px;line-height:1.35;margin:17px 0 8px;overflow-wrap:anywhere}
.company{display:flex;align-items:center;gap:9px;color:#a9bfd7;font-size:13px}
.company i{color:var(--cyan)}
.summary-details{padding:22px 25px}
.detail{display:flex;gap:12px;align-items:flex-start;padding:13px 0;border-bottom:1px solid rgba(56,189,248,.1);font-size:12px;color:#b4c8de}
.detail:last-child{border-bottom:0}
.detail i{width:18px;text-align:center;color:var(--cyan);margin-top:2px;transition:transform .25s}
.detail:hover i{transform:scale(1.2) rotate(-5deg)}
.detail strong{display:block;color:#e7f1fb;font-size:12px;margin-bottom:4px}
.description{color:#a8bfd7;font-size:12px;line-height:1.8;overflow-wrap:anywhere}
.status-chip{display:inline-flex;align-items:center;gap:8px;padding:8px 11px;border-radius:10px;background:rgba(255,190,92,.08);border:1px solid rgba(255,190,92,.2);color:#ffd18d;font-size:11px;font-weight:700}
.status-chip i{animation:iconFloat 2s ease-in-out infinite}
.empty-state{text-align:center;padding:30px 20px;color:#a7bfd8}
.empty-state i{font-size:34px;color:var(--cyan);margin-bottom:15px;animation:iconFloat 3s ease-in-out infinite}
.empty-state h2{font-size:18px;color:var(--white)}
.empty-state p{font-size:12px;line-height:1.8}
.footer{text-align:center;padding:22px 15px;color:#6685a5;font-size:11px}
.footer span{color:var(--cyan)}
@keyframes rise{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:translateY(0)}}
@keyframes iconFloat{0%,100%{transform:translateY(0)}50%{transform:translateY(-3px)}}
@media(max-width:1000px){.layout{grid-template-columns:1fr}.internship-summary{position:static}.nav-inner{align-items:flex-start;flex-direction:column}.nav-links{width:100%;gap:5px}.nav-links a{padding:11px 12px}.page{margin-top:28px}}
@media(max-width:600px){.nav-inner{padding:12px 4%;gap:12px}.brand{font-size:22px}.brand img{width:45px;height:45px}.nav-links{display:grid;grid-template-columns:repeat(2,minmax(0,1fr))}.nav-links a{justify-content:center;font-size:12px;padding:11px 8px}.page{width:92%;margin:22px auto 45px}.hero{padding:27px 22px;border-radius:23px}h1{letter-spacing:-1.3px}.card-head{padding:20px}.card-body{padding:20px}.section-heading{align-items:flex-start;flex-direction:column}.actions{flex-direction:column}.actions .btn{width:100%}}
@media(prefers-reduced-motion:reduce){*,*::before,*::after{animation-duration:.01ms!important;animation-iteration-count:1!important;scroll-behavior:auto!important;transition-duration:.01ms!important}}
</style>
</head>
<body>
<header class="navbar">
    <div class="nav-inner">
        <a class="brand" href="dashboard.php" aria-label="InternPro student dashboard">
            <img src="../assets/logo.jpg" alt="InternPro logo" onerror="this.style.display='none'">
            <span style="color:#f4f8ff">Intern<span>Pro</span></span>
        </a>
        <nav class="nav-links" aria-label="Student navigation">
            <a href="dashboard.php"><i class="fa-solid fa-border-all"></i> Dashboard</a>
            <a href="profile.php"><i class="fa-solid fa-circle-user"></i> My Profile</a>
            <a href="internships.php"><i class="fa-solid fa-briefcase"></i> Internships</a>
            <a href="applications.php"><i class="fa-solid fa-clipboard-check"></i> Applications</a>
            <a class="logout" href="../logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
        </nav>
    </div>
</header>

<main class="page">
    <section class="hero">
        <div class="eyebrow"><i class="fa-solid fa-paper-plane"></i> Take the next step</div>
        <h1>Apply for your next <span>opportunity.</span></h1>
        <p>Make your application count. Share your motivation, attach your resume, and take one step closer to your career goals.</p>
    </section>

    <div class="section-heading">
        <div>
            <h2>Internship application</h2>
            <p>Review the role and submit your application.</p>
        </div>
        <a class="btn btn-secondary" href="internships.php"><i class="fa-solid fa-arrow-left"></i> Back to internships</a>
    </div>

    <?php if ($error !== ''): ?>
        <div class="alert alert-error" role="alert">
            <i class="fa-solid fa-circle-exclamation"></i>
            <div><?= applyEscape($error) ?></div>
        </div>
    <?php endif; ?>

    <?php if ($success !== ''): ?>
        <div class="alert alert-success" role="status">
            <i class="fa-solid fa-circle-check"></i>
            <div><?= applyEscape($success) ?></div>
        </div>
    <?php endif; ?>

    <?php if ($internship): ?>
        <div class="layout">
            <section class="card">
                <div class="card-head">
                    <div class="head-icon"><i class="fa-solid fa-file-signature"></i></div>
                    <div>
                        <h2>Your application</h2>
                        <p>Complete the details below before submitting.</p>
                    </div>
                </div>
                <div class="card-body">
                    <?php if ($alreadyApplied): ?>
                        <div class="alert alert-error" role="status">
                            <i class="fa-solid fa-circle-info"></i>
                            <div>
                                <strong>You have already applied.</strong><br>
                                Current status: <?= applyEscape(ucwords(str_replace('_', ' ', (string) $existingApplication['status']))) ?>.
                            </div>
                        </div>
                        <a class="btn btn-primary btn-block" href="applications.php">
                            <i class="fa-solid fa-list-check"></i> Track my applications
                        </a>
                    <?php else: ?>
                        <form id="applicationForm" method="POST" action="apply.php?id=<?= (int) $internshipId ?>" enctype="multipart/form-data">
                            <input type="hidden" name="csrf_token" value="<?= applyEscape($csrfToken) ?>">
                            <input type="hidden" name="internship_id" value="<?= (int) $internshipId ?>">

                            <div class="field">
                                <label for="cover_letter">Cover letter <span class="optional">(optional)</span></label>
                                <textarea id="cover_letter" name="cover_letter" maxlength="10000" placeholder="Tell the company why you are interested in this internship and what you can contribute..."><?= applyEscape($coverLetter) ?></textarea>
                                <div class="counter"><span id="letterCount">0</span> / 10,000 characters</div>
                            </div>

                            <div class="field">
                                <label for="resume">Resume <span class="optional">(optional if not required by the employer)</span></label>
                                <div class="input-wrap">
                                    <i class="fa-solid fa-file-arrow-up"></i>
                                    <input id="resume" name="resume" type="file" accept=".pdf,.doc,.docx,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document">
                                </div>
                                <p class="hint">Accepted formats: PDF, DOC, DOCX. Maximum file size: 5 MB.</p>
                            </div>

                            <div class="alert" style="background:rgba(0,180,216,.06);border:1px solid rgba(0,180,216,.15);color:#a9c9e3">
                                <i class="fa-solid fa-shield-halved" style="color:var(--cyan)"></i>
                                <div>Check your details before submitting. You can track your application status from the Applications page.</div>
                            </div>

                            <div class="actions">
                                <button class="btn btn-primary" id="submitButton" type="submit">
                                    Submit application <i class="fa-solid fa-arrow-right"></i>
                                </button>
                                <a class="btn btn-secondary" href="internships.php">
                                    <i class="fa-solid fa-xmark"></i> Cancel
                                </a>
                            </div>
                        </form>
                    <?php endif; ?>
                </div>
            </section>

            <aside class="card internship-summary">
                <div class="summary-cover">
                    <span class="summary-category"><?= applyEscape($internshipCategory) ?></span>
                    <h2><?= applyEscape($internshipTitle) ?></h2>
                    <div class="company"><i class="fa-solid fa-building"></i> <?= applyEscape($companyName) ?></div>
                </div>
                <div class="summary-details">
                    <div class="detail">
                        <i class="fa-solid fa-location-dot"></i>
                        <div><strong>Location</strong><?= applyEscape($internshipLocation) ?></div>
                    </div>
                    <div class="detail">
                        <i class="fa-solid fa-laptop"></i>
                        <div><strong>Work mode</strong><?= applyEscape(ucfirst($internshipMode)) ?></div>
                    </div>
                    <div class="detail">
                        <i class="fa-solid fa-clock"></i>
                        <div><strong>Internship type</strong><?= applyEscape(ucwords(str_replace('_', ' ', $internshipType))) ?></div>
                    </div>
                    <?php if ($internshipStipend !== null && $internshipStipend !== ''): ?>
                        <div class="detail">
                            <i class="fa-solid fa-wallet"></i>
                            <div><strong>Stipend</strong><?= applyEscape(is_numeric($internshipStipend) ? '₹' . number_format((float) $internshipStipend) : $internshipStipend) ?></div>
                        </div>
                    <?php endif; ?>
                    <?php if ($internshipDeadline && strtotime((string) $internshipDeadline)): ?>
                        <div class="detail">
                            <i class="fa-solid fa-calendar-days"></i>
                            <div><strong>Application deadline</strong><?= applyEscape(date('d M Y', strtotime((string) $internshipDeadline))) ?></div>
                        </div>
                    <?php endif; ?>
                    <?php if ($internshipDescription !== ''): ?>
                        <div class="detail">
                            <i class="fa-solid fa-align-left"></i>
                            <div>
                                <strong>About this internship</strong>
                                <div class="description"><?= nl2br(applyEscape($internshipDescription)) ?></div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if ($alreadyApplied): ?>
                        <div style="margin-top:17px">
                            <span class="status-chip"><i class="fa-solid fa-clock"></i> Application already submitted</span>
                        </div>
                    <?php else: ?>
                        <div style="margin-top:17px">
                            <span class="status-chip"><i class="fa-solid fa-circle-check"></i> Ready for your application</span>
                        </div>
                    <?php endif; ?>
                </div>
            </aside>
        </div>
    <?php else: ?>
        <section class="card empty-state">
            <div style="padding:42px 22px">
                <i class="fa-solid fa-briefcase"></i>
                <h2>Internship unavailable</h2>
                <p>Choose an internship from the listings page to continue with your application.</p>
                <a class="btn btn-primary" href="internships.php"><i class="fa-solid fa-magnifying-glass"></i> Explore internships</a>
            </div>
        </section>
    <?php endif; ?>
</main>

<footer class="footer">Built for your next step with <span>InternPro</span>.</footer>

<script>
(function () {
    const letter = document.getElementById('cover_letter');
    const counter = document.getElementById('letterCount');
    const form = document.getElementById('applicationForm');
    const submitButton = document.getElementById('submitButton');
    const resume = document.getElementById('resume');

    if (letter && counter) {
        const updateCount = function () {
            counter.textContent = letter.value.length.toLocaleString();
        };
        letter.addEventListener('input', updateCount);
        updateCount();
    }

    if (resume) {
        resume.addEventListener('change', function () {
            if (resume.files.length && resume.files[0].size > 5 * 1024 * 1024) {
                alert('Your resume must be 5 MB or smaller.');
                resume.value = '';
            }
        });
    }

    if (form && submitButton) {
        form.addEventListener('submit', function (event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                form.reportValidity();
                return;
            }

            if (resume && resume.files.length && resume.files[0].size > 5 * 1024 * 1024) {
                event.preventDefault();
                alert('Your resume must be 5 MB or smaller.');
                return;
            }

            submitButton.disabled = true;
            submitButton.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Submitting...';
        });
    }
})();
</script>
</body>
</html>
