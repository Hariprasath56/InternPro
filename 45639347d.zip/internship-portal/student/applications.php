
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/database.php';

if (!isset($_SESSION['user_id'], $_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header('Location: ../login.php');
    exit;
}

if (!isset($pdo) || !($pdo instanceof PDO)) {
    http_response_code(500);
    exit('Database connection is unavailable.');
}

$userId = (int) $_SESSION['user_id'];
$studentId = null;
$applications = [];
$errorMessage = '';
$successMessage = '';
$search = trim((string) ($_GET['search'] ?? ''));
$statusFilter = trim((string) ($_GET['status'] ?? 'all'));

if (empty($_SESSION['applications_csrf'])) {
    $_SESSION['applications_csrf'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['applications_csrf'];

function appEscape($value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function appColumns(PDO $pdo, string $table): array
{
    $allowedTables = ['students', 'applications', 'internships', 'companies'];

    if (!in_array($table, $allowedTables, true)) {
        return [];
    }

    try {
        $stmt = $pdo->query("SHOW COLUMNS FROM `$table`");
        $columns = [];

        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $column) {
            $columns[] = $column['Field'];
        }

        return $columns;
    } catch (Throwable $e) {
        error_log('InternPro applications schema check failed: ' . $e->getMessage());
        return [];
    }
}

function appHas(array $columns, string $column): bool
{
    return in_array($column, $columns, true);
}

function appFirstColumn(array $columns, array $candidates): ?string
{
    foreach ($candidates as $candidate) {
        if (appHas($columns, $candidate)) {
            return $candidate;
        }
    }

    return null;
}

function appSelectColumn(array $columns, string $column, string $alias, string $tableAlias): string
{
    if (appHas($columns, $column)) {
        return "$tableAlias.`$column` AS `$alias`";
    }

    return "NULL AS `$alias`";
}

function appStatusLabel(string $status): string
{
    $labels = [
        'applied' => 'Applied',
        'under_review' => 'Under Review',
        'shortlisted' => 'Shortlisted',
        'interview' => 'Interview',
        'selected' => 'Selected',
        'rejected' => 'Rejected',
        'withdrawn' => 'Withdrawn'
    ];

    return $labels[$status] ?? ucwords(str_replace('_', ' ', $status));
}

function appStatusClass(string $status): string
{
    $classes = [
        'applied' => 'status-applied',
        'under_review' => 'status-review',
        'shortlisted' => 'status-shortlisted',
        'interview' => 'status-interview',
        'selected' => 'status-selected',
        'rejected' => 'status-rejected',
        'withdrawn' => 'status-withdrawn'
    ];

    return $classes[$status] ?? 'status-default';
}

try {
    $studentColumns = appColumns($pdo, 'students');
    $applicationColumns = appColumns($pdo, 'applications');
    $internshipColumns = appColumns($pdo, 'internships');
    $companyColumns = appColumns($pdo, 'companies');

    if (
        !appHas($studentColumns, 'id') ||
        !appHas($studentColumns, 'user_id') ||
        !appHas($applicationColumns, 'id') ||
        !appHas($applicationColumns, 'student_id') ||
        !appHas($applicationColumns, 'internship_id') ||
        !appHas($internshipColumns, 'id') ||
        !appHas($internshipColumns, 'title')
    ) {
        throw new RuntimeException('Required application database columns are missing.');
    }

    $studentStmt = $pdo->prepare(
        'SELECT `id` FROM `students` WHERE `user_id` = :user_id LIMIT 1'
    );
    $studentStmt->execute(['user_id' => $userId]);
    $student = $studentStmt->fetch(PDO::FETCH_ASSOC);

    if ($student) {
        $studentId = (int) $student['id'];
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $postedToken = (string) ($_POST['csrf_token'] ?? '');
        $action = (string) ($_POST['action'] ?? '');

        if (!hash_equals($csrfToken, $postedToken)) {
            $errorMessage = 'Your session has expired. Refresh the page and try again.';
        } elseif ($action === 'withdraw') {
            $applicationId = filter_input(INPUT_POST, 'application_id', FILTER_VALIDATE_INT);

            if (!$applicationId || $applicationId < 1) {
                $errorMessage = 'Invalid application selected.';
            } elseif ($studentId === null) {
                $errorMessage = 'Your student profile is not linked to your account. Complete your student profile first.';
            } elseif (!appHas($applicationColumns, 'status')) {
                $errorMessage = 'Application withdrawal is unavailable because the status field is missing.';
            } else {
                $checkStmt = $pdo->prepare(
                    'SELECT `id`, `status`
                     FROM `applications`
                     WHERE `id` = :application_id
                       AND `student_id` = :student_id
                     LIMIT 1'
                );
                $checkStmt->execute([
                    'application_id' => $applicationId,
                    'student_id' => $studentId
                ]);

                $applicationToWithdraw = $checkStmt->fetch(PDO::FETCH_ASSOC);

                if (!$applicationToWithdraw) {
                    $errorMessage = 'Application not found in your account.';
                } elseif (in_array(
                    strtolower((string) $applicationToWithdraw['status']),
                    ['withdrawn', 'rejected', 'selected'],
                    true
                )) {
                    $errorMessage = 'This application can no longer be withdrawn.';
                } else {
                    $withdrawStmt = $pdo->prepare(
                        "UPDATE `applications`
                         SET `status` = 'withdrawn'
                         WHERE `id` = :application_id
                           AND `student_id` = :student_id
                           AND `status` NOT IN ('withdrawn', 'rejected', 'selected')"
                    );

                    $withdrawStmt->execute([
                        'application_id' => $applicationId,
                        'student_id' => $studentId
                    ]);

                    if ($withdrawStmt->rowCount() > 0) {
                        $_SESSION['applications_flash_success'] = 'Application withdrawn successfully.';
                    } else {
                        $_SESSION['applications_flash_error'] = 'The application status could not be changed.';
                    }

                    $redirectQuery = [];

                    if ($search !== '') {
                        $redirectQuery['search'] = $search;
                    }

                    if ($statusFilter !== 'all') {
                        $redirectQuery['status'] = $statusFilter;
                    }

                    $redirectUrl = 'applications.php';

                    if ($redirectQuery) {
                        $redirectUrl .= '?' . http_build_query($redirectQuery);
                    }

                    header('Location: ' . $redirectUrl);
                    exit;
                }
            }
        } else {
            $errorMessage = 'Invalid request.';
        }
    }

    if (isset($_SESSION['applications_flash_success'])) {
        $successMessage = (string) $_SESSION['applications_flash_success'];
        unset($_SESSION['applications_flash_success']);
    }

    if (isset($_SESSION['applications_flash_error'])) {
        $errorMessage = (string) $_SESSION['applications_flash_error'];
        unset($_SESSION['applications_flash_error']);
    }

    if ($studentId !== null) {
        $companyNameColumn = appFirstColumn(
            $companyColumns,
            ['company_name', 'name', 'business_name']
        );

        $companyJoin = '';
        $companyNameSelect = "'Company' AS company_name";

        if (
            $companyNameColumn !== null &&
            appHas($internshipColumns, 'company_id') &&
            appHas($companyColumns, 'id')
        ) {
            $companyJoin = ' LEFT JOIN `companies` c ON c.`id` = i.`company_id` ';
            $companyNameSelect = 'COALESCE(c.`' . $companyNameColumn . "`, 'Company') AS company_name";
        }

        $selectParts = [
            'a.`id` AS application_id',
            'i.`id` AS internship_id',
            'i.`title` AS internship_title',
            $companyNameSelect,
            appSelectColumn($internshipColumns, 'category', 'category', 'i'),
            appSelectColumn($internshipColumns, 'location', 'location', 'i'),
            appSelectColumn($internshipColumns, 'work_mode', 'work_mode', 'i'),
            appSelectColumn($internshipColumns, 'internship_type', 'internship_type', 'i'),
            appSelectColumn($internshipColumns, 'stipend', 'stipend', 'i'),
            appSelectColumn($applicationColumns, 'status', 'status', 'a'),
            appSelectColumn($applicationColumns, 'applied_at', 'applied_at', 'a'),
            appSelectColumn($applicationColumns, 'cover_letter', 'cover_letter', 'a')
        ];

        $sql = 'SELECT ' . implode(', ', $selectParts) . '
                FROM `applications` a
                INNER JOIN `internships` i ON i.`id` = a.`internship_id`
                ' . $companyJoin . '
                WHERE a.`student_id` = :student_id
                ORDER BY ' .
                (appHas($applicationColumns, 'applied_at')
                    ? 'a.`applied_at`'
                    : 'a.`id`') .
                ' DESC';

        $stmt = $pdo->prepare($sql);
        $stmt->execute(['student_id' => $studentId]);
        $applications = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (Throwable $e) {
    error_log('InternPro applications page error: ' . $e->getMessage());
    $errorMessage = 'Unable to load your applications. Please verify your database setup and try again.';
}

$validStatuses = [
    'all',
    'applied',
    'under_review',
    'shortlisted',
    'interview',
    'selected',
    'rejected',
    'withdrawn'
];

if (!in_array($statusFilter, $validStatuses, true)) {
    $statusFilter = 'all';
}

$filteredApplications = array_values(array_filter(
    $applications,
    function (array $application) use ($search, $statusFilter): bool {
        $status = strtolower((string) ($application['status'] ?? 'applied'));

        if ($statusFilter !== 'all' && $status !== $statusFilter) {
            return false;
        }

        if ($search !== '') {
            $haystack = implode(' ', [
                $application['internship_title'] ?? '',
                $application['company_name'] ?? '',
                $application['category'] ?? '',
                $application['location'] ?? ''
            ]);

            if (stripos($haystack, $search) === false) {
                return false;
            }
        }

        return true;
    }
));

$totalApplications = count($applications);
$activeApplications = count(array_filter($applications, function (array $application): bool {
    return !in_array(
        strtolower((string) ($application['status'] ?? 'applied')),
        ['withdrawn', 'rejected', 'selected'],
        true
    );
}));

$selectedApplications = count(array_filter($applications, function (array $application): bool {
    return strtolower((string) ($application['status'] ?? '')) === 'selected';
}));

$withdrawnApplications = count(array_filter($applications, function (array $application): bool {
    return strtolower((string) ($application['status'] ?? '')) === 'withdrawn';
}));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="#041224">
<title>My Applications | InternPro</title>
<link rel="icon" type="image/jpeg" href="../assets/logo.jpg">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
:root {
    --navy: #041224;
    --navy-2: #071e3d;
    --blue: #0d3b66;
    --blue-2: #075985;
    --cyan: #00b4d8;
    --cyan-light: #38bdf8;
    --text: #f1f7ff;
    --muted: #9db3cc;
    --border: rgba(56, 189, 248, .19);
    --glass: rgba(8, 35, 65, .78);
    --red: #ff5d73;
    --red-dark: #b91c3a;
}
* { box-sizing: border-box; }
html { scroll-behavior: smooth; }
body {
    margin: 0;
    min-height: 100vh;
    color: var(--text);
    background:
        radial-gradient(ellipse at 12% 15%, rgba(0,180,216,.12), transparent 35%),
        radial-gradient(ellipse at 90% 30%, rgba(13,59,102,.35), transparent 40%),
        linear-gradient(135deg, var(--navy), #062344 58%, #041224);
    font-family: 'Poppins', sans-serif;
    overflow-x: hidden;
}
a { color: inherit; text-decoration: none; }
button, input, select { font: inherit; }
button, a, input, select { -webkit-tap-highlight-color: transparent; }
.ambient {
    position: fixed;
    width: 320px;
    height: 320px;
    border-radius: 50%;
    filter: blur(85px);
    opacity: .12;
    pointer-events: none;
    z-index: -1;
    animation: floatOrb 12s ease-in-out infinite alternate;
}
.ambient.one { top: 15%; left: -180px; background: var(--cyan); }
.ambient.two { right: -190px; bottom: 4%; background: #1687d9; animation-delay: -4s; }
@keyframes floatOrb {
    from { transform: translate3d(0,0,0) scale(1); }
    to { transform: translate3d(40px,-30px,0) scale(1.12); }
}
.navbar {
    position: sticky;
    top: 0;
    z-index: 20;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 24px;
    min-height: 88px;
    padding: 14px clamp(20px, 5vw, 80px);
    background: rgba(3, 16, 32, .93);
    border-bottom: 1px solid rgba(56,189,248,.13);
    backdrop-filter: blur(18px);
}
.brand {
    display: inline-flex;
    align-items: center;
    gap: 12px;
    flex-shrink: 0;
    font-size: 24px;
    font-weight: 800;
    letter-spacing: -.8px;
}
.brand-logo {
    width: 49px;
    height: 49px;
    min-width: 49px;
    object-fit: contain;
    display: block;
    border-radius: 50%;
    border: 1px solid rgba(0,180,216,.55);
    box-shadow: 0 0 15px rgba(0,180,216,.2);
    transition: transform .3s ease, filter .3s ease;
}
.brand-logo:hover {
    transform: scale(1.08) rotate(-4deg);
    filter: drop-shadow(0 0 8px rgba(0,180,216,.6));
}
.brand-name span { color: var(--cyan); }
.nav-links { display: flex; align-items: center; gap: 8px; }
.nav-link {
    position: relative;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    padding: 14px 17px;
    border: 1px solid transparent;
    border-radius: 14px;
    color: var(--muted);
    font-size: 13px;
    font-weight: 700;
    white-space: nowrap;
    transition: color .25s ease, background .25s ease, border-color .25s ease, transform .25s ease;
}
.nav-link i { transition: transform .25s ease, color .25s ease; }
.nav-link:hover, .nav-link.active {
    color: #4ce8ff;
    background: rgba(0,180,216,.08);
    border-color: rgba(0,180,216,.2);
    transform: translateY(-2px);
}
.nav-link:hover i { transform: translateY(-2px) scale(1.1); color: var(--cyan-light); }
.nav-link.active::after {
    content: '';
    position: absolute;
    bottom: -12px;
    left: 25%;
    width: 50%;
    height: 3px;
    border-radius: 8px;
    background: var(--cyan);
    box-shadow: 0 0 12px var(--cyan);
}
.container { width: min(1390px, 92%); margin: 0 auto; padding: 42px 0 70px; }
.hero {
    position: relative;
    isolation: isolate;
    overflow: hidden;
    padding: clamp(28px, 5vw, 60px);
    border: 1px solid rgba(56,189,248,.25);
    border-radius: 32px;
    background: linear-gradient(115deg, rgba(15,61,101,.86), rgba(4,24,45,.82));
    box-shadow: 0 25px 80px rgba(0,0,0,.14), inset 0 1px 0 rgba(255,255,255,.03);
    animation: riseIn .7s ease both;
}
.hero::before {
    content: '';
    position: absolute;
    z-index: -1;
    width: 350px;
    height: 350px;
    right: -100px;
    top: -230px;
    border: 1px solid rgba(0,180,216,.18);
    border-radius: 50%;
    box-shadow: 0 0 0 30px rgba(0,180,216,.025), 0 0 0 60px rgba(0,180,216,.02);
}
.eyebrow {
    display: inline-flex;
    align-items: center;
    gap: 9px;
    padding: 10px 15px;
    border: 1px solid rgba(0,180,216,.3);
    border-radius: 50px;
    background: rgba(0,180,216,.07);
    color: #51e4f8;
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 1.1px;
    text-transform: uppercase;
}
.eyebrow i { animation: iconPulse 2s ease-in-out infinite; }
h1 {
    margin: 24px 0 10px;
    font-size: clamp(32px, 4.8vw, 59px);
    line-height: 1.14;
    letter-spacing: -2px;
}
h1 span { color: var(--cyan); }
.hero p { max-width: 730px; margin: 0; color: #a8bfd8; line-height: 1.9; font-size: 15px; }
.stats { display: flex; flex-wrap: wrap; gap: 12px; margin-top: 28px; }
.stat {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 13px 17px;
    border: 1px solid var(--border);
    border-radius: 14px;
    background: rgba(2,18,35,.48);
    color: #d4e5f8;
    font-size: 12px;
}
.stat i { color: var(--cyan); transition: transform .25s ease; }
.stat:hover i { transform: scale(1.2) rotate(-8deg); }
.stat strong { color: #4be6f7; font-size: 15px; }
.section-heading {
    display: flex;
    align-items: end;
    justify-content: space-between;
    gap: 20px;
    margin: 42px 0 22px;
}
.section-heading h2 { margin: 0 0 6px; font-size: clamp(23px, 3vw, 33px); letter-spacing: -.8px; }
.section-heading p { margin: 0; color: var(--muted); font-size: 13px; }
.result-count {
    padding: 10px 14px;
    color: #55e5f7;
    background: rgba(0,180,216,.07);
    border: 1px solid var(--border);
    border-radius: 12px;
    font-size: 12px;
    white-space: nowrap;
}
.filters {
    display: grid;
    grid-template-columns: minmax(220px, 1fr) minmax(180px, 240px) auto auto;
    align-items: center;
    gap: 12px;
    padding: 18px;
    margin-bottom: 24px;
    border: 1px solid var(--border);
    border-radius: 22px;
    background: rgba(8,35,65,.75);
}
.search-wrap { position: relative; }
.search-wrap i { position: absolute; top: 50%; left: 16px; transform: translateY(-50%); color: #42dff5; }
.search-wrap input, .filters select {
    width: 100%;
    min-height: 49px;
    outline: none;
    border: 1px solid rgba(56,189,248,.18);
    border-radius: 13px;
    color: var(--text);
    background: #04172d;
    transition: border-color .25s ease, box-shadow .25s ease;
}
.search-wrap input { padding: 13px 15px 13px 44px; }
.filters select { padding: 12px; }
.filters input:focus, .filters select:focus {
    border-color: var(--cyan);
    box-shadow: 0 0 0 3px rgba(0,180,216,.1);
}
.filters select option { background: #04172d; color: white; }
.btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 9px;
    min-height: 46px;
    padding: 12px 17px;
    border: 1px solid transparent;
    border-radius: 13px;
    cursor: pointer;
    font-size: 12px;
    font-weight: 800;
    transition: transform .25s ease, box-shadow .25s ease, background .25s ease, border-color .25s ease;
}
.btn i { transition: transform .25s ease; }
.btn:hover { transform: translateY(-3px); }
.btn:hover i { transform: scale(1.12); }
.btn-primary {
    color: #031424;
    background: linear-gradient(100deg, var(--cyan), #35b7f0);
    box-shadow: 0 8px 22px rgba(0,180,216,.14);
}
.btn-primary:hover { box-shadow: 0 12px 27px rgba(0,180,216,.28); }
.btn-clear { color: #4ce5f8; background: transparent; border-color: var(--border); }
.applications-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 20px; }
.application-card {
    position: relative;
    overflow: hidden;
    padding: 25px;
    border: 1px solid rgba(56,189,248,.2);
    border-radius: 23px;
    background: linear-gradient(145deg, rgba(10,43,76,.92), rgba(4,22,42,.91));
    box-shadow: 0 15px 38px rgba(0,0,0,.12);
    animation: riseIn .55s ease both;
    transition: transform .3s ease, border-color .3s ease, box-shadow .3s ease;
}
.application-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 22px;
    right: 22px;
    height: 1px;
    background: linear-gradient(90deg, transparent, rgba(0,180,216,.65), transparent);
}
.application-card:hover {
    transform: translateY(-5px);
    border-color: rgba(0,180,216,.43);
    box-shadow: 0 22px 44px rgba(0,0,0,.2);
}
.card-top { display: flex; align-items: start; justify-content: space-between; gap: 15px; }
.company-mark {
    display: grid;
    place-items: center;
    width: 52px;
    height: 52px;
    flex-shrink: 0;
    border: 1px solid rgba(0,180,216,.27);
    border-radius: 16px;
    background: rgba(0,180,216,.09);
    color: #4be5f7;
    font-size: 21px;
    transition: transform .3s ease, box-shadow .3s ease;
}
.application-card:hover .company-mark { transform: rotate(-5deg) scale(1.05); box-shadow: 0 0 18px rgba(0,180,216,.13); }
.card-title { min-width: 0; flex: 1; }
.card-title h3 { margin: 1px 0 6px; font-size: 18px; line-height: 1.45; overflow-wrap: anywhere; }
.card-title p { margin: 0; color: #9db8d4; font-size: 12px; }
.status {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    padding: 8px 11px;
    border: 1px solid transparent;
    border-radius: 50px;
    font-size: 10px;
    font-weight: 800;
    white-space: nowrap;
}
.status::before { content: ''; width: 6px; height: 6px; border-radius: 50%; background: currentColor; }
.status-applied { color: #51dff2; background: rgba(0,180,216,.1); border-color: rgba(0,180,216,.2); }
.status-review { color: #8fc9ff; background: rgba(56,150,248,.1); border-color: rgba(56,150,248,.2); }
.status-shortlisted { color: #a9a1ff; background: rgba(139,92,246,.12); border-color: rgba(139,92,246,.25); }
.status-interview { color: #63e5b0; background: rgba(16,185,129,.1); border-color: rgba(16,185,129,.2); }
.status-selected { color: #5ee6a8; background: rgba(16,185,129,.1); border-color: rgba(16,185,129,.2); }
.status-rejected, .status-withdrawn { color: #ff8495; background: rgba(255,70,100,.1); border-color: rgba(255,93,115,.22); }
.status-default { color: #bdcce0; background: rgba(157,179,204,.08); border-color: rgba(157,179,204,.16); }
.card-meta { display: flex; flex-wrap: wrap; gap: 10px 17px; margin: 23px 0 17px; }
.meta-item { display: inline-flex; align-items: center; gap: 8px; color: #afc3da; font-size: 11px; }
.meta-item i { color: var(--cyan); transition: transform .25s ease; }
.meta-item:hover i { transform: translateY(-2px); }
.card-divider { height: 1px; margin: 18px 0; background: rgba(56,189,248,.13); }
.card-footer { display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 13px; }
.applied-date { color: #8da9c5; font-size: 11px; }
.card-actions { display: flex; align-items: center; flex-wrap: wrap; gap: 10px; }
.btn-details {
    color: #bcecff;
    background: rgba(0,180,216,.08);
    border-color: rgba(0,180,216,.2);
}
.btn-details:hover { background: rgba(0,180,216,.16); }
.btn-withdraw {
    position: relative;
    overflow: hidden;
    color: #fff0f2;
    background: linear-gradient(110deg, #a91e3a, #e3425d);
    border-color: rgba(255,115,135,.48);
    box-shadow: 0 5px 17px rgba(220,38,68,.16);
    animation: withdrawGlow 2.8s ease-in-out infinite;
}
.btn-withdraw::before {
    content: '';
    position: absolute;
    top: -60%;
    left: -80%;
    width: 45%;
    height: 220%;
    transform: rotate(25deg);
    background: rgba(255,255,255,.18);
    transition: left .45s ease;
}
.btn-withdraw:hover {
    background: linear-gradient(110deg, #c51f43, #ff536d);
    border-color: #ff8293;
    box-shadow: 0 9px 25px rgba(255,55,85,.3);
    animation: none;
}
.btn-withdraw:hover::before { left: 140%; }
.btn-withdraw:hover i { transform: rotate(-12deg) scale(1.15); }
.btn-withdraw:active { transform: scale(.96); }
.btn-withdraw:focus-visible, .btn:focus-visible, .nav-link:focus-visible {
    outline: 2px solid var(--cyan-light);
    outline-offset: 3px;
}
.btn-disabled {
    color: #8ba0b6;
    background: rgba(140,160,185,.08);
    border-color: rgba(140,160,185,.13);
    cursor: not-allowed;
}
.btn-disabled:hover { transform: none; }
.alert {
    display: flex;
    align-items: start;
    gap: 11px;
    margin: 20px 0;
    padding: 15px 17px;
    border-radius: 14px;
    font-size: 13px;
    line-height: 1.7;
    animation: riseIn .3s ease both;
}
.alert i { margin-top: 3px; }
.alert-error { color: #ffc0ca; border: 1px solid rgba(255,93,115,.25); background: rgba(185,28,58,.12); }
.alert-success { color: #a3f4ce; border: 1px solid rgba(52,211,153,.25); background: rgba(16,185,129,.1); }
.empty-state {
    grid-column: 1 / -1;
    padding: 60px 24px;
    text-align: center;
    border: 1px dashed rgba(56,189,248,.27);
    border-radius: 24px;
    background: rgba(7,30,61,.42);
}
.empty-icon {
    display: grid;
    place-items: center;
    width: 76px;
    height: 76px;
    margin: 0 auto 18px;
    border: 1px solid rgba(0,180,216,.22);
    border-radius: 23px;
    background: rgba(0,180,216,.08);
    color: var(--cyan);
    font-size: 28px;
    animation: iconPulse 2.5s ease-in-out infinite;
}
.empty-state h3 { margin: 0 0 9px; font-size: 22px; }
.empty-state p { max-width: 480px; margin: 0 auto 23px; color: var(--muted); font-size: 13px; line-height: 1.8; }
.footer { padding: 25px 15px; border-top: 1px solid rgba(56,189,248,.12); color: #819bb6; text-align: center; font-size: 11px; }
.footer span { color: var(--cyan); }
.modal-backdrop {
    position: fixed;
    inset: 0;
    z-index: 100;
    display: none;
    align-items: center;
    justify-content: center;
    padding: 20px;
    background: rgba(0,8,18,.78);
    backdrop-filter: blur(9px);
}
.modal-backdrop.open { display: flex; animation: fadeIn .2s ease both; }
.confirm-modal {
    width: min(450px, 100%);
    padding: 30px;
    border: 1px solid rgba(255,93,115,.32);
    border-radius: 24px;
    background: linear-gradient(145deg, #10253d, #071426);
    box-shadow: 0 25px 90px rgba(0,0,0,.45);
    animation: modalIn .25s ease both;
}
.modal-icon {
    display: grid;
    place-items: center;
    width: 60px;
    height: 60px;
    margin-bottom: 18px;
    border: 1px solid rgba(255,93,115,.3);
    border-radius: 19px;
    color: #ff8293;
    background: rgba(255,93,115,.1);
    font-size: 23px;
    animation: iconPulse 2.5s ease-in-out infinite;
}
.confirm-modal h2 { margin: 0 0 10px; font-size: 23px; }
.confirm-modal p { margin: 0; color: #a7bdd4; font-size: 13px; line-height: 1.8; }
.modal-actions { display: flex; gap: 10px; margin-top: 25px; }
.modal-actions button { flex: 1; }
.btn-cancel { color: #c6d8eb; background: rgba(157,179,204,.08); border-color: rgba(157,179,204,.2); }
@keyframes riseIn { from { opacity: 0; transform: translateY(15px); } to { opacity: 1; transform: translateY(0); } }
@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
@keyframes modalIn { from { opacity: 0; transform: translateY(12px) scale(.97); } to { opacity: 1; transform: translateY(0) scale(1); } }
@keyframes iconPulse { 0%,100% { transform: scale(1); } 50% { transform: scale(1.08); } }
@keyframes withdrawGlow {
    0%,100% { box-shadow: 0 5px 17px rgba(220,38,68,.13); }
    50% { box-shadow: 0 5px 23px rgba(255,55,85,.29); }
}
@media (max-width: 1050px) {
    .navbar { padding-inline: 3%; }
    .nav-link { padding: 12px 10px; font-size: 12px; }
    .filters { grid-template-columns: 1fr 1fr; }
    .filters .btn { width: 100%; }
}
@media (max-width: 760px) {
    .navbar { align-items: flex-start; flex-direction: column; gap: 12px; padding: 13px 5%; }
    .brand { font-size: 22px; }
    .nav-links { width: 100%; gap: 5px; overflow-x: auto; padding-bottom: 5px; }
    .nav-link { flex-shrink: 0; padding: 11px 12px; }
    .nav-link.active::after { bottom: -6px; }
    .container { width: 92%; padding-top: 25px; }
    .hero { border-radius: 23px; }
    .applications-grid { grid-template-columns: 1fr; }
    .section-heading { align-items: flex-start; }
    .application-card { padding: 20px; }
}
@media (max-width: 480px) {
    .filters { grid-template-columns: 1fr; padding: 13px; }
    .card-top { flex-wrap: wrap; }
    .card-title { min-width: calc(100% - 70px); }
    .card-top .status { margin-left: 0; }
    .card-footer { align-items: flex-start; flex-direction: column; }
    .card-actions { width: 100%; }
    .card-actions .btn { flex: 1; }
    .stats { flex-direction: column; align-items: stretch; }
    .stat { justify-content: space-between; }
    .modal-actions { flex-direction: column; }
}
@media (prefers-reduced-motion: reduce) {
    *, *::before, *::after {
        scroll-behavior: auto !important;
        animation-duration: .01ms !important;
        animation-iteration-count: 1 !important;
        transition-duration: .01ms !important;
    }
}
</style>
</head>
<body>
<div class="ambient one"></div>
<div class="ambient two"></div>

<header class="navbar">
    <a class="brand" href="dashboard.php" aria-label="InternPro Dashboard">
        <img class="brand-logo" src="../assets/logo.jpg" alt="InternPro Logo" width="49" height="49">
        <span class="brand-name">Intern<span>Pro</span></span>
    </a>
    <nav class="nav-links" aria-label="Student navigation">
        <a class="nav-link" href="dashboard.php"><i class="fa-solid fa-grip"></i> Dashboard</a>
        <a class="nav-link" href="profile.php"><i class="fa-solid fa-circle-user"></i> My Profile</a>
        <a class="nav-link" href="internships.php"><i class="fa-solid fa-briefcase"></i> Internships</a>
        <a class="nav-link active" href="applications.php" aria-current="page"><i class="fa-solid fa-clipboard-check"></i> Applications</a>
        <a class="nav-link" href="../logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
    </nav>
</header>

<main class="container">
    <section class="hero">
        <div class="eyebrow"><i class="fa-solid fa-paper-plane"></i> Your career journey</div>
        <h1>Track your <span>applications.</span></h1>
        <p>Every opportunity has a story. Follow your application progress, check recruiter decisions, and manage your internship journey in one place.</p>
        <div class="stats">
            <div class="stat"><i class="fa-solid fa-layer-group"></i><span>Total applications</span><strong><?= $totalApplications ?></strong></div>
            <div class="stat"><i class="fa-solid fa-hourglass-half"></i><span>In progress</span><strong><?= $activeApplications ?></strong></div>
            <div class="stat"><i class="fa-solid fa-circle-check"></i><span>Selected</span><strong><?= $selectedApplications ?></strong></div>
            <div class="stat"><i class="fa-solid fa-ban"></i><span>Withdrawn</span><strong><?= $withdrawnApplications ?></strong></div>
        </div>
    </section>

    <?php if ($errorMessage !== ''): ?>
        <div class="alert alert-error" role="alert">
            <i class="fa-solid fa-circle-exclamation"></i>
            <div><?= appEscape($errorMessage) ?></div>
        </div>
    <?php endif; ?>

    <?php if ($successMessage !== ''): ?>
        <div class="alert alert-success" role="status">
            <i class="fa-solid fa-circle-check"></i>
            <div><?= appEscape($successMessage) ?></div>
        </div>
    <?php endif; ?>

    <section class="section-heading">
        <div>
            <h2>Your applications</h2>
            <p>Review status updates and manage your submitted applications.</p>
        </div>
        <div class="result-count"><i class="fa-solid fa-magnifying-glass"></i> <?= count($filteredApplications) ?> results</div>
    </section>

    <form class="filters" method="get" action="applications.php">
        <label class="search-wrap">
            <i class="fa-solid fa-magnifying-glass"></i>
            <input type="search" name="search" value="<?= appEscape($search) ?>" placeholder="Search role, company, category..." aria-label="Search applications">
        </label>
        <select name="status" aria-label="Filter by application status">
            <option value="all" <?= $statusFilter === 'all' ? 'selected' : '' ?>>All statuses</option>
            <option value="applied" <?= $statusFilter === 'applied' ? 'selected' : '' ?>>Applied</option>
            <option value="under_review" <?= $statusFilter === 'under_review' ? 'selected' : '' ?>>Under Review</option>
            <option value="shortlisted" <?= $statusFilter === 'shortlisted' ? 'selected' : '' ?>>Shortlisted</option>
            <option value="interview" <?= $statusFilter === 'interview' ? 'selected' : '' ?>>Interview</option>
            <option value="selected" <?= $statusFilter === 'selected' ? 'selected' : '' ?>>Selected</option>
            <option value="rejected" <?= $statusFilter === 'rejected' ? 'selected' : '' ?>>Rejected</option>
            <option value="withdrawn" <?= $statusFilter === 'withdrawn' ? 'selected' : '' ?>>Withdrawn</option>
        </select>
        <button class="btn btn-primary" type="submit"><i class="fa-solid fa-sliders"></i> Apply filters</button>
        <a class="btn btn-clear" href="applications.php"><i class="fa-solid fa-rotate-left"></i> Clear</a>
    </form>

    <section class="applications-grid" aria-label="Application list">
        <?php if ($studentId === null): ?>
            <div class="empty-state">
                <div class="empty-icon"><i class="fa-solid fa-user-graduate"></i></div>
                <h3>Complete your student profile</h3>
                <p>Your account is not linked to a record in the students table yet. Complete or link your student profile before managing applications.</p>
                <a class="btn btn-primary" href="profile.php"><i class="fa-solid fa-user-pen"></i> Open my profile</a>
            </div>
        <?php elseif (!$filteredApplications): ?>
            <div class="empty-state">
                <div class="empty-icon"><i class="fa-solid fa-folder-open"></i></div>
                <h3><?= $totalApplications > 0 ? 'No matching applications' : 'Your journey starts here' ?></h3>
                <p><?= $totalApplications > 0
                    ? 'Try another search term or choose a different status filter.'
                    : 'You have not submitted any internship applications yet. Explore available opportunities and take your next step.' ?></p>
                <a class="btn btn-primary" href="internships.php"><i class="fa-solid fa-briefcase"></i> Explore internships</a>
            </div>
        <?php else: ?>
            <?php foreach ($filteredApplications as $index => $application): ?>
                <?php
                    $applicationStatus = strtolower((string) ($application['status'] ?? 'applied'));
                    $canWithdraw = !in_array($applicationStatus, ['withdrawn', 'rejected', 'selected'], true);
                    $appliedAt = $application['applied_at'] ?? null;
                    $dateLabel = 'Date unavailable';

                    if ($appliedAt && strtotime((string) $appliedAt) !== false) {
                        $dateLabel = date('d M Y', strtotime((string) $appliedAt));
                    }

                    $detailsQuery = http_build_query([
                        'id' => (int) ($application['internship_id'] ?? 0)
                    ]);
                ?>
                <article class="application-card" style="animation-delay: <?= min($index * 65, 400) ?>ms">
                    <div class="card-top">
                        <div class="company-mark"><i class="fa-solid fa-briefcase"></i></div>
                        <div class="card-title">
                            <h3><?= appEscape($application['internship_title'] ?? 'Internship opportunity') ?></h3>
                            <p><?= appEscape($application['company_name'] ?? 'Company') ?></p>
                        </div>
                        <span class="status <?= appEscape(appStatusClass($applicationStatus)) ?>">
                            <?= appEscape(appStatusLabel($applicationStatus)) ?>
                        </span>
                    </div>

                    <div class="card-meta">
                        <?php if (!empty($application['category'])): ?>
                            <span class="meta-item"><i class="fa-solid fa-code"></i> <?= appEscape($application['category']) ?></span>
                        <?php endif; ?>
                        <?php if (!empty($application['location'])): ?>
                            <span class="meta-item"><i class="fa-solid fa-location-dot"></i> <?= appEscape($application['location']) ?></span>
                        <?php endif; ?>
                        <?php if (!empty($application['work_mode'])): ?>
                            <span class="meta-item"><i class="fa-solid fa-laptop"></i> <?= appEscape(ucfirst((string) $application['work_mode'])) ?></span>
                        <?php endif; ?>
                        <?php if (!empty($application['internship_type'])): ?>
                            <span class="meta-item"><i class="fa-solid fa-clock"></i> <?= appEscape(ucwords(str_replace('-', ' ', (string) $application['internship_type']))) ?></span>
                        <?php endif; ?>
                        <?php if (!empty($application['stipend'])): ?>
                            <span class="meta-item"><i class="fa-solid fa-wallet"></i> <?= appEscape($application['stipend']) ?></span>
                        <?php endif; ?>
                    </div>

                    <div class="card-divider"></div>

                    <div class="card-footer">
                        <span class="applied-date"><i class="fa-regular fa-calendar-check"></i> Applied on <?= appEscape($dateLabel) ?></span>
                        <div class="card-actions">
                            <a class="btn btn-details" href="internships.php?<?= appEscape($detailsQuery) ?>">
                                <i class="fa-solid fa-arrow-up-right-from-square"></i> View role
                            </a>

                            <?php if ($canWithdraw): ?>
                                <button
                                    class="btn btn-withdraw"
                                    type="button"
                                    data-application-id="<?= (int) $application['application_id'] ?>"
                                    data-internship-title="<?= appEscape($application['internship_title'] ?? 'this internship') ?>"
                                >
                                    <i class="fa-solid fa-ban"></i> Withdraw
                                </button>
                            <?php else: ?>
                                <button class="btn btn-disabled" type="button" disabled>
                                    <i class="fa-solid fa-lock"></i>
                                    <?= $applicationStatus === 'withdrawn' ? 'Withdrawn' : 'Closed' ?>
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        <?php endif; ?>
    </section>
</main>

<footer class="footer">
    Built for your next step with <span><i class="fa-solid fa-heart"></i> InternPro</span>
</footer>

<div class="modal-backdrop" id="withdrawModal" role="dialog" aria-modal="true" aria-labelledby="withdrawTitle" aria-describedby="withdrawDescription">
    <div class="confirm-modal">
        <div class="modal-icon"><i class="fa-solid fa-triangle-exclamation"></i></div>
        <h2 id="withdrawTitle">Withdraw application?</h2>
        <p id="withdrawDescription">Are you sure you want to withdraw this application? This action changes its status and cannot be undone from this page.</p>
        <form method="post" action="applications.php<?= !empty($_SERVER['QUERY_STRING']) ? '?' . appEscape($_SERVER['QUERY_STRING']) : '' ?>" id="withdrawForm">
            <input type="hidden" name="csrf_token" value="<?= appEscape($csrfToken) ?>">
            <input type="hidden" name="action" value="withdraw">
            <input type="hidden" name="application_id" id="withdrawApplicationId" value="">
            <div class="modal-actions">
                <button type="button" class="btn btn-cancel" id="cancelWithdraw"><i class="fa-solid fa-arrow-left"></i> Keep application</button>
                <button type="submit" class="btn btn-withdraw"><i class="fa-solid fa-ban"></i> Yes, withdraw</button>
            </div>
        </form>
    </div>
</div>

<script>
(function () {
    const modal = document.getElementById('withdrawModal');
    const applicationInput = document.getElementById('withdrawApplicationId');
    const cancelButton = document.getElementById('cancelWithdraw');
    const description = document.getElementById('withdrawDescription');
    const withdrawButtons = document.querySelectorAll('[data-application-id]');
    let previousFocus = null;

    function openModal(button) {
        previousFocus = button;
        applicationInput.value = button.dataset.applicationId || '';
        const title = button.dataset.internshipTitle || 'this internship';
        description.textContent = 'Are you sure you want to withdraw your application for "' + title + '"? Its status will change to Withdrawn and you cannot undo this action from this page.';
        modal.classList.add('open');
        document.body.style.overflow = 'hidden';
        cancelButton.focus();
    }

    function closeModal() {
        modal.classList.remove('open');
        document.body.style.overflow = '';
        if (previousFocus) previousFocus.focus();
    }

    withdrawButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            openModal(button);
        });
    });

    cancelButton.addEventListener('click', closeModal);

    modal.addEventListener('click', function (event) {
        if (event.target === modal) closeModal();
    });

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape' && modal.classList.contains('open')) {
            closeModal();
        }
    });

    document.getElementById('withdrawForm').addEventListener('submit', function () {
        const submitButton = this.querySelector('button[type="submit"]');
        submitButton.disabled = true;
        submitButton.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Withdrawing...';
    });
})();
</script>
</body>
</html>
