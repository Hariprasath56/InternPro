
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/database.php';

if (
    !isset($_SESSION['user_id'], $_SESSION['role']) ||
    $_SESSION['role'] !== 'student'
) {
    header('Location: ../login.php');
    exit;
}

if (!isset($pdo) || !($pdo instanceof PDO)) {
    http_response_code(500);
    exit('Database connection is unavailable.');
}

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

function e($value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function internshipColumns(PDO $pdo, string $table): array
{
    $allowed = ['students', 'companies', 'internships', 'applications'];

    if (!in_array($table, $allowed, true)) {
        return [];
    }

    $stmt = $pdo->query("DESCRIBE `$table`");
    return array_column($stmt->fetchAll(PDO::FETCH_ASSOC), 'Field');
}

function internshipFirstColumn(array $columns, array $candidates): ?string
{
    foreach ($candidates as $column) {
        if (in_array($column, $columns, true)) {
            return $column;
        }
    }

    return null;
}

$userId = (int) $_SESSION['user_id'];
$displayName = trim((string) ($_SESSION['name'] ?? 'Student'));

if ($displayName === '') {
    $displayName = 'Student';
}

$search = trim((string) ($_GET['search'] ?? ''));
$locationFilter = trim((string) ($_GET['location'] ?? ''));
$modeFilter = trim((string) ($_GET['mode'] ?? ''));
$typeFilter = trim((string) ($_GET['type'] ?? ''));
$categoryFilter = trim((string) ($_GET['category'] ?? ''));

$allowedModes = ['', 'onsite', 'remote', 'hybrid'];
$allowedTypes = ['', 'full-time', 'part-time', 'contract', 'summer', 'winter', 'other'];

if (!in_array($modeFilter, $allowedModes, true)) {
    $modeFilter = '';
}

if (!in_array($typeFilter, $allowedTypes, true)) {
    $typeFilter = '';
}

if (empty($_SESSION['internpro_internship_csrf'])) {
    $_SESSION['internpro_internship_csrf'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['internpro_internship_csrf'];
$studentId = 0;
$internships = [];
$applicationMap = [];
$categories = [];
$errorMessage = '';
$successMessage = '';

try {
    $studentColumns = internshipColumns($pdo, 'students');
    $companyColumns = internshipColumns($pdo, 'companies');
    $internshipColumnNames = internshipColumns($pdo, 'internships');
    $applicationColumnNames = internshipColumns($pdo, 'applications');

    if (
        !in_array('id', $studentColumns, true) ||
        !in_array('user_id', $studentColumns, true)
    ) {
        throw new RuntimeException('The students table must contain id and user_id.');
    }

    $studentStmt = $pdo->prepare(
        'SELECT id FROM students WHERE user_id = :user_id LIMIT 1'
    );
    $studentStmt->execute(['user_id' => $userId]);
    $studentRecord = $studentStmt->fetch(PDO::FETCH_ASSOC);

    if (!$studentRecord) {
        $insertStudent = $pdo->prepare(
            'INSERT INTO students (user_id) VALUES (:user_id)'
        );
        $insertStudent->execute(['user_id' => $userId]);
        $studentId = (int) $pdo->lastInsertId();
    } else {
        $studentId = (int) $studentRecord['id'];
    }

    foreach (
        [
            'id',
            'company_id',
            'title',
            'description'
        ] as $requiredColumn
    ) {
        if (!in_array($requiredColumn, $internshipColumnNames, true)) {
            throw new RuntimeException(
                'The internships table is missing required column: ' . $requiredColumn
            );
        }
    }

    foreach (['internship_id', 'student_id'] as $requiredColumn) {
        if (!in_array($requiredColumn, $applicationColumnNames, true)) {
            throw new RuntimeException(
                'The applications table is missing required column: ' . $requiredColumn
            );
        }
    }

    /*
     * Handle application submissions and withdrawals.
     */
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $postedToken = (string) ($_POST['csrf_token'] ?? '');

        if (!hash_equals($csrfToken, $postedToken)) {
            $errorMessage = 'Your session token expired. Refresh the page and try again.';
        } else {
            $action = (string) ($_POST['action'] ?? '');
            $internshipId = filter_var(
                $_POST['internship_id'] ?? null,
                FILTER_VALIDATE_INT
            );

            if (!$internshipId || $internshipId < 1) {
                $errorMessage = 'Please select a valid internship.';
            } elseif ($action === 'apply') {
                $checkInternship = $pdo->prepare(
                    'SELECT id FROM internships WHERE id = :id LIMIT 1'
                );
                $checkInternship->execute(['id' => $internshipId]);

                if (!$checkInternship->fetchColumn()) {
                    $errorMessage = 'This internship is no longer available.';
                } else {
                    $duplicateStmt = $pdo->prepare(
                        'SELECT id FROM applications
                         WHERE internship_id = :internship_id
                         AND student_id = :student_id
                         LIMIT 1'
                    );

                    $duplicateStmt->execute([
                        'internship_id' => $internshipId,
                        'student_id' => $studentId
                    ]);

                    if ($duplicateStmt->fetchColumn()) {
                        $errorMessage = 'You have already applied for this internship.';
                    } else {
                        $insertColumns = ['internship_id', 'student_id'];
                        $insertValues = [':internship_id', ':student_id'];

                        $params = [
                            'internship_id' => $internshipId,
                            'student_id' => $studentId
                        ];

                        if (in_array('cover_letter', $applicationColumnNames, true)) {
                            $coverLetter = trim(
                                (string) ($_POST['cover_letter'] ?? '')
                            );

                            if (strlen($coverLetter) > 10000) {
                                $errorMessage = 'Your cover letter is too long.';
                            } else {
                                $insertColumns[] = 'cover_letter';
                                $insertValues[] = ':cover_letter';
                                $params['cover_letter'] =
                                    $coverLetter !== '' ? $coverLetter : null;
                            }
                        }

                        if (
                            $errorMessage === '' &&
                            in_array('status', $applicationColumnNames, true)
                        ) {
                            $insertColumns[] = 'status';
                            $insertValues[] = ':status';
                            $params['status'] = 'applied';
                        }

                        if ($errorMessage === '') {
                            $quotedColumns = array_map(
                                static fn($column) => "`$column`",
                                $insertColumns
                            );

                            $insertSql =
                                'INSERT INTO applications (' .
                                implode(', ', $quotedColumns) .
                                ') VALUES (' .
                                implode(', ', $insertValues) .
                                ')';

                            $insertApplication = $pdo->prepare($insertSql);
                            $insertApplication->execute($params);

                            $_SESSION['internpro_internship_flash'] =
                                'Your application has been submitted successfully.';

                            $redirectUrl = 'internships.php';

                            if ($_GET) {
                                $redirectUrl .= '?' . http_build_query($_GET);
                            }

                            header('Location: ' . $redirectUrl);
                            exit;
                        }
                    }
                }
            } elseif ($action === 'withdraw') {
                if (!in_array('status', $applicationColumnNames, true)) {
                    $errorMessage =
                        'Withdrawal is unavailable because application status is not configured.';
                } else {
                    $withdrawStmt = $pdo->prepare(
                        "UPDATE applications
                         SET status = 'withdrawn'
                         WHERE internship_id = :internship_id
                         AND student_id = :student_id
                         AND status IN ('applied', 'under_review')"
                    );

                    $withdrawStmt->execute([
                        'internship_id' => $internshipId,
                        'student_id' => $studentId
                    ]);

                    if ($withdrawStmt->rowCount() > 0) {
                        $_SESSION['internpro_internship_flash'] =
                            'Your application has been withdrawn.';

                        header('Location: internships.php');
                        exit;
                    }

                    $errorMessage =
                        'This application cannot be withdrawn at its current status.';
                }
            } else {
                $errorMessage = 'Invalid request.';
            }
        }
    }

    if (isset($_SESSION['internpro_internship_flash'])) {
        $successMessage = (string) $_SESSION['internpro_internship_flash'];
        unset($_SESSION['internpro_internship_flash']);
    }

    /*
     * Build a company-name join only when the expected columns exist.
     */
    $companyNameColumn = internshipFirstColumn(
        $companyColumns,
        ['company_name', 'name', 'name_of_company', 'organization_name']
    );

    $selectParts = [
        'i.id',
        'i.company_id',
        'i.title',
        'i.description'
    ];

    $optionalColumns = [
        'category',
        'responsibilities',
        'requirements',
        'location',
        'work_mode',
        'internship_type',
        'stipend',
        'salary',
        'duration',
        'application_deadline',
        'deadline',
        'vacancies',
        'created_at',
        'status'
    ];

    foreach ($optionalColumns as $column) {
        if (in_array($column, $internshipColumnNames, true)) {
            $selectParts[] = 'i.`' . $column . '`';
        }
    }

    $companyJoin = '';

    if (
        $companyNameColumn !== null &&
        in_array('id', $companyColumns, true)
    ) {
        $selectParts[] = 'c.`' . $companyNameColumn . '` AS company_display_name';
        $companyJoin = ' LEFT JOIN companies c ON c.id = i.company_id';
    }

    $whereParts = [];
    $params = [];

    if (in_array('status', $internshipColumnNames, true)) {
        $whereParts[] =
            "(i.status IS NULL OR LOWER(i.status) IN ('active', 'published', 'open'))";
    }

    if ($search !== '') {
        $searchParts = [
            'i.title LIKE :search_title',
            'i.description LIKE :search_description'
        ];

        $searchValue = '%' . $search . '%';

        $params['search_title'] = $searchValue;
        $params['search_description'] = $searchValue;

        if (in_array('category', $internshipColumnNames, true)) {
            $searchParts[] = 'i.category LIKE :search_category';
            $params['search_category'] = $searchValue;
        }

        if (in_array('requirements', $internshipColumnNames, true)) {
            $searchParts[] = 'i.requirements LIKE :search_requirements';
            $params['search_requirements'] = $searchValue;
        }

        $whereParts[] = '(' . implode(' OR ', $searchParts) . ')';
    }

    if (
        $locationFilter !== '' &&
        in_array('location', $internshipColumnNames, true)
    ) {
        $whereParts[] = 'i.location LIKE :location';
        $params['location'] = '%' . $locationFilter . '%';
    }

    if (
        $modeFilter !== '' &&
        in_array('work_mode', $internshipColumnNames, true)
    ) {
        $whereParts[] = 'i.work_mode = :work_mode';
        $params['work_mode'] = $modeFilter;
    }

    if (
        $typeFilter !== '' &&
        in_array('internship_type', $internshipColumnNames, true)
    ) {
        $whereParts[] = 'i.internship_type = :internship_type';
        $params['internship_type'] = $typeFilter;
    }

    if (
        $categoryFilter !== '' &&
        in_array('category', $internshipColumnNames, true)
    ) {
        $whereParts[] = 'i.category = :category';
        $params['category'] = $categoryFilter;
    }

    $sql = 'SELECT ' . implode(', ', $selectParts) .
        ' FROM internships i' . $companyJoin;

    if ($whereParts) {
        $sql .= ' WHERE ' . implode(' AND ', $whereParts);
    }

    $orderColumn = in_array('created_at', $internshipColumnNames, true)
        ? 'i.created_at'
        : 'i.id';

    $sql .= ' ORDER BY ' . $orderColumn . ' DESC';

    $internshipStmt = $pdo->prepare($sql);
    $internshipStmt->execute($params);
    $internships = $internshipStmt->fetchAll(PDO::FETCH_ASSOC);

    /*
     * Load the student's existing applications.
     */
    $applicationSelect = ['internship_id', 'student_id'];

    if (in_array('status', $applicationColumnNames, true)) {
        $applicationSelect[] = 'status';
    }

    $quotedApplicationColumns = array_map(
        static fn($column) => "`$column`",
        $applicationSelect
    );

    $applicationStmt = $pdo->prepare(
        'SELECT ' . implode(', ', $quotedApplicationColumns) .
        ' FROM applications WHERE student_id = :student_id'
    );

    $applicationStmt->execute(['student_id' => $studentId]);

    foreach ($applicationStmt->fetchAll(PDO::FETCH_ASSOC) as $application) {
        $applicationMap[(int) $application['internship_id']] =
            $application['status'] ?? 'applied';
    }
} catch (Throwable $exception) {
    error_log('InternPro internships page error: ' . $exception->getMessage());

    if ($errorMessage === '') {
        $errorMessage =
            'Unable to load internships right now. Please refresh the page and try again.';
    }
}

foreach ($internships as $internship) {
    $category = trim((string) ($internship['category'] ?? ''));

    if ($category !== '') {
        $categories[$category] = $category;
    }
}

ksort($categories, SORT_NATURAL | SORT_FLAG_CASE);

$totalInternships = count($internships);
$activeApplications = 0;

foreach ($applicationMap as $status) {
    if (!in_array(strtolower((string) $status), ['rejected', 'withdrawn'], true)) {
        $activeApplications++;
    }
}

$filterQuery = $_GET ? '?' . e(http_build_query($_GET)) : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#041224">
    <title>Explore Internships | InternPro</title>

    <link rel="icon" type="image/jpeg" href="../assets/logo.jpg">
    <link rel="apple-touch-icon" href="../assets/logooo.png.png">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <style>
        :root {
            --navy: #071e3d;
            --deep: #041224;
            --blue: #0d3b66;
            --bright: #0077b6;
            --cyan: #00b4d8;
            --light-cyan: #38bdf8;
            --white: #f5faff;
            --muted: #9aacc4;
            --border: rgba(56,189,248,.17);
            --glass: rgba(10,37,67,.67);
            --success: #43e6ae;
            --danger: #ff8191;
        }

        * { box-sizing: border-box; }

        html {
            scroll-behavior: smooth;
            scrollbar-color: #12618b #041224;
        }

        body {
            margin: 0;
            min-height: 100vh;
            color: var(--white);
            background:
                radial-gradient(ellipse at 4% 18%, rgba(0,180,216,.13), transparent 34%),
                radial-gradient(ellipse at 95% 55%, rgba(0,119,182,.15), transparent 34%),
                linear-gradient(135deg, var(--deep), var(--navy) 55%, #06172c);
            font-family: 'Poppins', sans-serif;
            overflow-x: hidden;
        }

        body::before {
            content: "";
            position: fixed;
            inset: 0;
            pointer-events: none;
            opacity: .16;
            background-image:
                linear-gradient(rgba(56,189,248,.08) 1px, transparent 1px),
                linear-gradient(90deg, rgba(56,189,248,.08) 1px, transparent 1px);
            background-size: 48px 48px;
            mask-image: linear-gradient(to bottom, black, transparent 90%);
            z-index: -1;
        }

        body::after {
            content: "";
            position: fixed;
            width: 330px;
            height: 330px;
            left: -180px;
            bottom: -180px;
            border-radius: 50%;
            background: rgba(0,180,216,.08);
            filter: blur(55px);
            pointer-events: none;
            z-index: -1;
            animation: ambient-float 12s ease-in-out infinite alternate;
        }

        a { color: inherit; text-decoration: none; }
        button, input, select, textarea { font: inherit; }
        button, a, input, select, textarea { -webkit-tap-highlight-color: transparent; }

        button:focus-visible, a:focus-visible, input:focus-visible,
        select:focus-visible, textarea:focus-visible {
            outline: 2px solid var(--light-cyan);
            outline-offset: 3px;
        }

        .icon-motion {
            display: inline-block;
            transition: transform .28s ease, color .28s ease, filter .28s ease;
        }

        a:hover .icon-motion,
        button:hover .icon-motion,
        .action-icon:hover {
            transform: translateY(-2px) rotate(-5deg) scale(1.08);
            color: var(--light-cyan);
            filter: drop-shadow(0 0 7px rgba(0,180,216,.65));
        }

        .navbar {
            position: sticky;
            top: 0;
            z-index: 100;
            min-height: 82px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 25px;
            padding: 12px clamp(20px, 5vw, 82px);
            background: rgba(3,15,30,.93);
            border-bottom: 1px solid rgba(56,189,248,.12);
            backdrop-filter: blur(18px);
            -webkit-backdrop-filter: blur(18px);
        }

        .brand {
            display: inline-flex;
            align-items: center;
            gap: 11px;
            flex-shrink: 0;
            font: 700 24px 'Space Grotesk', sans-serif;
            letter-spacing: -.8px;
            white-space: nowrap;
        }

        .brand-logo,
        .brand-logo-fallback {
            width: 49px;
            height: 49px;
            flex: 0 0 49px;
            border-radius: 50%;
            border: 1px solid rgba(0,180,216,.65);
            background: #041224;
            box-shadow: 0 0 0 3px rgba(0,180,216,.08), 0 0 18px rgba(0,180,216,.24);
            transition: transform .28s ease, box-shadow .28s ease;
        }

        .brand-logo {
    width: 49px;
    height: 49px;
    min-width: 49px;
    object-fit: contain;
    display: block;
    border-radius: 50%;
    background: transparent;
    border: none;
    box-shadow: 0 0 15px rgba(0, 180, 216, 0.2);
    transition: transform 0.3s ease, filter 0.3s ease;
}

.brand-logo:hover {
    transform: scale(1.08) rotate(-4deg);
    filter: drop-shadow(0 0 8px rgba(0, 180, 216, 0.6));
}

        .brand-name span { color: var(--cyan); }

        .nav-links {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            flex-wrap: wrap;
            gap: 7px;
        }

        .nav-link {
            position: relative;
            display: inline-flex;
            align-items: center;
            gap: 9px;
            padding: 13px 14px;
            color: var(--muted);
            font-size: 13px;
            font-weight: 600;
            border: 1px solid transparent;
            border-radius: 13px;
            transition: color .25s ease, background .25s ease,
                border-color .25s ease, transform .25s ease;
        }

        .nav-link:hover,
        .nav-link.active {
            color: #55e5fa;
            background: rgba(0,180,216,.09);
            border-color: rgba(0,180,216,.2);
            transform: translateY(-2px);
        }

        .nav-link.active::after {
            content: "";
            position: absolute;
            height: 3px;
            width: 48%;
            left: 26%;
            bottom: -14px;
            background: var(--cyan);
            border-radius: 5px;
            box-shadow: 0 0 12px var(--cyan);
        }

        .nav-link.logout {
            border-color: var(--border);
            color: #d5e5f6;
            margin-left: 5px;
        }

        .page-shell {
            width: min(1290px, calc(100% - 48px));
            margin: 0 auto;
            padding: 42px 0 72px;
        }

        .hero {
            position: relative;
            overflow: hidden;
            padding: clamp(28px, 5vw, 58px);
            margin-bottom: 36px;
            border: 1px solid rgba(56,189,248,.24);
            border-radius: 32px;
            background:
                radial-gradient(circle at 100% 0%, rgba(0,180,216,.13), transparent 37%),
                linear-gradient(120deg, rgba(13,59,102,.83), rgba(4,18,36,.86));
            box-shadow: 0 24px 70px rgba(0,0,0,.17), inset 0 1px rgba(255,255,255,.035);
            animation: rise-in .7s ease both;
        }

        .hero::before {
            content: "";
            position: absolute;
            width: 360px;
            height: 360px;
            right: -105px;
            top: -230px;
            border: 1px solid rgba(0,180,216,.17);
            border-radius: 50%;
            box-shadow: 0 0 0 28px rgba(0,180,216,.025), 0 0 0 65px rgba(0,180,216,.018);
            pointer-events: none;
        }

        .eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 9px;
            padding: 9px 14px;
            border-radius: 30px;
            border: 1px solid rgba(0,180,216,.27);
            background: rgba(0,180,216,.075);
            color: #5ce4f7;
            font-size: 11px;
            font-weight: 800;
            letter-spacing: 1.2px;
            text-transform: uppercase;
        }

        .hero h1 {
            position: relative;
            margin: 22px 0 12px;
            font: 700 clamp(34px, 5vw, 59px)/1.12 'Space Grotesk', sans-serif;
            letter-spacing: -2px;
        }

        .hero h1 span {
            background: linear-gradient(100deg, var(--cyan), #61d7ff);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }

        .hero p {
            max-width: 690px;
            margin: 0;
            color: #a9bfd6;
            font-size: 15px;
            line-height: 1.9;
        }

        .hero-stats {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            margin-top: 27px;
        }

        .stat-pill {
            display: flex;
            align-items: center;
            gap: 9px;
            padding: 10px 14px;
            color: #dceaf8;
            background: rgba(4,18,36,.45);
            border: 1px solid var(--border);
            border-radius: 13px;
            font-size: 12px;
        }

        .stat-pill strong,
        .stat-pill i { color: #58e3f7; }

        .alert {
            display: flex;
            align-items: flex-start;
            gap: 11px;
            padding: 15px 18px;
            margin: 0 0 22px;
            border-radius: 14px;
            font-size: 13px;
            line-height: 1.7;
            animation: rise-in .35s ease both;
        }

        .alert.success {
            color: #b8ffe7;
            border: 1px solid rgba(67,230,174,.25);
            background: rgba(67,230,174,.08);
        }

        .alert.error {
            color: #ffd2d8;
            border: 1px solid rgba(255,129,145,.28);
            background: rgba(255,129,145,.08);
        }

        .section-heading {
            display: flex;
            align-items: flex-end;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 15px;
            margin: 0 0 20px;
        }

        .section-heading h2 {
            margin: 0;
            font: 700 clamp(24px, 3vw, 33px) 'Space Grotesk', sans-serif;
            letter-spacing: -.8px;
        }

        .section-heading p {
            color: var(--muted);
            font-size: 13px;
            margin: 8px 0 0;
        }

        .result-count {
            padding: 8px 13px;
            color: #6be6f8;
            border: 1px solid var(--border);
            background: rgba(0,180,216,.07);
            border-radius: 10px;
            font-size: 12px;
        }

        .filter-panel {
            padding: 20px;
            margin-bottom: 27px;
            background: var(--glass);
            border: 1px solid var(--border);
            border-radius: 21px;
            box-shadow: 0 15px 45px rgba(0,0,0,.12);
            backdrop-filter: blur(12px);
        }

        .search-row {
            display: grid;
            grid-template-columns: minmax(220px, 2fr) minmax(150px, 1fr)
                minmax(140px, 1fr) minmax(140px, 1fr) auto;
            gap: 11px;
        }

        .field-wrap { position: relative; min-width: 0; }

        .field-wrap > i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #52d9f1;
            pointer-events: none;
            transition: color .25s ease, filter .25s ease;
        }

        .field-wrap:focus-within > i {
            color: #8beeff;
            filter: drop-shadow(0 0 6px rgba(0,180,216,.6));
        }

        .field-wrap input,
        .field-wrap select {
            width: 100%;
            min-width: 0;
            height: 49px;
            padding: 0 13px 0 42px;
            color: var(--white);
            background: rgba(3,16,33,.73);
            border: 1px solid rgba(125,175,218,.18);
            border-radius: 12px;
            outline: none;
            font-size: 12px;
            transition: border-color .25s ease, box-shadow .25s ease;
        }

        .field-wrap select { padding-right: 8px; }
        .field-wrap input::placeholder { color: #8198b2; }

        .field-wrap input:focus,
        .field-wrap select:focus {
            border-color: rgba(0,180,216,.65);
            box-shadow: 0 0 0 3px rgba(0,180,216,.08);
        }

        .field-wrap select option {
            color: #eaf5ff;
            background: #071e3d;
        }

        .btn {
            min-height: 46px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 9px;
            padding: 12px 18px;
            border: 1px solid transparent;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 700;
            cursor: pointer;
            transition: transform .25s ease, box-shadow .25s ease,
                background .25s ease, border-color .25s ease;
        }

        .btn:hover { transform: translateY(-3px); }

        .btn-primary {
            color: #031629;
            background: linear-gradient(110deg, var(--cyan), #36b9f5);
            box-shadow: 0 8px 22px rgba(0,180,216,.15);
        }

        .btn-primary:hover { box-shadow: 0 12px 28px rgba(0,180,216,.27); }

        .btn-secondary {
            color: #d5e8f9;
            background: rgba(11,36,65,.72);
            border-color: rgba(125,175,218,.22);
        }

        .btn-secondary:hover { border-color: rgba(0,180,216,.5); }

        .btn:disabled {
            opacity: .65;
            cursor: not-allowed;
            transform: none;
        }

        .filter-footer {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            flex-wrap: wrap;
            margin-top: 13px;
        }

        .filter-hint { color: #849db8; font-size: 11px; }
        .clear-link { color: #58dff5; font-size: 12px; font-weight: 600; }
        .clear-link:hover { color: white; }

        .card-tags {
            display: flex;
            gap: 7px;
            flex-wrap: wrap;
            margin-top: 14px;
        }

        .tag {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 9px;
            border-radius: 9px;
            color: #a8eefa;
            background: rgba(0,180,216,.075);
            border: 1px solid rgba(0,180,216,.15);
            font-size: 10px;
            font-weight: 600;
        }

        .internship-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 20px;
        }

        .internship-card {
            position: relative;
            display: flex;
            flex-direction: column;
            min-width: 0;
            padding: 23px;
            overflow: hidden;
            border: 1px solid rgba(110,164,211,.16);
            border-radius: 22px;
            background: linear-gradient(145deg, rgba(10,35,65,.86), rgba(4,18,36,.91));
            box-shadow: 0 15px 38px rgba(0,0,0,.12);
            transition: transform .3s ease, border-color .3s ease, box-shadow .3s ease;
            animation: rise-in .55s ease both;
        }

        .internship-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 18px;
            right: 18px;
            height: 2px;
            background: linear-gradient(90deg, transparent, var(--cyan), transparent);
            opacity: .55;
            transition: opacity .3s ease;
        }

        .internship-card:hover {
            transform: translateY(-7px);
            border-color: rgba(0,180,216,.43);
            box-shadow: 0 22px 45px rgba(0,0,0,.22), 0 0 24px rgba(0,180,216,.055);
        }

        .internship-card:hover::before { opacity: 1; }

        .card-top {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 12px;
            margin-bottom: 17px;
        }

        .company-mark {
            width: 48px;
            height: 48px;
            flex: 0 0 48px;
            display: grid;
            place-items: center;
            color: #65e8fb;
            font-size: 19px;
            background: linear-gradient(145deg, rgba(0,180,216,.18), rgba(0,119,182,.1));
            border: 1px solid rgba(0,180,216,.23);
            border-radius: 15px;
            transition: transform .3s ease, box-shadow .3s ease;
        }

        .internship-card:hover .company-mark {
            transform: rotate(-7deg) scale(1.07);
            box-shadow: 0 0 20px rgba(0,180,216,.14);
        }

        .card-title {
            margin: 0;
            font: 700 20px/1.35 'Space Grotesk', sans-serif;
            overflow-wrap: anywhere;
        }

        .company-name {
            margin: 7px 0 0;
            color: #65dff3;
            font-size: 12px;
            font-weight: 600;
        }

        .card-description {
            margin: 16px 0;
            color: #9db1c9;
            font-size: 12px;
            line-height: 1.85;
            overflow-wrap: anywhere;
        }

        .card-meta {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 10px;
            padding: 14px 0;
            margin-top: auto;
            border-top: 1px solid rgba(125,175,218,.12);
            border-bottom: 1px solid rgba(125,175,218,.12);
        }

        .meta-item {
            display: flex;
            align-items: flex-start;
            gap: 8px;
            min-width: 0;
            color: #a8bbd0;
            font-size: 11px;
            line-height: 1.6;
            overflow-wrap: anywhere;
        }

        .meta-item i {
            width: 14px;
            flex: 0 0 14px;
            margin-top: 3px;
            color: var(--cyan);
            text-align: center;
        }

        .card-bottom {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 18px;
        }

        .card-bottom .btn { flex: 1 1 auto; }

        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 8px 10px;
            border-radius: 10px;
            color: #8af2c9;
            background: rgba(67,230,174,.08);
            border: 1px solid rgba(67,230,174,.19);
            font-size: 10px;
            font-weight: 700;
        }

        .status-badge.pending {
            color: #a9dff9;
            background: rgba(56,189,248,.07);
            border-color: rgba(56,189,248,.2);
        }

        .status-badge.finished {
            color: #ffb7c1;
            background: rgba(255,129,145,.07);
            border-color: rgba(255,129,145,.18);
        }

        .empty-state {
            grid-column: 1 / -1;
            text-align: center;
            padding: 65px 25px;
            background: var(--glass);
            border: 1px solid var(--border);
            border-radius: 24px;
        }

        .empty-icon {
            width: 76px;
            height: 76px;
            display: grid;
            place-items: center;
            margin: 0 auto 18px;
            border-radius: 23px;
            color: #55e4f7;
            background: rgba(0,180,216,.09);
            border: 1px solid var(--border);
            font-size: 28px;
        }

        .empty-state h3 {
            margin: 0 0 9px;
            font: 700 23px 'Space Grotesk', sans-serif;
        }

        .empty-state p {
            margin: 0 auto 20px;
            max-width: 460px;
            color: var(--muted);
            font-size: 13px;
            line-height: 1.8;
        }

        .footer {
            padding: 25px 20px;
            text-align: center;
            color: #7189a5;
            border-top: 1px solid rgba(56,189,248,.1);
            font-size: 11px;
        }

        .footer span { color: var(--cyan); }

        .modal-backdrop {
            position: fixed;
            inset: 0;
            z-index: 200;
            display: none;
            align-items: center;
            justify-content: center;
            padding: 20px;
            background: rgba(1,8,18,.78);
            backdrop-filter: blur(9px);
            -webkit-backdrop-filter: blur(9px);
        }

        .modal-backdrop.open { display: flex; }

        .modal {
            width: min(600px, 100%);
            max-height: 90vh;
            overflow-y: auto;
            padding: 26px;
            background: linear-gradient(145deg, #0c2a4b, #041224);
            border: 1px solid rgba(0,180,216,.3);
            border-radius: 22px;
            box-shadow: 0 25px 90px rgba(0,0,0,.45);
            animation: rise-in .25s ease both;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            gap: 15px;
            align-items: flex-start;
        }

        .modal-header h3 {
            margin: 0;
            font: 700 23px 'Space Grotesk', sans-serif;
            overflow-wrap: anywhere;
        }

        .modal-close {
            width: 38px;
            height: 38px;
            flex: 0 0 38px;
            color: #d9eafa;
            background: rgba(255,255,255,.04);
            border: 1px solid var(--border);
            border-radius: 11px;
            cursor: pointer;
        }

        .modal-company { color: #5ce4f7; font-size: 12px; margin: 8px 0 18px; }
        .modal-section { margin: 18px 0; }
        .modal-section h4 { color: #68e3f7; font-size: 12px; margin: 0 0 7px; }

        .modal-section p {
            white-space: pre-line;
            color: #a9bfd6;
            font-size: 12px;
            line-height: 1.85;
            margin: 0;
            overflow-wrap: anywhere;
        }

        .modal textarea {
            width: 100%;
            min-height: 120px;
            resize: vertical;
            padding: 13px;
            color: var(--white);
            background: rgba(3,16,33,.8);
            border: 1px solid rgba(125,175,218,.22);
            border-radius: 12px;
            font-size: 12px;
        }

        .modal textarea:focus {
            outline: 2px solid rgba(0,180,216,.45);
            outline-offset: 1px;
        }

        .modal-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            flex-wrap: wrap;
            margin-top: 15px;
        }

        @keyframes rise-in {
            from { opacity: 0; transform: translateY(14px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes ambient-float {
            from { transform: translate(0, 0); }
            to { transform: translate(70px, -35px); }
        }

        @media (max-width: 1250px) {
            .navbar { gap: 15px; }
            .nav-link { padding: 11px 10px; }
            .search-row {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
            .search-row .search-submit { grid-column: span 2; }
            .internship-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
        }

        @media (max-width: 720px) {
            .navbar {
                position: relative;
                flex-direction: column;
                align-items: stretch;
                gap: 13px;
                padding: 15px 18px;
            }

            .brand { justify-content: center; }
            .nav-links { justify-content: center; gap: 5px; }
            .nav-link { padding: 10px 9px; font-size: 11px; gap: 6px; }
            .nav-link.active::after { bottom: -5px; }
            .nav-link.logout { margin-left: 0; }

            .page-shell {
                width: min(calc(100% - 28px), 600px);
                padding-top: 25px;
            }

            .hero { padding: 28px 22px; border-radius: 24px; }
            .hero h1 { letter-spacing: -1px; }
            .hero p { font-size: 13px; }
            .search-row { grid-template-columns: 1fr; }
            .search-row .search-submit { grid-column: auto; }
            .internship-grid { grid-template-columns: 1fr; }
            .filter-panel { padding: 15px; }
            .internship-card { padding: 20px; }
            .section-heading { align-items: flex-start; }
        }

        @media (max-width: 390px) {
            .nav-link { font-size: 10px; padding: 9px 7px; }
            .brand { font-size: 21px; }
            .brand-logo, .brand-logo-fallback {
                width: 43px;
                height: 43px;
                flex-basis: 43px;
            }
            .card-meta { grid-template-columns: 1fr; }
            .card-bottom { align-items: stretch; flex-direction: column; }
            .card-bottom .btn { width: 100%; }
            .modal { padding: 20px; }
        }

        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                scroll-behavior: auto !important;
                animation-duration: .01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: .01ms !important;
            }
        }
    </style>
</head>
<body>
<header class="navbar">
    <a class="brand" href="dashboard.php" aria-label="InternPro Dashboard">
    <img
        class="brand-logo"
        src="../assets/logo.jpg"
        alt="InternPro Logo"
        width="49"
        height="49"
    >
    <span class="brand-name">Intern<span>Pro</span></span>
</a>

    <nav class="nav-links" aria-label="Student navigation">
        <a class="nav-link" href="dashboard.php">
            <i class="fa-solid fa-table-cells-large icon-motion" aria-hidden="true"></i>
            Dashboard
        </a>
        <a class="nav-link" href="profile.php">
            <i class="fa-solid fa-circle-user icon-motion" aria-hidden="true"></i>
            My Profile
        </a>
        <a class="nav-link active" href="internships.php" aria-current="page">
            <i class="fa-solid fa-briefcase icon-motion" aria-hidden="true"></i>
            Internships
        </a>
        <a class="nav-link" href="applications.php">
            <i class="fa-solid fa-clipboard-check icon-motion" aria-hidden="true"></i>
            Applications
        </a>
        <a class="nav-link logout" href="../logout.php">
            <i class="fa-solid fa-right-from-bracket icon-motion" aria-hidden="true"></i>
            Logout
        </a>
    </nav>
</header>

<main class="page-shell">
    <section class="hero">
        <div class="eyebrow">
            <i class="fa-solid fa-wand-magic-sparkles icon-motion" aria-hidden="true"></i>
            Your next opportunity awaits
        </div>

        <h1>Find your next <span>internship.</span></h1>

        <p>
            Welcome back, <?= e($displayName) ?>. Discover opportunities,
            explore new career paths, and find the experience that moves you forward.
        </p>

        <div class="hero-stats">
            <div class="stat-pill">
                <i class="fa-solid fa-layer-group icon-motion" aria-hidden="true"></i>
                Opportunities found <strong><?= (int) $totalInternships ?></strong>
            </div>
            <div class="stat-pill">
                <i class="fa-solid fa-paper-plane icon-motion" aria-hidden="true"></i>
                Your applications <strong><?= (int) $activeApplications ?></strong>
            </div>
        </div>
    </section>

    <?php if ($successMessage !== ''): ?>
        <div class="alert success" role="status">
            <i class="fa-solid fa-circle-check icon-motion" aria-hidden="true"></i>
            <div><?= e($successMessage) ?></div>
        </div>
    <?php endif; ?>

    <?php if ($errorMessage !== ''): ?>
        <div class="alert error" role="alert">
            <i class="fa-solid fa-circle-exclamation icon-motion" aria-hidden="true"></i>
            <div><?= e($errorMessage) ?></div>
        </div>
    <?php endif; ?>

    <section aria-labelledby="explore-heading">
        <div class="section-heading">
            <div>
                <h2 id="explore-heading">Explore opportunities</h2>
                <p>Find a role that matches your skills and career goals.</p>
            </div>

            <span class="result-count">
                <i class="fa-solid fa-magnifying-glass icon-motion" aria-hidden="true"></i>
                <?= (int) $totalInternships ?>
                result<?= $totalInternships === 1 ? '' : 's' ?>
            </span>
        </div>

        <form class="filter-panel" method="get" action="internships.php">
            <div class="search-row">
                <div class="field-wrap">
                    <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
                    <input
                        type="search"
                        name="search"
                        value="<?= e($search) ?>"
                        placeholder="Search title, skill, category..."
                        aria-label="Search internships"
                    >
                </div>

                <div class="field-wrap">
                    <i class="fa-solid fa-location-dot" aria-hidden="true"></i>
                    <input
                        type="search"
                        name="location"
                        value="<?= e($locationFilter) ?>"
                        placeholder="Location"
                        aria-label="Filter by location"
                    >
                </div>

                <div class="field-wrap">
                    <i class="fa-solid fa-laptop" aria-hidden="true"></i>
                    <select name="mode" aria-label="Work mode">
                        <option value="">All work modes</option>
                        <option value="onsite" <?= $modeFilter === 'onsite' ? 'selected' : '' ?>>On-site</option>
                        <option value="remote" <?= $modeFilter === 'remote' ? 'selected' : '' ?>>Remote</option>
                        <option value="hybrid" <?= $modeFilter === 'hybrid' ? 'selected' : '' ?>>Hybrid</option>
                    </select>
                </div>

                <div class="field-wrap">
                    <i class="fa-solid fa-clock" aria-hidden="true"></i>
                    <select name="type" aria-label="Internship type">
                        <option value="">All internship types</option>
                        <option value="full-time" <?= $typeFilter === 'full-time' ? 'selected' : '' ?>>Full-time</option>
                        <option value="part-time" <?= $typeFilter === 'part-time' ? 'selected' : '' ?>>Part-time</option>
                        <option value="contract" <?= $typeFilter === 'contract' ? 'selected' : '' ?>>Contract</option>
                        <option value="summer" <?= $typeFilter === 'summer' ? 'selected' : '' ?>>Summer</option>
                        <option value="winter" <?= $typeFilter === 'winter' ? 'selected' : '' ?>>Winter</option>
                        <option value="other" <?= $typeFilter === 'other' ? 'selected' : '' ?>>Other</option>
                    </select>
                </div>

                <button class="btn btn-primary search-submit" type="submit">
                    <i class="fa-solid fa-sliders icon-motion" aria-hidden="true"></i>
                    Find internships
                </button>
            </div>

            <?php if ($categories): ?>
                <div class="filter-footer">
                    <span class="filter-hint">Popular categories</span>
                    <div class="card-tags">
                        <?php foreach ($categories as $category): ?>
                            <a
                                class="tag"
                                href="<?= e('internships.php?' . http_build_query(array_merge($_GET, ['category' => $category]))) ?>"
                            ><?= e($category) ?></a>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>

            <div class="filter-footer">
                <span class="filter-hint">
                    <i class="fa-solid fa-shield-halved icon-motion" aria-hidden="true"></i>
                    Your search updates the listings using the database.
                </span>
                <a class="clear-link" href="internships.php">
                    <i class="fa-solid fa-rotate-left icon-motion" aria-hidden="true"></i>
                    Clear filters
                </a>
            </div>
        </form>
    </section>

    <section aria-label="Internship listings">
        <div class="internship-grid">
            <?php if (!$internships && $errorMessage === ''): ?>
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="fa-solid fa-binoculars icon-motion" aria-hidden="true"></i>
                    </div>
                    <h3>No internships found</h3>
                    <p>
                        There are no internships matching your filters right now.
                        Try another search or check back soon for new opportunities.
                    </p>
                    <a class="btn btn-primary" href="internships.php">
                        <i class="fa-solid fa-rotate-left icon-motion" aria-hidden="true"></i>
                        Reset search
                    </a>
                </div>
            <?php elseif (!$internships): ?>
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="fa-solid fa-triangle-exclamation icon-motion" aria-hidden="true"></i>
                    </div>
                    <h3>We couldn't load the listings</h3>
                    <p>
                        Please refresh the page. If the problem continues,
                        check the PHP error log for the database error.
                    </p>
                    <a class="btn btn-secondary" href="internships.php">
                        <i class="fa-solid fa-rotate icon-motion" aria-hidden="true"></i>
                        Try again
                    </a>
                </div>
            <?php else: ?>
                <?php foreach ($internships as $index => $internship): ?>
                    <?php
                    $id = (int) $internship['id'];
                    $title = (string) $internship['title'];

                    $companyName = trim(
                        (string) ($internship['company_display_name'] ?? '')
                    );

                    if ($companyName === '') {
                        $companyName = 'Hiring Company';
                    }

                    $description = trim((string) $internship['description']);
                    $mode = trim((string) ($internship['work_mode'] ?? ''));
                    $type = trim((string) ($internship['internship_type'] ?? ''));
                    $location = trim((string) ($internship['location'] ?? ''));
                    $category = trim((string) ($internship['category'] ?? ''));
                    $stipend = $internship['stipend'] ?? ($internship['salary'] ?? null);
                    $duration = trim((string) ($internship['duration'] ?? ''));
                    $deadline = $internship['application_deadline'] ?? ($internship['deadline'] ?? null);
                    $responsibilities = trim((string) ($internship['responsibilities'] ?? ''));
                    $requirements = trim((string) ($internship['requirements'] ?? ''));
                    $status = strtolower((string) ($applicationMap[$id] ?? ''));

                    $alreadyApplied = array_key_exists($id, $applicationMap);
                    $isWithdrawn = $status === 'withdrawn';
                    $isRejected = $status === 'rejected';
                    $canWithdraw = in_array($status, ['applied', 'under_review'], true);

                    $modalData = [
                        'id' => $id,
                        'title' => $title,
                        'company' => $companyName,
                        'description' => $description,
                        'responsibilities' => $responsibilities,
                        'requirements' => $requirements,
                        'location' => $location,
                        'mode' => $mode,
                        'type' => $type,
                        'category' => $category,
                        'duration' => $duration,
                        'stipend' => $stipend,
                        'deadline' => $deadline
                    ];
                    ?>

                    <article class="internship-card" style="animation-delay: <?= min($index * 60, 360) ?>ms">
                        <div class="card-top">
                            <div class="company-mark">
                                <i class="fa-solid fa-briefcase icon-motion" aria-hidden="true"></i>
                            </div>
                            <?php if ($category !== ''): ?>
                                <span class="tag"><?= e($category) ?></span>
                            <?php endif; ?>
                        </div>

                        <h3 class="card-title"><?= e($title) ?></h3>

                        <p class="company-name">
                            <i class="fa-regular fa-building icon-motion" aria-hidden="true"></i>
                            <?= e($companyName) ?>
                        </p>

                        <p class="card-description">
                            <?= e(function_exists('mb_strimwidth')
                                ? mb_strimwidth($description, 0, 165, '…', 'UTF-8')
                                : (strlen($description) > 165 ? substr($description, 0, 162) . '...' : $description)) ?>
                        </p>

                        <div class="card-meta">
                            <div class="meta-item">
                                <i class="fa-solid fa-location-dot icon-motion" aria-hidden="true"></i>
                                <span><?= e($location !== '' ? $location : 'Location not specified') ?></span>
                            </div>
                            <div class="meta-item">
                                <i class="fa-solid fa-laptop icon-motion" aria-hidden="true"></i>
                                <span><?= e($mode !== '' ? ucfirst($mode) : 'Not specified') ?></span>
                            </div>
                            <div class="meta-item">
                                <i class="fa-solid fa-clock icon-motion" aria-hidden="true"></i>
                                <span><?= e($type !== '' ? ucwords(str_replace('-', ' ', $type)) : 'Internship') ?></span>
                            </div>
                            <div class="meta-item">
                                <i class="fa-solid fa-wallet icon-motion" aria-hidden="true"></i>
                                <span><?= e($stipend !== null && $stipend !== '' ? $stipend : 'Compensation not specified') ?></span>
                            </div>

                            <?php if ($duration !== ''): ?>
                                <div class="meta-item">
                                    <i class="fa-regular fa-calendar icon-motion" aria-hidden="true"></i>
                                    <span><?= e($duration) ?></span>
                                </div>
                            <?php endif; ?>

                            <?php if ($deadline !== null && $deadline !== ''): ?>
                                <div class="meta-item">
                                    <i class="fa-solid fa-hourglass-end icon-motion" aria-hidden="true"></i>
                                    <span>Deadline: <?= e($deadline) ?></span>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="card-bottom">
                            <button
                                class="btn btn-secondary details-button"
                                type="button"
                                data-internship="<?= e(json_encode($modalData, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP)) ?>"
                            >
                                <i class="fa-regular fa-eye icon-motion" aria-hidden="true"></i>
                                View details
                            </button>

                            <?php if ($alreadyApplied && !$isWithdrawn && !$isRejected): ?>
                                <span class="status-badge <?= $status === 'applied' ? '' : 'pending' ?>">
                                    <i class="fa-solid fa-circle-check icon-motion" aria-hidden="true"></i>
                                    <?= e(ucwords(str_replace('_', ' ', $status !== '' ? $status : 'applied'))) ?>
                                </span>

                                <?php if ($canWithdraw): ?>
                                    <form
                                        method="post"
                                        action="internships.php<?= $filterQuery ?>"
                                        onsubmit="return confirm('Are you sure you want to withdraw this application?');"
                                    >
                                        <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
                                        <input type="hidden" name="action" value="withdraw">
                                        <input type="hidden" name="internship_id" value="<?= $id ?>">
                                        <button class="btn btn-secondary" type="submit">
                                            <i class="fa-solid fa-arrow-rotate-left icon-motion" aria-hidden="true"></i>
                                            Withdraw
                                        </button>
                                    </form>
                                <?php endif; ?>

                            <?php elseif ($isWithdrawn || $isRejected): ?>
                                <span class="status-badge finished">
                                    <i class="fa-solid fa-circle-minus icon-motion" aria-hidden="true"></i>
                                    <?= e(ucfirst($status)) ?>
                                </span>

                                <button
                                    class="btn btn-primary apply-button"
                                    type="button"
                                    data-id="<?= $id ?>"
                                    data-title="<?= e($title) ?>"
                                    data-company="<?= e($companyName) ?>"
                                >
                                    <i class="fa-solid fa-paper-plane icon-motion" aria-hidden="true"></i>
                                    Apply again
                                </button>
                            <?php else: ?>
                                <button
                                    class="btn btn-primary apply-button"
                                    type="button"
                                    data-id="<?= $id ?>"
                                    data-title="<?= e($title) ?>"
                                    data-company="<?= e($companyName) ?>"
                                >
                                    <i class="fa-solid fa-paper-plane icon-motion" aria-hidden="true"></i>
                                    Apply now
                                </button>
                            <?php endif; ?>
                        </div>
                    </article>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </section>
</main>

<footer class="footer">
    Built for your next big opportunity with <span>InternPro</span>.
</footer>

<div class="modal-backdrop" id="detailsBackdrop" role="dialog" aria-modal="true" aria-labelledby="detailsTitle">
    <div class="modal">
        <div class="modal-header">
            <h3 id="detailsTitle">Internship details</h3>
            <button class="modal-close" type="button" data-close-modal aria-label="Close details">
                <i class="fa-solid fa-xmark icon-motion" aria-hidden="true"></i>
            </button>
        </div>

        <div class="modal-company" id="detailsCompany"></div>
        <div class="card-tags" id="detailsTags"></div>

        <div class="modal-section">
            <h4>Description</h4>
            <p id="detailsDescription"></p>
        </div>

        <div class="modal-section" id="responsibilitiesSection">
            <h4>Responsibilities</h4>
            <p id="detailsResponsibilities"></p>
        </div>

        <div class="modal-section" id="requirementsSection">
            <h4>Requirements</h4>
            <p id="detailsRequirements"></p>
        </div>

        <div class="modal-actions">
            <button class="btn btn-secondary" type="button" data-close-modal>Close</button>
            <button class="btn btn-primary" type="button" id="detailsApply">
                <i class="fa-solid fa-paper-plane icon-motion" aria-hidden="true"></i>
                Apply now
            </button>
        </div>
    </div>
</div>

<div class="modal-backdrop" id="applyBackdrop" role="dialog" aria-modal="true" aria-labelledby="applyTitle">
    <div class="modal">
        <div class="modal-header">
            <h3 id="applyTitle">Apply for internship</h3>
            <button class="modal-close" type="button" data-close-modal aria-label="Close application form">
                <i class="fa-solid fa-xmark icon-motion" aria-hidden="true"></i>
            </button>
        </div>

        <p class="modal-company" id="applyCompany"></p>

        <form method="post" action="internships.php<?= $filterQuery ?>" id="applicationForm">
            <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
            <input type="hidden" name="action" value="apply">
            <input type="hidden" name="internship_id" id="applyInternshipId" value="">

            <?php if (in_array('cover_letter', $applicationColumnNames ?? [], true)): ?>
                <div class="modal-section">
                    <label for="coverLetter">
                        <h4>Cover letter <span style="color:#8198b2;font-weight:400">(optional)</span></h4>
                    </label>
                    <textarea
                        id="coverLetter"
                        name="cover_letter"
                        maxlength="10000"
                        placeholder="Tell the company why you are interested in this opportunity..."
                    ></textarea>
                </div>
            <?php endif; ?>

            <p class="filter-hint">Your application will be recorded with your student account.</p>

            <div class="modal-actions">
                <button class="btn btn-secondary" type="button" data-close-modal>Cancel</button>
                <button class="btn btn-primary" type="submit" id="submitApplication">
                    <i class="fa-solid fa-paper-plane icon-motion" aria-hidden="true"></i>
                    Submit application
                </button>
            </div>
        </form>
    </div>
</div>

<script>
(() => {
    'use strict';

    const detailsBackdrop = document.getElementById('detailsBackdrop');
    const applyBackdrop = document.getElementById('applyBackdrop');
    const detailsApply = document.getElementById('detailsApply');
    const applicationForm = document.getElementById('applicationForm');

    let activeInternship = null;
    let previousFocus = null;

    function openModal(modal) {
        previousFocus = document.activeElement;
        modal.classList.add('open');
        document.body.style.overflow = 'hidden';

        const firstControl = modal.querySelector('button, textarea');
        if (firstControl) firstControl.focus();
    }

    function closeModal(modal) {
        modal.classList.remove('open');

        if (
            !detailsBackdrop.classList.contains('open') &&
            !applyBackdrop.classList.contains('open')
        ) {
            document.body.style.overflow = '';
        }

        if (previousFocus && typeof previousFocus.focus === 'function') {
            previousFocus.focus();
        }
    }

    function setText(id, value) {
        const element = document.getElementById(id);
        if (element) element.textContent = value || '';
    }

    function showDetails(data) {
        activeInternship = data;

        setText('detailsTitle', data.title || 'Internship details');
        setText('detailsCompany', data.company || 'Hiring Company');
        setText('detailsDescription', data.description || 'No description provided.');
        setText('detailsResponsibilities', data.responsibilities || 'Not specified.');
        setText('detailsRequirements', data.requirements || 'Not specified.');

        document.getElementById('responsibilitiesSection').hidden = !data.responsibilities;
        document.getElementById('requirementsSection').hidden = !data.requirements;

        const tags = document.getElementById('detailsTags');
        tags.replaceChildren();

        [
            data.category,
            data.mode,
            data.type ? data.type.replaceAll('-', ' ') : '',
            data.location,
            data.duration,
            data.stipend ? 'Compensation: ' + data.stipend : '',
            data.deadline ? 'Deadline: ' + data.deadline : ''
        ].filter(Boolean).forEach(value => {
            const tag = document.createElement('span');
            tag.className = 'tag';
            tag.textContent = value;
            tags.appendChild(tag);
        });

        openModal(detailsBackdrop);
    }

    function closeModalIfOpen(modal) {
        if (modal.classList.contains('open')) {
            modal.classList.remove('open');
        }
    }

    function showApply(id, title, company) {
        document.getElementById('applyInternshipId').value = String(id);
        setText('applyTitle', 'Apply for ' + title);
        setText('applyCompany', company || 'Hiring Company');

        closeModalIfOpen(detailsBackdrop);
        openModal(applyBackdrop);
    }

    document.querySelectorAll('.details-button').forEach(button => {
        button.addEventListener('click', () => {
            try {
                const data = JSON.parse(button.dataset.internship || '{}');
                showDetails(data);
            } catch (error) {
                console.error('Unable to open internship details.');
            }
        });
    });

    document.querySelectorAll('.apply-button').forEach(button => {
        button.addEventListener('click', () => {
            showApply(
                button.dataset.id,
                button.dataset.title,
                button.dataset.company
            );
        });
    });

    detailsApply.addEventListener('click', () => {
        if (activeInternship) {
            showApply(
                activeInternship.id,
                activeInternship.title,
                activeInternship.company
            );
        }
    });

    document.querySelectorAll('[data-close-modal]').forEach(button => {
        button.addEventListener('click', () => {
            const modal = button.closest('.modal-backdrop');
            if (modal) closeModal(modal);
        });
    });

    [detailsBackdrop, applyBackdrop].forEach(backdrop => {
        backdrop.addEventListener('click', event => {
            if (event.target === backdrop) closeModal(backdrop);
        });
    });

    document.addEventListener('keydown', event => {
        if (event.key === 'Escape') {
            if (applyBackdrop.classList.contains('open')) {
                closeModal(applyBackdrop);
            } else if (detailsBackdrop.classList.contains('open')) {
                closeModal(detailsBackdrop);
            }
        }
    });

    if (applicationForm) {
        applicationForm.addEventListener('submit', event => {
            if (!applicationForm.checkValidity()) {
                event.preventDefault();
                applicationForm.reportValidity();
                return;
            }

            const submitButton = document.getElementById('submitApplication');

            if (submitButton) {
                submitButton.disabled = true;
                submitButton.innerHTML =
                    '<i class="fa-solid fa-spinner fa-spin" aria-hidden="true"></i> Submitting...';
            }
        });
    }
})();
</script>
</body>
</html>
