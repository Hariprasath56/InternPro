<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

if (
    empty($_SESSION['user_id']) ||
    ($_SESSION['role'] ?? '') !== 'student'
) {
    header('Location: ../login.php');
    exit;
}

require_once __DIR__ . '/../config/database.php';

if (!isset($pdo) || !($pdo instanceof PDO)) {
    error_log('InternPro profile: PDO connection unavailable.');
    http_response_code(500);
    exit('Unable to connect to the database. Please try again later.');
}

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

$user_id = (int) $_SESSION['user_id'];
$user = [];
$user_data = [];
$student = [];
$profile = [];
$student_id = 0;
$user_columns = [];
$student_columns = [];
$actual_profile_columns = [];
$profile_columns = [];
$schema_notice = '';
$error_message = '';
$success_message = '';
$error_msg = '';
$success_msg = '';

if (!function_exists('profileEscape')) {
    function profileEscape($value): string
    {
        return htmlspecialchars(
            (string) ($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

if (!function_exists('profileHasColumn')) {
    function profileHasColumn(array $columns, string $field): bool
    {
        return in_array($field, $columns, true);
    }
}

try {
    foreach ([
        'users' => 'user_columns',
        'students' => 'student_columns',
        'student_profiles' => 'actual_profile_columns'
    ] as $table => $variable) {
        $statement = $pdo->query("DESCRIBE `$table`");
        $$variable = [];

        foreach ($statement->fetchAll() as $columnInfo) {
            if (isset($columnInfo['Field'])) {
                $$variable[] = $columnInfo['Field'];
            }
        }
    }

    if (
        !in_array('id', $user_columns, true) ||
        !in_array('email', $user_columns, true) ||
        !in_array('id', $student_columns, true) ||
        !in_array('user_id', $student_columns, true) ||
        !in_array('student_id', $actual_profile_columns, true)
    ) {
        throw new RuntimeException('Required database relationship columns are missing.');
    }

    $statement = $pdo->prepare(
        'SELECT * FROM users WHERE id = ? LIMIT 1'
    );
    $statement->execute([$user_id]);
    $user = $statement->fetch() ?: [];

    if (!$user) {
        header('Location: ../logout.php');
        exit;
    }

    $statement = $pdo->prepare(
        'SELECT * FROM students WHERE user_id = ? LIMIT 1'
    );
    $statement->execute([$user_id]);
    $student = $statement->fetch() ?: [];

    if (!$student) {
        throw new RuntimeException(
            'Your account does not have a linked student record.'
        );
    }

    $student_id = (int) $student['id'];

    $statement = $pdo->prepare(
        'SELECT * FROM student_profiles WHERE student_id = ? LIMIT 1'
    );
    $statement->execute([$student_id]);
    $profile = $statement->fetch() ?: [];

    $profile_columns = array_values(array_unique(array_merge(
        $student_columns,
        $actual_profile_columns
    )));
} catch (Throwable $e) {
    error_log('InternPro profile load: ' . $e->getMessage());
    http_response_code(500);
    exit('Unable to load your profile. Please verify your database schema and try again.');
}

$user_data = $user;
$name = (string) ($user['name'] ?? $_SESSION['name'] ?? 'Student');
$email = (string) ($user['email'] ?? '');
$initial = strtoupper(substr(trim($name) ?: 'S', 0, 1));

$success_message = (string) ($_SESSION['profile_flash_success'] ?? '');
unset($_SESSION['profile_flash_success']);

$csrf_token = $_SESSION['profile_csrf_token'] ?? '';
if (!is_string($csrf_token) || $csrf_token === '') {
    $csrf_token = bin2hex(random_bytes(32));
    $_SESSION['profile_csrf_token'] = $csrf_token;
}

$field_aliases = [
    'phone' => ['phone', 'phone_number', 'mobile'],
    'date_of_birth' => ['date_of_birth', 'dob'],
    'college_name' => ['college_name', 'university_name'],
    'department' => ['department', 'branch'],
    'degree' => ['degree', 'course'],
    'year_of_study' => ['year_of_study', 'study_year'],
    'cgpa' => ['cgpa', 'current_cgpa'],
    'graduation_year' => ['graduation_year'],
    'city' => ['city'],
    'state' => ['state'],
    'country' => ['country'],
    'location' => ['location', 'city'],
    'skills' => ['skills'],
    'preferred_domain' => ['preferred_domain', 'domain'],
    'preferred_location' => ['preferred_location'],
    'internship_duration' => ['internship_duration', 'preferred_duration'],
    'work_mode' => ['work_mode', 'preferred_work_mode'],
    'about' => ['about', 'bio'],
    'linkedin_url' => ['linkedin_url'],
    'github_url' => ['github_url'],
    'portfolio_url' => ['portfolio_url'],
    'headline' => ['headline'],
    'achievements' => ['achievements'],
    'certifications' => ['certifications'],
    'projects' => ['projects'],
    'available_from' => ['available_from'],
    'profile_visibility' => ['profile_visibility']
];

$field_values = [];

foreach ($field_aliases as $field => $aliases) {
    $value = '';

    foreach ($aliases as $column) {
        if (
            in_array($column, $student_columns, true) &&
            array_key_exists($column, $student) &&
            $student[$column] !== null &&
            $student[$column] !== ''
        ) {
            $value = (string) $student[$column];
            break;
        }

        if (
            in_array($column, $actual_profile_columns, true) &&
            array_key_exists($column, $profile) &&
            $profile[$column] !== null &&
            $profile[$column] !== ''
        ) {
            $value = (string) $profile[$column];
            break;
        }
    }

    $field_values[$field] = $value;
}

$field_values['location'] = implode(', ', array_filter([
    trim((string) ($student['city'] ?? '')),
    trim((string) ($student['state'] ?? '')),
    trim((string) ($student['country'] ?? ''))
], static fn($part) => $part !== ''));

if ($field_values['location'] === '') {
    $field_values['location'] = (string) (
        $student['location'] ?? $profile['location'] ?? ''
    );
}

$field_values['about'] = $field_values['about'] !== ''
    ? $field_values['about']
    : (string) ($field_values['bio'] ?? '');

$field_values['college_name'] = $field_values['college_name'] ?? '';
$field_values['year_of_study'] = $field_values['year_of_study'] ?? '';
$field_values['cgpa'] = $field_values['cgpa'] ?? '';
$field_values['preferred_domain'] = $field_values['preferred_domain'] ?? '';
$field_values['internship_duration'] = $field_values['internship_duration'] ?? '';
$field_values['work_mode'] = $field_values['work_mode'] ?? '';

$field_map = [
    'phone' => [
        'label' => 'Phone Number',
        'type' => 'tel',
        'icon' => 'bi-telephone',
        'placeholder' => 'Enter your phone number'
    ],
    'location' => [
        'label' => 'Location',
        'type' => 'text',
        'icon' => 'bi-geo-alt',
        'placeholder' => 'City, State, Country'
    ],
    'college_name' => [
        'label' => 'College / University',
        'type' => 'text',
        'icon' => 'bi-building',
        'placeholder' => 'Enter your college or university'
    ],
    'department' => [
        'label' => 'Department',
        'type' => 'text',
        'icon' => 'bi-diagram-3',
        'placeholder' => 'Enter your department'
    ],
    'degree' => [
        'label' => 'Degree',
        'type' => 'text',
        'icon' => 'bi-mortarboard',
        'placeholder' => 'Enter your degree'
    ],
    'year_of_study' => [
        'label' => 'Year of Study',
        'type' => 'text',
        'icon' => 'bi-calendar3',
        'placeholder' => 'Enter your current study year'
    ],
    'cgpa' => [
        'label' => 'Current CGPA',
        'type' => 'number',
        'icon' => 'bi-award',
        'placeholder' => 'e.g. 8.50'
    ],
    'graduation_year' => [
        'label' => 'Graduation Year',
        'type' => 'number',
        'icon' => 'bi-calendar-check',
        'placeholder' => 'e.g. 2028'
    ],
    'skills' => [
        'label' => 'Skills',
        'type' => 'textarea',
        'icon' => 'bi-stars',
        'placeholder' => 'PHP, JavaScript, MySQL'
    ],
    'preferred_domain' => [
        'label' => 'Preferred Domain',
        'type' => 'text',
        'icon' => 'bi-briefcase',
        'placeholder' => 'Web Development, Data Science...'
    ],
    'preferred_location' => [
        'label' => 'Preferred Location',
        'type' => 'text',
        'icon' => 'bi-geo',
        'placeholder' => 'Remote, Chennai, Bengaluru...'
    ],
    'internship_duration' => [
        'label' => 'Internship Duration',
        'type' => 'text',
        'icon' => 'bi-hourglass-split',
        'placeholder' => 'e.g. 3 months'
    ],
    'work_mode' => [
        'label' => 'Preferred Work Mode',
        'type' => 'select',
        'icon' => 'bi-laptop',
        'placeholder' => 'Select work mode',
        'options' => ['Remote', 'Hybrid', 'On-site', 'Any']
    ],
    'about' => [
        'label' => 'About Me',
        'type' => 'textarea',
        'icon' => 'bi-chat-square-text',
        'placeholder' => 'Tell employers about yourself'
    ],
    'linkedin_url' => [
        'label' => 'LinkedIn Profile',
        'type' => 'url',
        'icon' => 'bi-linkedin',
        'placeholder' => 'https://www.linkedin.com/in/your-profile'
    ],
    'github_url' => [
        'label' => 'GitHub Profile',
        'type' => 'url',
        'icon' => 'bi-github',
        'placeholder' => 'https://github.com/your-username'
    ],
    'portfolio_url' => [
        'label' => 'Portfolio Website',
        'type' => 'url',
        'icon' => 'bi-globe',
        'placeholder' => 'https://yourportfolio.com'
    ]
];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_profile'])) {
    $postedToken = $_POST['csrf_token'] ?? '';

    if (
        !is_string($postedToken) ||
        !hash_equals($csrf_token, $postedToken)
    ) {
        $error_message = 'Your form session expired. Refresh the page and try again.';
    } else {
        $newName = trim((string) ($_POST['name'] ?? $name));
        $newEmail = trim((string) ($_POST['email'] ?? $email));

        if ($newName === '') {
            $error_message = 'Please enter your name.';
        } elseif (mb_strlen($newName) > 150) {
            $error_message = 'Your name is too long.';
        } elseif (!filter_var($newEmail, FILTER_VALIDATE_EMAIL)) {
            $error_message = 'Please enter a valid email address.';
        } else {
            try {
                $statement = $pdo->prepare(
                    'SELECT id FROM users WHERE email = ? AND id <> ? LIMIT 1'
                );
                $statement->execute([$newEmail, $user_id]);

                if ($statement->fetch()) {
                    throw new RuntimeException(
                        'That email address is already being used by another account.'
                    );
                }

                $pdo->beginTransaction();

                $userUpdates = [];
                if (in_array('name', $user_columns, true)) {
                    $userUpdates['name'] = $newName;
                }
                if (in_array('email', $user_columns, true)) {
                    $userUpdates['email'] = $newEmail;
                }

                if ($userUpdates) {
                    $sets = [];
                    $params = [];

                    foreach ($userUpdates as $column => $value) {
                        $sets[] = "`$column` = ?";
                        $params[] = $value;
                    }

                    $params[] = $user_id;
                    $statement = $pdo->prepare(
                        'UPDATE users SET ' . implode(', ', $sets) . ' WHERE id = ?'
                    );
                    $statement->execute($params);
                }

                $studentUpdates = [];
                $profileUpdates = [];

                foreach ($field_aliases as $field => $aliases) {
                    if (!array_key_exists($field, $_POST)) {
                        continue;
                    }

                    $value = trim((string) $_POST[$field]);

                    if (mb_strlen($value) > 5000) {
                        throw new RuntimeException(
                            'One of your profile fields is too long.'
                        );
                    }

                    if ($field === 'location' && $value !== '') {
                        $parts = array_map('trim', explode(',', $value, 3));

                        if (in_array('city', $student_columns, true)) {
                            $studentUpdates['city'] = $parts[0] ?? '';
                        }
                        if (isset($parts[1]) && in_array('state', $student_columns, true)) {
                            $studentUpdates['state'] = $parts[1];
                        }
                        if (isset($parts[2]) && in_array('country', $student_columns, true)) {
                            $studentUpdates['country'] = $parts[2];
                        }
                        continue;
                    }

                    if (in_array($field, ['linkedin_url', 'github_url', 'portfolio_url'], true) && $value !== '') {
                        $scheme = strtolower((string) parse_url($value, PHP_URL_SCHEME));

                        if (
                            !filter_var($value, FILTER_VALIDATE_URL) ||
                            !in_array($scheme, ['http', 'https'], true)
                        ) {
                            throw new RuntimeException(
                                'Please enter a valid HTTP or HTTPS URL for ' . $field . '.'
                            );
                        }
                    }

                    if ($field === 'cgpa' && $value !== '') {
                        if (!is_numeric($value) || (float) $value < 0 || (float) $value > 10) {
                            throw new RuntimeException('CGPA must be between 0 and 10.');
                        }
                    }

                    if ($field === 'graduation_year' && $value !== '') {
                        $year = filter_var($value, FILTER_VALIDATE_INT);

                        if ($year === false || $year < 2000 || $year > 2100) {
                            throw new RuntimeException('Please enter a valid graduation year.');
                        }
                    }

                    if ($field === 'work_mode' && $value !== '') {
                        $modeMap = [
                            'Remote' => 'remote',
                            'Hybrid' => 'hybrid',
                            'On-site' => 'onsite',
                            'Onsite' => 'onsite',
                            'Any' => 'any',
                            'remote' => 'remote',
                            'hybrid' => 'hybrid',
                            'onsite' => 'onsite',
                            'any' => 'any'
                        ];

                        if (!isset($modeMap[$value])) {
                            throw new RuntimeException('Please select a valid work mode.');
                        }

                        $value = $modeMap[$value];
                    }

                    $destination = null;
                    $columnName = null;

                    foreach ($aliases as $candidate) {
                        if (in_array($candidate, $student_columns, true)) {
                            $destination = 'students';
                            $columnName = $candidate;
                            break;
                        }

                        if (in_array($candidate, $actual_profile_columns, true)) {
                            $destination = 'student_profiles';
                            $columnName = $candidate;
                            break;
                        }
                    }

                    if ($destination === 'students' && $columnName !== null) {
                        $studentUpdates[$columnName] = $value;
                    } elseif ($destination === 'student_profiles' && $columnName !== null) {
                        $profileUpdates[$columnName] = $value;
                    }
                }

                unset($studentUpdates['name'], $studentUpdates['email']);
                unset($profileUpdates['name'], $profileUpdates['email']);

                if ($studentUpdates) {
                    $sets = [];
                    $params = [];

                    foreach ($studentUpdates as $column => $value) {
                        $sets[] = "`$column` = ?";
                        $params[] = $value;
                    }

                    $params[] = $user_id;

                    $statement = $pdo->prepare(
                        'UPDATE students SET ' . implode(', ', $sets) . ' WHERE user_id = ?'
                    );
                    $statement->execute($params);
                }

                if ($profileUpdates) {
                    $statement = $pdo->prepare(
                        'SELECT id FROM student_profiles WHERE student_id = ? LIMIT 1'
                    );
                    $statement->execute([$student_id]);
                    $existingProfileId = $statement->fetchColumn();

                    if ($existingProfileId !== false) {
                        $sets = [];
                        $params = [];

                        foreach ($profileUpdates as $column => $value) {
                            $sets[] = "`$column` = ?";
                            $params[] = $value;
                        }

                        $params[] = $student_id;

                        $statement = $pdo->prepare(
                            'UPDATE student_profiles SET ' .
                            implode(', ', $sets) .
                            ' WHERE student_id = ?'
                        );
                        $statement->execute($params);
                    } else {
                        $insertValues = ['student_id' => $student_id] + $profileUpdates;
                        $insertColumns = array_keys($insertValues);
                        $quotedColumns = array_map(
                            static fn($column) => "`$column`",
                            $insertColumns
                        );
                        $placeholders = array_fill(0, count($insertColumns), '?');

                        $statement = $pdo->prepare(
                            'INSERT INTO student_profiles (' .
                            implode(', ', $quotedColumns) .
                            ') VALUES (' . implode(', ', $placeholders) . ')'
                        );
                        $statement->execute(array_values($insertValues));
                    }
                }

                $pdo->commit();

                $_SESSION['name'] = $newName;
                $_SESSION['profile_flash_success'] = 'Your profile has been updated successfully.';

                header('Location: profile.php');
                exit;
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }

                error_log('InternPro profile save: ' . $e->getMessage());

                $error_message = $e instanceof RuntimeException
                    ? $e->getMessage()
                    : 'Unable to save your profile. Please verify your database schema and try again.';
            }
        }
    }
}

$success_msg = $success_message;
$error_msg = $error_message;

$completionWeights = [
    'email' => 2,
    'name' => 6,
    'phone' => 5,
    'college_name' => 7,
    'degree' => 5,
    'department' => 5,
    'year_of_study' => 4,
    'graduation_year' => 4,
    'cgpa' => 4,
    'location' => 4,
    'skills' => 8,
    'about' => 12,
    'linkedin_url' => 4,
    'github_url' => 4,
    'portfolio_url' => 4,
    'preferred_domain' => 4,
    'preferred_location' => 3,
    'internship_duration' => 3,
    'work_mode' => 3
];

$completionTotal = array_sum($completionWeights);
$completionEarned = 0;

foreach ($completionWeights as $field => $weight) {
    $value = $field === 'email'
        ? $email
        : ($field === 'name' ? $name : ($field_values[$field] ?? ''));

    if (trim((string) $value) !== '') {
        $completionEarned += $weight;
    }
}

$completion_percentage = $completionTotal > 0
    ? (int) round(($completionEarned / $completionTotal) * 100)
    : 0;

$completion_percentage = max(0, min(100, $completion_percentage));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#020b1a">
    <meta name="description" content="Manage your InternPro student profile and preview your professional details live.">
    <title>My Profile | InternPro</title>

    <link rel="icon" type="image/jpeg" href="../assets/logo.jpg">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <style>
        :root {
            --navy-950: #020b1a;
            --navy-900: #071e3d;
            --navy-850: #0a2a50;
            --navy-800: #0d3b66;
            --blue: #0077b6;
            --cyan: #00b4d8;
            --cyan-light: #38bdf8;
            --cyan-bright: #67e8f9;
            --text: #f8fafc;
            --muted: #94a3b8;
            --line: rgba(148, 163, 184, .16);
            --glass: rgba(7, 30, 61, .72);
            --transition: .28s ease;
        }

        *, *::before, *::after {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        html { scroll-behavior: smooth; }

        body {
            min-height: 100vh;
            overflow-x: hidden;
            color: var(--text);
            font-family: 'Poppins', sans-serif;
            line-height: 1.6;
            background:
                radial-gradient(ellipse at 8% 8%, rgba(0,180,216,.14), transparent 34%),
                radial-gradient(ellipse at 96% 78%, rgba(0,119,182,.15), transparent 34%),
                linear-gradient(135deg, var(--navy-950), var(--navy-900) 55%, #041326);
        }

        body::before {
            content: "";
            position: fixed;
            inset: 0;
            z-index: -2;
            pointer-events: none;
            opacity: .22;
            background-image:
                linear-gradient(rgba(56,189,248,.05) 1px, transparent 1px),
                linear-gradient(90deg, rgba(56,189,248,.05) 1px, transparent 1px);
            background-size: 48px 48px;
            mask-image: linear-gradient(to bottom, black, transparent 90%);
        }

        a { color: inherit; text-decoration: none; }

        button, input, textarea, select {
            font: inherit;
            -webkit-tap-highlight-color: transparent;
        }

        a:focus-visible, button:focus-visible, input:focus-visible,
        textarea:focus-visible, select:focus-visible {
            outline: 2px solid var(--cyan-bright);
            outline-offset: 4px;
        }

        .orb {
            position: fixed;
            z-index: -1;
            width: 330px;
            height: 330px;
            border-radius: 50%;
            filter: blur(95px);
            opacity: .12;
            pointer-events: none;
            animation: floatOrb 13s ease-in-out infinite alternate;
        }

        .orb.one { top: 10%; left: -180px; background: var(--cyan); }
        .orb.two { right: -180px; bottom: 5%; background: var(--blue); animation-delay: -5s; }

        @keyframes floatOrb {
            from { transform: translate3d(0, 0, 0); }
            to { transform: translate3d(35px, -25px, 0); }
        }

        @keyframes fadeUp {
            from { opacity: 0; transform: translateY(15px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes fillBar {
            from { width: 0; }
        }

        @keyframes iconPulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.12); }
        }

        /* Navbar matches the dashboard */

        .site-header {
            position: sticky;
            top: 0;
            z-index: 100;
            padding: 12px 5%;
            border-bottom: 1px solid rgba(148,163,184,.12);
            background: rgba(2,11,26,.86);
            backdrop-filter: blur(22px);
            -webkit-backdrop-filter: blur(22px);
        }

        .navbar {
            width: min(1400px, 100%);
            min-height: 52px;
            margin: auto;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 22px;
        }

        .brand { display: inline-flex; align-items: center; gap: 10px; flex-shrink: 0; }

        .brand img {
            width: 46px;
            height: 46px;
            object-fit: cover;
            object-position: center;
            border-radius: 50%;
            border: 2px solid rgba(56,189,248,.65);
            background: var(--navy-900);
            box-shadow: 0 0 0 3px rgba(0,180,216,.08), 0 0 15px rgba(0,180,216,.18);
            transition: transform var(--transition), border-color var(--transition), box-shadow var(--transition);
        }

        .brand:hover img {
            transform: rotate(-7deg) scale(1.08);
            border-color: var(--cyan-bright);
            box-shadow: 0 0 0 4px rgba(0,180,216,.12), 0 0 23px rgba(0,180,216,.45);
        }

        .brand-name {
            font-family: 'Space Grotesk', sans-serif;
            font-size: 1.4rem;
            font-weight: 700;
            letter-spacing: -.7px;
        }

        .brand-name span { color: var(--cyan-light); }

        .nav-links { display: flex; align-items: center; gap: 5px; }

        .nav-link {
            position: relative;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 11px 13px;
            border: 1px solid transparent;
            border-radius: 12px;
            color: var(--muted);
            font-size: .84rem;
            font-weight: 500;
            transition: color var(--transition), background var(--transition), border-color var(--transition), transform var(--transition);
        }

        .nav-link i { transition: transform var(--transition), color var(--transition), filter var(--transition); }

        .nav-link:hover {
            color: var(--text);
            background: rgba(56,189,248,.07);
            border-color: var(--line);
            transform: translateY(-2px);
        }

        .nav-link:hover i {
            color: var(--cyan-light);
            transform: translateY(-2px) rotate(-5deg);
            filter: drop-shadow(0 0 7px rgba(0,180,216,.6));
        }

        .nav-link.active {
            color: var(--cyan-bright);
            border-color: rgba(0,180,216,.2);
            background: rgba(0,180,216,.09);
        }

        .nav-link.active::after {
            content: "";
            position: absolute;
            bottom: -13px;
            left: 25%;
            width: 50%;
            height: 2px;
            border-radius: 5px;
            background: var(--cyan);
            box-shadow: 0 0 12px rgba(0,180,216,.75);
        }

        .logout-link { border-color: rgba(56,189,248,.2); color: #d8e9f8; }

        .menu-toggle {
            display: none;
            width: 44px;
            height: 44px;
            align-items: center;
            justify-content: center;
            border: 1px solid var(--line);
            border-radius: 12px;
            color: var(--text);
            background: rgba(7,30,61,.85);
            cursor: pointer;
        }

        .menu-toggle i { font-size: 1.3rem; transition: transform var(--transition); }
        .menu-toggle:hover i { color: var(--cyan-light); transform: rotate(90deg); }

        .container { width: min(1400px, 92%); margin: 0 auto; }

        .page-head {
            display: flex;
            align-items: end;
            justify-content: space-between;
            gap: 20px;
            margin: 38px 0 25px;
            animation: fadeUp .55s ease both;
        }

        .eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 9px;
            color: var(--cyan);
            font-size: .73rem;
            font-weight: 700;
            letter-spacing: 1.6px;
            text-transform: uppercase;
        }

        .eyebrow i { animation: iconPulse 2.5s ease-in-out infinite; }

        h1, h2, h3 { font-family: 'Space Grotesk', sans-serif; }

        .page-head h1 { font-size: clamp(1.8rem, 4vw, 2.7rem); line-height: 1.2; letter-spacing: -1px; }
        .page-head p { margin-top: 8px; color: var(--muted); font-size: .9rem; }

        .layout {
            display: grid;
            grid-template-columns: minmax(0, 1.45fr) minmax(310px, .75fr);
            align-items: start;
            gap: 23px;
            padding-bottom: 65px;
        }

        .left-column, .right-column { min-width: 0; display: grid; gap: 20px; }

        .glass-card {
            min-width: 0;
            border: 1px solid var(--line);
            border-radius: 22px;
            background: var(--glass);
            box-shadow: 0 15px 40px rgba(0,0,0,.14);
            backdrop-filter: blur(17px);
            -webkit-backdrop-filter: blur(17px);
            animation: fadeUp .55s ease both;
        }

        .card-head {
            padding: 23px 25px 19px;
            border-bottom: 1px solid rgba(148,163,184,.11);
        }

        .card-head-row { display: flex; align-items: center; gap: 13px; }

        .section-icon {
            width: 43px;
            height: 43px;
            flex-shrink: 0;
            display: grid;
            place-items: center;
            border: 1px solid rgba(56,189,248,.2);
            border-radius: 14px;
            color: var(--cyan-light);
            background: rgba(0,180,216,.09);
            transition: transform var(--transition), box-shadow var(--transition);
        }

        .section-icon i { font-size: 1.15rem; transition: transform var(--transition); }
        .glass-card:hover .section-icon { box-shadow: 0 0 20px rgba(0,180,216,.08); }
        .glass-card:hover .section-icon i { transform: scale(1.1) rotate(-5deg); }

        .card-head h2 { font-size: 1.08rem; }
        .card-head p { margin-top: 4px; color: var(--muted); font-size: .79rem; }

        .card-body { padding: 24px 25px 26px; }

        .alert {
            display: flex;
            align-items: flex-start;
            gap: 10px;
            padding: 14px 16px;
            margin-bottom: 20px;
            border-radius: 13px;
            font-size: .82rem;
            line-height: 1.7;
        }

        .alert i { font-size: 1.1rem; }
        .alert-success { color: #bbf7d0; background: rgba(22,163,74,.1); border: 1px solid rgba(74,222,128,.22); }
        .alert-error { color: #fecaca; background: rgba(220,38,38,.1); border: 1px solid rgba(248,113,113,.22); }
        .alert-info { color: #bae6fd; background: rgba(0,180,216,.07); border: 1px solid rgba(56,189,248,.2); }

        .form-section + .form-section {
            margin-top: 28px;
            padding-top: 25px;
            border-top: 1px solid rgba(148,163,184,.12);
        }

        .form-section-title {
            display: flex;
            align-items: center;
            gap: 9px;
            margin-bottom: 18px;
            color: var(--cyan-bright);
            font-size: .88rem;
            font-weight: 600;
        }

        .form-section-title i { font-size: 1.05rem; }

        .form-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 18px; }
        .field { min-width: 0; }
        .field.full { grid-column: 1 / -1; }

        .field label {
            display: flex;
            align-items: center;
            gap: 7px;
            margin-bottom: 8px;
            color: #dbeafe;
            font-size: .8rem;
            font-weight: 500;
        }

        .field label i { color: var(--cyan-light); transition: transform var(--transition), filter var(--transition); }
        .field:focus-within label i { transform: scale(1.13); filter: drop-shadow(0 0 7px rgba(0,180,216,.45)); }

        .field input, .field textarea, .field select {
            width: 100%;
            min-width: 0;
            padding: 12px 13px;
            border: 1px solid rgba(148,163,184,.19);
            border-radius: 12px;
            color: var(--text);
            background: rgba(2,11,26,.48);
            font-size: .83rem;
            transition: border-color var(--transition), box-shadow var(--transition), background var(--transition);
        }

        .field input::placeholder, .field textarea::placeholder { color: #647b94; }

        .field input:focus, .field textarea:focus, .field select:focus {
            outline: none;
            border-color: rgba(56,189,248,.62);
            background: rgba(2,11,26,.72);
            box-shadow: 0 0 0 3px rgba(0,180,216,.08);
        }

        .field textarea { min-height: 125px; resize: vertical; line-height: 1.7; }
        .field select { cursor: pointer; }
        .field select option { color: var(--text); background: var(--navy-900); }

        .field-help { display: block; margin-top: 6px; color: var(--muted); font-size: .7rem; line-height: 1.6; }

        .save-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 14px;
            margin-top: 28px;
            padding-top: 22px;
            border-top: 1px solid rgba(148,163,184,.12);
        }

        .save-note { color: var(--muted); font-size: .75rem; }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 9px;
            min-height: 46px;
            padding: 11px 18px;
            border: 1px solid transparent;
            border-radius: 12px;
            font-size: .83rem;
            font-weight: 600;
            cursor: pointer;
            transition: transform var(--transition), box-shadow var(--transition), background var(--transition);
        }

        .btn i { transition: transform var(--transition); }
        .btn:hover { transform: translateY(-3px); }
        .btn:hover i { transform: translateX(3px); }

        .btn-primary {
            color: #021522;
            background: linear-gradient(110deg, var(--cyan), var(--cyan-light));
            box-shadow: 0 8px 22px rgba(0,180,216,.14);
        }

        .btn-primary:hover { box-shadow: 0 12px 28px rgba(0,180,216,.27); }

        /* Completion card */

        .completion-card { padding: 24px; }

        .completion-top { display: flex; align-items: center; justify-content: space-between; gap: 15px; }

        .completion-top h2 { font-size: 1.05rem; }
        .completion-top p { margin-top: 4px; color: var(--muted); font-size: .76rem; }

        .completion-number {
            flex-shrink: 0;
            color: var(--cyan-bright);
            font-family: 'Space Grotesk', sans-serif;
            font-size: 1.75rem;
            font-weight: 700;
            letter-spacing: -1px;
            text-shadow: 0 0 18px rgba(0,180,216,.2);
        }

        .progress-track {
            height: 11px;
            overflow: hidden;
            margin-top: 21px;
            border: 1px solid rgba(56,189,248,.12);
            border-radius: 999px;
            background: rgba(2,11,26,.75);
        }

        .progress-fill {
            width: 0;
            height: 100%;
            border-radius: inherit;
            background: linear-gradient(90deg, var(--blue), var(--cyan), var(--cyan-bright));
            box-shadow: 0 0 16px rgba(0,180,216,.38);
            transition: width .6s cubic-bezier(.22,1,.36,1);
        }

        .completion-foot {
            display: flex;
            justify-content: space-between;
            gap: 10px;
            margin-top: 10px;
            color: var(--muted);
            font-size: .72rem;
        }

        .completion-hint { margin-top: 14px; color: #b6c8db; font-size: .76rem; line-height: 1.7; }

        /* Live preview card */

        .preview-card { overflow: hidden; }

        .preview-banner {
            position: relative;
            height: 90px;
            overflow: hidden;
            background:
                radial-gradient(circle at 82% 10%, rgba(56,189,248,.28), transparent 35%),
                linear-gradient(120deg, #0d3b66, #041326);
        }

        .preview-banner::before, .preview-banner::after {
            content: "";
            position: absolute;
            border: 1px solid rgba(56,189,248,.22);
            border-radius: 50%;
        }

        .preview-banner::before { width: 160px; height: 160px; top: -88px; right: 12%; }
        .preview-banner::after { width: 220px; height: 220px; top: -115px; right: 4%; }

        .preview-main { padding: 0 23px 23px; }

        .avatar {
            display: grid;
            place-items: center;
            width: 78px;
            height: 78px;
            margin-top: -39px;
            position: relative;
            border: 3px solid #0a2a50;
            border-radius: 50%;
            color: #021522;
            background: linear-gradient(135deg, var(--cyan), var(--cyan-light));
            box-shadow: 0 0 0 3px rgba(0,180,216,.14), 0 8px 25px rgba(0,0,0,.25);
            font-family: 'Space Grotesk', sans-serif;
            font-size: 1.7rem;
            font-weight: 700;
        }

        .preview-name {
            overflow-wrap: anywhere;
            margin-top: 14px;
            font-size: 1.25rem;
            line-height: 1.35;
        }

        .preview-degree { margin-top: 6px; color: var(--cyan-light); font-size: .81rem; overflow-wrap: anywhere; }
        .preview-college { display: flex; align-items: flex-start; gap: 8px; margin-top: 9px; color: var(--muted); font-size: .77rem; overflow-wrap: anywhere; }
        .preview-college i { flex-shrink: 0; color: var(--cyan); margin-top: 3px; }

        .preview-divider { height: 1px; margin: 19px 0; background: rgba(148,163,184,.13); }

        .preview-label {
            margin-bottom: 9px;
            color: var(--muted);
            font-size: .7rem;
            font-weight: 700;
            letter-spacing: 1.2px;
            text-transform: uppercase;
        }

        .preview-bio {
            color: #d3dfeb;
            font-size: .8rem;
            line-height: 1.8;
            white-space: pre-wrap;
            overflow-wrap: anywhere;
        }

        .preview-skills { display: flex; flex-wrap: wrap; gap: 7px; }

        .skill-chip {
            max-width: 100%;
            overflow-wrap: anywhere;
            padding: 6px 9px;
            border: 1px solid rgba(56,189,248,.18);
            border-radius: 9px;
            color: #c9f5ff;
            background: rgba(0,180,216,.07);
            font-size: .7rem;
        }

        .preview-empty { color: #71869c; font-size: .79rem; font-style: italic; }

        .social-links { display: flex; flex-wrap: wrap; gap: 8px; }

        .social-preview {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            max-width: 100%;
            padding: 8px 10px;
            border: 1px solid rgba(56,189,248,.19);
            border-radius: 10px;
            color: var(--cyan-light);
            background: rgba(0,180,216,.06);
            font-size: .75rem;
            overflow-wrap: anywhere;
            transition: transform var(--transition), background var(--transition);
        }

        .social-preview:hover { transform: translateY(-2px); background: rgba(0,180,216,.12); }
        .social-preview i { transition: transform var(--transition); }
        .social-preview:hover i { transform: scale(1.12); }

        .preview-details { display: grid; gap: 11px; }
        .preview-detail { display: flex; align-items: flex-start; gap: 10px; color: #d3dfeb; font-size: .78rem; overflow-wrap: anywhere; }
        .preview-detail i { width: 16px; flex-shrink: 0; color: var(--cyan-light); margin-top: 3px; }

        .preview-note { margin-top: 18px; padding: 11px 12px; border-radius: 11px; color: var(--muted); background: rgba(2,11,26,.35); font-size: .7rem; line-height: 1.7; }
        .preview-note i { color: var(--cyan); margin-right: 5px; }

        .site-footer {
            padding: 23px 5%;
            border-top: 1px solid rgba(148,163,184,.1);
            color: var(--muted);
            background: rgba(2,11,26,.42);
            text-align: center;
            font-size: .8rem;
        }

        .site-footer span { color: var(--cyan-light); }

        @media (max-width: 1100px) {
            .nav-link { padding: 10px 9px; font-size: .79rem; }
            .layout { grid-template-columns: minmax(0, 1.2fr) minmax(285px, .8fr); gap: 16px; }
            .card-body { padding: 21px; }
        }

        @media (max-width: 850px) {
            .site-header { padding: 10px 4%; }
            .navbar { position: relative; flex-wrap: wrap; }
            .menu-toggle { display: inline-flex; }
            .nav-links {
                position: absolute;
                top: calc(100% + 12px);
                right: 0;
                left: 0;
                display: none;
                flex-direction: column;
                align-items: stretch;
                padding: 12px;
                border: 1px solid var(--line);
                border-radius: 16px;
                background: rgba(2,11,26,.97);
                box-shadow: 0 18px 45px rgba(0,0,0,.35);
            }
            .nav-links.open { display: flex; animation: fadeUp .22s ease both; }
            .nav-link { padding: 12px 14px; }
            .nav-link.active::after { display: none; }
            .layout { grid-template-columns: 1fr; }
            .right-column { grid-template-columns: repeat(2, minmax(0, 1fr)); align-items: start; }
            .preview-card { grid-column: 1 / -1; }
        }

        @media (max-width: 560px) {
            .container { width: 92%; }
            .page-head { align-items: flex-start; flex-direction: column; margin-top: 28px; }
            .form-grid { grid-template-columns: 1fr; gap: 15px; }
            .field.full { grid-column: auto; }
            .card-head { padding: 19px; }
            .card-body { padding: 19px; }
            .completion-card { padding: 20px; }
            .right-column { grid-template-columns: 1fr; }
            .preview-card { grid-column: auto; }
            .save-row { align-items: stretch; flex-direction: column; }
            .save-row .btn { width: 100%; }
        }

        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                scroll-behavior: auto !important;
                animation-duration: .01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: .01ms !important;
            }
        }
    </style>
</head>

<body>
    <div class="orb one" aria-hidden="true"></div>
    <div class="orb two" aria-hidden="true"></div>

    <header class="site-header">
        <nav class="navbar" aria-label="Main navigation">
            <a class="brand" href="dashboard.php" aria-label="InternPro dashboard">
                <img
                    src="../assets/logo.jpg"
                    alt="InternPro logo"
                    width="46"
                    height="46"
                    onerror="this.style.display='none';"
                >
                <span class="brand-name">Intern<span>Pro</span></span>
            </a>

            <button
                class="menu-toggle"
                id="menuToggle"
                type="button"
                aria-label="Open navigation menu"
                aria-controls="navLinks"
                aria-expanded="false"
            >
                <i class="bi bi-list" aria-hidden="true"></i>
            </button>

            <div class="nav-links" id="navLinks">
                <a class="nav-link" href="dashboard.php">
                    <i class="bi bi-grid-1x2-fill" aria-hidden="true"></i>
                    Dashboard
                </a>
                <a class="nav-link active" href="profile.php" aria-current="page">
                    <i class="bi bi-person-circle" aria-hidden="true"></i>
                    My Profile
                </a>
                <a class="nav-link" href="internships.php">
                    <i class="bi bi-briefcase-fill" aria-hidden="true"></i>
                    Internships
                </a>
                <a class="nav-link" href="applications.php">
                    <i class="bi bi-file-earmark-check-fill" aria-hidden="true"></i>
                    Applications
                </a>
                <a class="nav-link logout-link" href="../logout.php">
                    <i class="bi bi-box-arrow-right" aria-hidden="true"></i>
                    Logout
                </a>
            </div>
        </nav>
    </header>

    <main class="container">
        <section class="page-head">
            <div>
                <span class="eyebrow">
                    <i class="bi bi-person-vcard" aria-hidden="true"></i>
                    Your professional identity
                </span>
                <h1>My <span class="gradient-text">Profile</span></h1>
                <p>Update your details and see your professional profile take shape instantly.</p>
            </div>
        </section>

        <?php if ($success_message !== ''): ?>
            <div class="alert alert-success" role="status">
                <i class="bi bi-check-circle-fill" aria-hidden="true"></i>
                <div><?= profileEscape($success_message) ?></div>
            </div>
        <?php endif; ?>

        <?php if ($error_message !== ''): ?>
            <div class="alert alert-error" role="alert">
                <i class="bi bi-exclamation-triangle-fill" aria-hidden="true"></i>
                <div><?= profileEscape($error_message) ?></div>
            </div>
        <?php endif; ?>

        <?php if ($schema_notice !== ''): ?>
            <div class="alert alert-info" role="status">
                <i class="bi bi-info-circle-fill" aria-hidden="true"></i>
                <div><?= profileEscape($schema_notice) ?></div>
            </div>
        <?php endif; ?>

        <div class="layout">

            <!-- LEFT: editable profile form -->
            <div class="left-column">
                <section class="glass-card">
                    <div class="card-head">
                        <div class="card-head-row">
                            <div class="section-icon">
                                <i class="bi bi-person-gear" aria-hidden="true"></i>
                            </div>
                            <div>
                                <h2>Edit Your Details</h2>
                                <p>Your preview updates as you type. Save to store your changes.</p>
                            </div>
                        </div>
                    </div>

                    <div class="card-body">
                        <form method="POST" action="profile.php" id="profileForm">
                            <input type="hidden" name="csrf_token" value="<?= profileEscape($csrf_token) ?>">

                            <div class="form-section">
                                <div class="form-section-title">
                                    <i class="bi bi-person-fill" aria-hidden="true"></i>
                                    Personal Information
                                </div>

                                <div class="form-grid">
                                    <div class="field">
                                        <label for="name"><i class="bi bi-person" aria-hidden="true"></i> Full Name *</label>
                                        <input
                                            id="name"
                                            name="name"
                                            type="text"
                                            maxlength="150"
                                            autocomplete="name"
                                            required
                                            value="<?= profileEscape($name) ?>"
                                            data-preview="name"
                                            placeholder="Enter your full name"
                                        >
                                    </div>

                                    <div class="field">
                                        <label for="email"><i class="bi bi-envelope" aria-hidden="true"></i> Email Address *</label>
                                        <input
                                            id="email"
                                            name="email"
                                            type="email"
                                            maxlength="254"
                                            autocomplete="email"
                                            required
                                            value="<?= profileEscape($email) ?>"
                                            data-preview="email"
                                            placeholder="you@example.com"
                                        >
                                        <span class="field-help">Email adds 2% to your profile completion.</span>
                                    </div>

                                    <?php
                                    $personal_fields = [
                                        'phone',
                                        'location'
                                    ];

                                    foreach ($personal_fields as $field):
                                        $config = $field_map[$field];
                                    ?>
                                        <div class="field">
                                            <label for="<?= profileEscape($field) ?>">
                                                <i class="bi <?= profileEscape($config['icon']) ?>" aria-hidden="true"></i>
                                                <?= profileEscape($config['label']) ?>
                                            </label>
                                            <input
                                                id="<?= profileEscape($field) ?>"
                                                name="<?= profileEscape($field) ?>"
                                                type="<?= profileEscape($config['type']) ?>"
                                                maxlength="5000"
                                                value="<?= profileEscape($field_values[$field]) ?>"
                                                data-preview="<?= profileEscape($field) ?>"
                                                placeholder="<?= profileEscape($config['placeholder']) ?>"
                                            >
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>

                            <div class="form-section">
                                <div class="form-section-title">
                                    <i class="bi bi-mortarboard-fill" aria-hidden="true"></i>
                                    Education
                                </div>

                                <div class="form-grid">
                                    <?php
                                    foreach (
                                        ['college_name', 'department', 'degree', 'year_of_study', 'cgpa', 'graduation_year']
                                        as $field
                                    ):
                                        $config = $field_map[$field];
                                    ?>
                                        <div class="field">
                                            <label for="<?= profileEscape($field) ?>">
                                                <i class="bi <?= profileEscape($config['icon']) ?>" aria-hidden="true"></i>
                                                <?= profileEscape($config['label']) ?>
                                            </label>
                                            <input
                                                id="<?= profileEscape($field) ?>"
                                                name="<?= profileEscape($field) ?>"
                                                type="<?= profileEscape($config['type']) ?>"
                                                maxlength="5000"
                                                <?php if ($field === 'graduation_year'): ?>
                                                    min="2000" max="2100"
                                                <?php endif; ?>
                                                value="<?= profileEscape($field_values[$field]) ?>"
                                                data-preview="<?= profileEscape($field) ?>"
                                                placeholder="<?= profileEscape($config['placeholder']) ?>"
                                            >
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>

                            <div class="form-section">
                                <div class="form-section-title">
                                    <i class="bi bi-stars" aria-hidden="true"></i>
                                    Skills and Preferences
                                </div>

                                <div class="form-grid">
                                    <?php
                                    foreach (
                                        ['skills', 'preferred_domain', 'preferred_location', 'internship_duration', 'work_mode']
                                        as $field
                                    ):
                                        $config = $field_map[$field];
                                    ?>
                                        <div class="field <?= $config['type'] === 'textarea' ? 'full' : '' ?>">
                                            <label for="<?= profileEscape($field) ?>">
                                                <i class="bi <?= profileEscape($config['icon']) ?>" aria-hidden="true"></i>
                                                <?= profileEscape($config['label']) ?>
                                            </label>

                                            <?php if ($config['type'] === 'textarea'): ?>
                                                <textarea
                                                    id="<?= profileEscape($field) ?>"
                                                    name="<?= profileEscape($field) ?>"
                                                    maxlength="5000"
                                                    data-preview="<?= profileEscape($field) ?>"
                                                    placeholder="<?= profileEscape($config['placeholder']) ?>"
                                                ><?= profileEscape($field_values[$field]) ?></textarea>
                                                <span class="field-help">Separate skills with commas for individual preview tags.</span>
                                            <?php elseif ($config['type'] === 'select'): ?>
                                                <select
                                                    id="<?= profileEscape($field) ?>"
                                                    name="<?= profileEscape($field) ?>"
                                                    data-preview="<?= profileEscape($field) ?>"
                                                >
                                                    <option value="">Select work mode</option>
                                                    <?php foreach ($config['options'] as $option): ?>
                                                        <option
                                                            value="<?= profileEscape($option) ?>"
                                                            <?= $field_values[$field] === $option ? 'selected' : '' ?>
                                                        >
                                                            <?= profileEscape($option) ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            <?php else: ?>
                                                <input
                                                    id="<?= profileEscape($field) ?>"
                                                    name="<?= profileEscape($field) ?>"
                                                    type="<?= profileEscape($config['type']) ?>"
                                                    maxlength="5000"
                                                    value="<?= profileEscape($field_values[$field]) ?>"
                                                    data-preview="<?= profileEscape($field) ?>"
                                                    placeholder="<?= profileEscape($config['placeholder']) ?>"
                                                >
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; ?>

                                    <div class="field full">
                                        <label for="about">
                                            <i class="bi bi-chat-square-text" aria-hidden="true"></i>
                                            About Me
                                        </label>
                                        <textarea
                                            id="about"
                                            name="about"
                                            maxlength="5000"
                                            data-preview="about"
                                            placeholder="<?= profileEscape($field_map['about']['placeholder']) ?>"
                                        ><?= profileEscape($field_values['about']) ?></textarea>
                                        <span class="field-help">Write a short introduction, your interests, and what you want to achieve.</span>
                                    </div>
                                </div>
                            </div>

                            <div class="form-section">
                                <div class="form-section-title">
                                    <i class="bi bi-link-45deg" aria-hidden="true"></i>
                                    Professional Links
                                </div>

                                <div class="form-grid">
                                    <?php
                                    foreach (
                                        ['linkedin_url', 'github_url', 'portfolio_url']
                                        as $field
                                    ):
                                        $config = $field_map[$field];
                                    ?>
                                        <div class="field full">
                                            <label for="<?= profileEscape($field) ?>">
                                                <i class="bi <?= profileEscape($config['icon']) ?>" aria-hidden="true"></i>
                                                <?= profileEscape($config['label']) ?>
                                            </label>
                                            <input
                                                id="<?= profileEscape($field) ?>"
                                                name="<?= profileEscape($field) ?>"
                                                type="url"
                                                maxlength="5000"
                                                value="<?= profileEscape($field_values[$field]) ?>"
                                                data-preview="<?= profileEscape($field) ?>"
                                                placeholder="<?= profileEscape($config['placeholder']) ?>"
                                            >
                                            <?php if (!profileHasColumn($profile_columns, $field)): ?>
                                                <span class="field-help">This link needs the <code><?= profileEscape($field) ?></code> database column before it can be saved.</span>
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>

                            <div class="save-row">
                                <span class="save-note">
                                    <i class="bi bi-shield-check" aria-hidden="true"></i>
                                    Your profile changes are saved to your account.
                                </span>

                                <button
                                    class="btn btn-primary"
                                    type="submit"
                                    name="save_profile"
                                    value="1"
                                >
                                    <i class="bi bi-cloud-check" aria-hidden="true"></i>
                                    Save Profile
                                    <i class="bi bi-arrow-right" aria-hidden="true"></i>
                                </button>
                            </div>
                        </form>
                    </div>
                </section>
            </div>

            <!-- RIGHT: completion and live preview -->
            <aside class="right-column" aria-label="Profile preview and completion">

                <section class="glass-card completion-card">
                    <div class="completion-top">
                        <div>
                            <h2>Profile Completion</h2>
                            <p>Keep adding details to stand out.</p>
                        </div>
                        <div
                            class="completion-number"
                            id="completionNumber"
                            aria-live="polite"
                        ><?= $completion_percentage ?>%</div>
                    </div>

                    <div
                        class="progress-track"
                        role="progressbar"
                        id="completionProgress"
                        aria-label="Profile completion"
                        aria-valuemin="0"
                        aria-valuemax="100"
                        aria-valuenow="<?= $completion_percentage ?>"
                    >
                        <div
                            class="progress-fill"
                            id="completionFill"
                            style="width: <?= $completion_percentage ?>%;"
                        ></div>
                    </div>

                    <div class="completion-foot">
                        <span id="completionStatus">Profile strength</span>
                        <span id="completionRemaining"><?= 100 - $completion_percentage ?>% remaining</span>
                    </div>

                    <p class="completion-hint" id="completionHint">
                        <?php if ($completion_percentage >= 100): ?>
                            Excellent! Your profile is complete.
                        <?php elseif ($completion_percentage >= 70): ?>
                            Great progress. Add the remaining details to finish your profile.
                        <?php elseif ($completion_percentage >= 35): ?>
                            You're making progress. Keep adding your education, skills, and links.
                        <?php else: ?>
                            Start with your name and email, then add education and skills.
                        <?php endif; ?>
                    </p>
                </section>

                <section class="glass-card preview-card" aria-labelledby="previewHeading">
                    <div class="card-head">
                        <div class="card-head-row">
                            <div class="section-icon">
                                <i class="bi bi-eye-fill" aria-hidden="true"></i>
                            </div>
                            <div>
                                <h2 id="previewHeading">Live Profile Preview</h2>
                                <p>Updates instantly as you type.</p>
                            </div>
                        </div>
                    </div>

                    <div class="preview-banner" aria-hidden="true"></div>

                    <div class="preview-main">
                        <div class="avatar" id="previewInitial"><?= profileEscape($initial) ?></div>

                        <h2 class="preview-name" id="previewName"><?= profileEscape($name ?: 'Your Name') ?></h2>
                        <p class="preview-degree" id="previewDegree"><?= profileEscape($field_values['degree'] ?: 'Your degree or course') ?></p>

                        <div class="preview-college">
                            <i class="bi bi-building" aria-hidden="true"></i>
                            <span id="previewCollege"><?= profileEscape($field_values['college_name'] ?: 'Your college or university') ?></span>
                        </div>

                        <div class="preview-divider"></div>

                        <div class="preview-label">About</div>
                        <p class="preview-bio" id="previewAbout"><?= profileEscape($field_values['about'] ?: 'Your introduction will appear here when you start typing in the About Me field.') ?></p>

                        <div class="preview-divider"></div>

                        <div class="preview-label">Skills</div>
                        <div class="preview-skills" id="previewSkills">
                            <?php
                            $initial_skills = array_filter(
                                array_map('trim', explode(',', (string) $field_values['skills']))
                            );
                            ?>
                            <?php if ($initial_skills): ?>
                                <?php foreach ($initial_skills as $skill): ?>
                                    <span class="skill-chip"><?= profileEscape($skill) ?></span>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <span class="preview-empty">Your skills will appear here.</span>
                            <?php endif; ?>
                        </div>

                        <div class="preview-divider"></div>

                        <div class="preview-label">Details</div>
                        <div class="preview-details">
                            <div class="preview-detail">
                                <i class="bi bi-envelope" aria-hidden="true"></i>
                                <span id="previewEmail"><?= profileEscape($email ?: 'Your email address') ?></span>
                            </div>
                            <div class="preview-detail">
                                <i class="bi bi-telephone" aria-hidden="true"></i>
                                <span id="previewPhone"><?= profileEscape($field_values['phone'] ?: 'Your phone number') ?></span>
                            </div>
                            <div class="preview-detail">
                                <i class="bi bi-geo-alt" aria-hidden="true"></i>
                                <span id="previewLocation"><?= profileEscape($field_values['location'] ?: 'Your location') ?></span>
                            </div>
                            <div class="preview-detail">
                                <i class="bi bi-calendar-check" aria-hidden="true"></i>
                                <span id="previewGraduation"><?= profileEscape($field_values['graduation_year'] ?: 'Graduation year') ?></span>
                            </div>
                            <div class="preview-detail">
                                <i class="bi bi-stars" aria-hidden="true"></i>
                                <span id="previewDomain"><?= profileEscape($field_values['preferred_domain'] ?: 'Preferred internship domain') ?></span>
                            </div>
                        </div>

                        <div class="preview-divider"></div>

                        <div class="preview-label">Professional Links</div>
                        <div class="social-links" id="previewSocials">
                            <span class="preview-empty">Your professional links will appear here.</span>
                        </div>

                        <p class="preview-note">
                            <i class="bi bi-info-circle" aria-hidden="true"></i>
                            This preview is for your reference. Save your profile to store changes.
                        </p>
                    </div>
                </section>
            </aside>
        </div>
    </main>

    <footer class="site-footer">
        &copy; <?= date('Y') ?> <span>InternPro</span>. Built for your next opportunity
        <i class="bi bi-lightning-charge-fill" aria-hidden="true"></i>
    </footer>

    <script>
        (() => {
            'use strict';

            const form = document.getElementById('profileForm');
            const fields = Array.from(form.querySelectorAll('[data-preview]'));

            const byId = (id) => document.getElementById(id);
            const valueOf = (name) => {
                const field = form.elements.namedItem(name);
                return field ? String(field.value || '').trim() : '';
            };

            // textContent is used for user-entered preview content so that
            // input is displayed as text, never interpreted as HTML.
            function setText(id, value, fallback) {
                const element = byId(id);
                if (element) {
                    element.textContent = value || fallback;
                }
            }

            function updateSkills() {
                const target = byId('previewSkills');
                if (!target) return;

                target.replaceChildren();

                const skills = valueOf('skills')
                    .split(',')
                    .map(skill => skill.trim())
                    .filter(Boolean)
                    .slice(0, 40);

                if (!skills.length) {
                    const empty = document.createElement('span');
                    empty.className = 'preview-empty';
                    empty.textContent = 'Your skills will appear here.';
                    target.appendChild(empty);
                    return;
                }

                skills.forEach(skill => {
                    const chip = document.createElement('span');
                    chip.className = 'skill-chip';
                    chip.textContent = skill;
                    target.appendChild(chip);
                });
            }

            function updateSocials() {
                const target = byId('previewSocials');
                if (!target) return;

                target.replaceChildren();

                const socials = [
                    ['linkedin_url', 'LinkedIn', 'bi-linkedin'],
                    ['github_url', 'GitHub', 'bi-github'],
                    ['portfolio_url', 'Portfolio', 'bi-globe']
                ];

                let count = 0;

                socials.forEach(([field, label, iconClass]) => {
                    const url = valueOf(field);
                    if (!url) return;

                    // Do not create clickable links for invalid or unsafe URLs.
                    try {
                        const parsed = new URL(url);
                        if (!['http:', 'https:'].includes(parsed.protocol)) {
                            return;
                        }

                        const link = document.createElement('a');
                        link.className = 'social-preview';
                        link.href = parsed.href;
                        link.target = '_blank';
                        link.rel = 'noopener noreferrer';
                        link.title = parsed.href;

                        const icon = document.createElement('i');
                        icon.className = 'bi ' + iconClass;
                        icon.setAttribute('aria-hidden', 'true');

                        const text = document.createElement('span');
                        text.textContent = label;

                        link.append(icon, text);
                        target.appendChild(link);
                        count++;
                    } catch (error) {
                        // Invalid URLs stay in the form but are not preview links.
                    }
                });

                if (!count) {
                    const empty = document.createElement('span');
                    empty.className = 'preview-empty';
                    empty.textContent = 'Your professional links will appear here.';
                    target.appendChild(empty);
                }
            }

            // The same weights are used by the server-side calculation.
            // Email is intentionally worth exactly 2 percentage points.
            const weights = {
                email: 2,
                name: 6,
                phone: 5,
                college_name: 7,
                department: 5,
                degree: 5,
                year_of_study: 4,
                cgpa: 4,
                graduation_year: 4,
                location: 4,
                skills: 8,
                preferred_domain: 4,
                preferred_location: 3,
                internship_duration: 3,
                work_mode: 3,
                about: 12,
                linkedin_url: 4,
                github_url: 4,
                portfolio_url: 4
            };

            function updateCompletion() {
                let percentage = 0;

                Object.entries(weights).forEach(([field, weight]) => {
                    if (valueOf(field) !== '') {
                        percentage += weight;
                    }
                });

                // The server includes existing photo/resume values in the
                // initial percentage; live edits update the visible fields.
                percentage = Math.min(100, percentage);

                const number = byId('completionNumber');
                const fill = byId('completionFill');
                const progress = byId('completionProgress');
                const remaining = byId('completionRemaining');
                const hint = byId('completionHint');
                const status = byId('completionStatus');

                if (number) number.textContent = percentage + '%';
                if (fill) fill.style.width = percentage + '%';

                if (progress) {
                    progress.setAttribute('aria-valuenow', String(percentage));
                }

                if (remaining) {
                    remaining.textContent = (100 - percentage) + '% remaining';
                }

                if (status) {
                    status.textContent = percentage >= 100
                        ? 'Profile complete'
                        : 'Profile strength';
                }

                if (hint) {
                    if (percentage >= 100) {
                        hint.textContent = 'Excellent! Your profile is complete.';
                    } else if (percentage >= 70) {
                        hint.textContent = 'Great progress. Add the remaining details to finish your profile.';
                    } else if (percentage >= 35) {
                        hint.textContent = 'You are making progress. Keep adding education, skills, and links.';
                    } else {
                        hint.textContent = 'Start with your name and email, then add education and skills.';
                    }
                }
            }

            function updatePreview() {
                const name = valueOf('name');
                const degree = valueOf('degree');
                const college = valueOf('college_name');
                const about = valueOf('about');
                const email = valueOf('email');
                const phone = valueOf('phone');
                const location = valueOf('location');
                const graduation = valueOf('graduation_year');
                const domain = valueOf('preferred_domain');

                setText('previewName', name, 'Your Name');
                setText('previewInitial', name ? name.charAt(0).toUpperCase() : 'S', 'S');
                setText('previewDegree', degree, 'Your degree or course');
                setText('previewCollege', college, 'Your college or university');
                setText('previewAbout', about, 'Your introduction will appear here when you start typing in the About Me field.');
                setText('previewEmail', email, 'Your email address');
                setText('previewPhone', phone, 'Your phone number');
                setText('previewLocation', location, 'Your location');
                setText('previewGraduation', graduation, 'Graduation year');
                setText('previewDomain', domain, 'Preferred internship domain');

                updateSkills();
                updateSocials();
                updateCompletion();
            }

            fields.forEach(field => {
                field.addEventListener('input', updatePreview);
                field.addEventListener('change', updatePreview);
            });

            // Responsive navbar.
            const menuToggle = byId('menuToggle');
            const navLinks = byId('navLinks');

            if (menuToggle && navLinks) {
                const icon = menuToggle.querySelector('i');

                function closeMenu() {
                    navLinks.classList.remove('open');
                    menuToggle.setAttribute('aria-expanded', 'false');
                    menuToggle.setAttribute('aria-label', 'Open navigation menu');
                    if (icon) icon.className = 'bi bi-list';
                }

                menuToggle.addEventListener('click', () => {
                    const open = navLinks.classList.toggle('open');
                    menuToggle.setAttribute('aria-expanded', String(open));
                    menuToggle.setAttribute(
                        'aria-label',
                        open ? 'Close navigation menu' : 'Open navigation menu'
                    );
                    if (icon) icon.className = open ? 'bi bi-x-lg' : 'bi bi-list';
                });

                navLinks.querySelectorAll('a').forEach(link => {
                    link.addEventListener('click', closeMenu);
                });

                document.addEventListener('click', event => {
                    if (
                        !navLinks.contains(event.target) &&
                        !menuToggle.contains(event.target)
                    ) {
                        closeMenu();
                    }
                });

                document.addEventListener('keydown', event => {
                    if (event.key === 'Escape') {
                        const wasOpen = navLinks.classList.contains('open');
                        closeMenu();
                        if (wasOpen) menuToggle.focus();
                    }
                });

                window.addEventListener('resize', () => {
                    if (window.innerWidth > 850) closeMenu();
                });
            }

            updatePreview();
        })();
    </script>
</body>
</html>
