
<?php
require_once __DIR__ . '/config/database.php';

$contact_sent = false;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#071e3d">
    <meta name="description" content="Discover internships, build your student profile, develop skills and track your application journey with InternPro.">

    <title>InternPro | College Internship Portal</title>

    <link rel="icon" type="image/jpeg" href="assets/logo.jpg">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        /* =========================================================
           INTERNPRO — ORIGINAL BLUE / CYAN THEME
           Navy: #071E3D
           Blue: #0D3B66
           Cyan: #00B4D8
           Bright blue: #0096C7
           ========================================================= */

        :root {
            --navy: #071E3D;
            --navy-deep: #041224;
            --blue: #0D3B66;
            --blue-bright: #0077B6;
            --cyan: #00B4D8;
            --cyan-light: #38BDF8;
            --cyan-soft: rgba(0, 180, 216, .13);
            --white: #FFFFFF;
            --text: #E2E8F0;
            --muted: #94A3B8;
            --border: rgba(255, 255, 255, .10);
            --panel: rgba(13, 35, 65, .70);
            --panel-hover: rgba(15, 49, 83, .90);
            --glow: rgba(0, 180, 216, .24);
            --radius: 18px;
            --transition: .35s cubic-bezier(.2, .8, .2, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html {
            scroll-behavior: smooth;
            scroll-padding-top: 100px;
        }

        body {
            min-height: 100vh;
            overflow-x: hidden;
            color: var(--white);
            background:
                radial-gradient(ellipse at 15% 0%, rgba(0, 150, 199, .15), transparent 38%),
                radial-gradient(ellipse at 90% 35%, rgba(0, 119, 182, .14), transparent 35%),
                linear-gradient(135deg, var(--navy) 0%, var(--blue) 55%, #052A4A 100%);
            font-family: 'Poppins', sans-serif;
            line-height: 1.7;
        }

        body.intro-active,
        body.menu-open {
            overflow: hidden;
        }

        a {
            color: inherit;
        }

        button,
        input,
        textarea,
        select {
            font: inherit;
        }

        button,
        a,
        input,
        textarea,
        select {
            -webkit-tap-highlight-color: transparent;
        }

        a:focus-visible,
        button:focus-visible,
        input:focus-visible,
        textarea:focus-visible,
        select:focus-visible {
            outline: 2px solid var(--cyan-light);
            outline-offset: 4px;
        }

        ::selection {
            color: #fff;
            background: #0077B6;
        }

        /* =========================================================
           ANIMATED BACKGROUND
           ========================================================= */

        .ambient-background {
            position: fixed;
            inset: 0;
            z-index: -2;
            overflow: hidden;
            pointer-events: none;
        }

        .ambient-grid {
            position: absolute;
            inset: -50%;
            opacity: .18;
            background-image:
                linear-gradient(rgba(56, 189, 248, .14) 1px, transparent 1px),
                linear-gradient(90deg, rgba(56, 189, 248, .14) 1px, transparent 1px);
            background-size: 58px 58px;
            transform: perspective(750px) rotateX(55deg) scale(1.7);
            transform-origin: center;
            animation: gridDrift 25s linear infinite;
            mask-image: linear-gradient(to bottom, transparent, #000 20%, #000 80%, transparent);
        }

        .ambient-orb {
            position: absolute;
            width: 400px;
            aspect-ratio: 1;
            border-radius: 50%;
            filter: blur(100px);
            opacity: .25;
            animation: orbFloat 14s ease-in-out infinite alternate;
        }

        .orb-one {
            top: 8%;
            left: -200px;
            background: #00B4D8;
        }

        .orb-two {
            top: 40%;
            right: -220px;
            background: #0077B6;
            animation-delay: -5s;
        }

        .orb-three {
            bottom: -260px;
            left: 30%;
            background: #38BDF8;
            animation-delay: -9s;
        }

        #particleCanvas {
            position: absolute;
            inset: 0;
            width: 100%;
            height: 100%;
        }

        .scanline {
            position: fixed;
            inset: 0;
            z-index: 5;
            pointer-events: none;
            opacity: .035;
            background: repeating-linear-gradient(
                to bottom,
                transparent 0,
                transparent 3px,
                rgba(255, 255, 255, .30) 4px
            );
        }

        @keyframes gridDrift {
            from { background-position: 0 0; }
            to { background-position: 0 232px; }
        }

        @keyframes orbFloat {
            from { transform: translate3d(0, 0, 0) scale(1); }
            to { transform: translate3d(45px, -35px, 0) scale(1.12); }
        }

        /* =========================================================
           INTRO SCREEN
           ========================================================= */

        #internproIntro {
            position: fixed;
            inset: 0;
            z-index: 10000;
            display: grid;
            place-items: center;
            overflow-y: auto;
            padding: 30px 20px;
            background:
                radial-gradient(ellipse at 50% 20%, rgba(0, 180, 216, .17), transparent 55%),
                #041A36;
            transition: opacity .7s ease, visibility .7s ease;
        }

        #internproIntro::before,
        #internproIntro::after {
            position: absolute;
            width: min(460px, 80vw);
            aspect-ratio: 1;
            border: 1px solid rgba(56, 189, 248, .15);
            border-radius: 50%;
            content: "";
            pointer-events: none;
            box-shadow: 0 0 80px rgba(0, 180, 216, .08);
            animation: introOrbit 12s ease-in-out infinite alternate;
        }

        #internproIntro::after {
            width: min(300px, 60vw);
            animation-duration: 8s;
            animation-direction: alternate-reverse;
        }

        #internproIntro.intro-leaving {
            opacity: 0;
            visibility: hidden;
            pointer-events: none;
        }

        .intro-shell {
            position: relative;
            z-index: 1;
            width: min(940px, 100%);
            text-align: center;
            animation: enterUp .8s both;
        }

        .brand,
        .intro-brand {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
        }

        .intro-brand {
            margin-bottom: 25px;
        }

        .brand img,
        .intro-brand img {
            width: 38px;
            height: 38px;
            object-fit: contain;
            border-radius: 9px;
            filter: drop-shadow(0 0 12px var(--glow));
            transition: transform var(--transition), filter var(--transition);
        }

        .brand:hover img,
        .intro-brand:hover img {
            transform: rotate(-8deg) scale(1.1);
            filter: drop-shadow(0 0 20px var(--cyan));
        }

        .brand-name {
            font-size: 24px;
            font-weight: 800;
            letter-spacing: -.8px;
            line-height: 1.2;
        }

        .brand-name span:last-child {
            color: var(--cyan);
        }

        .intro-kicker,
        .eyebrow {
            display: block;
            color: var(--cyan-light);
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 3px;
            text-transform: uppercase;
        }

        .intro-title {
            margin: 14px 0;
            font-family: 'Space Grotesk', sans-serif;
            font-size: clamp(38px, 7vw, 72px);
            font-weight: 700;
            line-height: 1.08;
            letter-spacing: -2px;
        }

        .gradient-text {
            color: transparent;
            background: linear-gradient(
                110deg,
                #FFFFFF 10%,
                #BAE6FD 40%,
                #38BDF8 70%,
                #00B4D8 100%
            );
            background-size: 200% auto;
            background-clip: text;
            -webkit-background-clip: text;
            animation: textShimmer 6s linear infinite;
        }

        .intro-subtitle {
            max-width: 620px;
            margin: 0 auto 30px;
            color: #CBD5E1;
            font-size: 14px;
            font-weight: 300;
        }

        .intro-journey {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 13px;
            margin-bottom: 28px;
        }

        .intro-step {
            padding: 22px 12px;
            border: 1px solid var(--border);
            border-radius: 17px;
            background: rgba(255, 255, 255, .045);
            backdrop-filter: blur(15px);
            transition: transform var(--transition), border-color var(--transition), box-shadow var(--transition);
            animation: enterUp .7s both;
        }

        .intro-step:nth-child(2) { animation-delay: .08s; }
        .intro-step:nth-child(3) { animation-delay: .16s; }
        .intro-step:nth-child(4) { animation-delay: .24s; }

        .intro-step:hover {
            transform: translateY(-6px);
            border-color: rgba(0, 180, 216, .6);
            box-shadow: 0 0 30px rgba(0, 180, 216, .13);
        }

        .intro-step-number {
            display: grid;
            place-items: center;
            width: 42px;
            height: 42px;
            margin: 0 auto 12px;
            border-radius: 13px;
            color: #fff;
            font-weight: 800;
            background: linear-gradient(135deg, var(--cyan), var(--blue-bright));
            box-shadow: 0 0 22px var(--glow);
            transition: transform var(--transition);
        }

        .intro-step:hover .intro-step-number {
            transform: rotate(8deg) scale(1.1);
        }

        .intro-step h3 {
            font-size: 14px;
        }

        .intro-step p {
            margin-top: 5px;
            color: var(--muted);
            font-size: 11px;
        }

        .intro-start,
        .btn-primary,
        .btn-secondary,
        .btn-search,
        .btn-submit {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 9px;
            min-height: 48px;
            padding: 12px 23px;
            border: 1px solid transparent;
            border-radius: 11px;
            color: #fff;
            font-size: 13px;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
            transition: transform var(--transition), box-shadow var(--transition), background var(--transition), border-color var(--transition);
        }

        .intro-start,
        .btn-primary,
        .btn-search,
        .btn-submit {
            background: linear-gradient(110deg, #00B4D8, #0077B6, #0096C7);
            background-size: 200% 100%;
            box-shadow: 0 8px 28px rgba(0, 180, 216, .25);
        }

        .intro-start:hover,
        .btn-primary:hover,
        .btn-search:hover,
        .btn-submit:hover {
            transform: translateY(-3px);
            background-position: 100% 0;
            box-shadow: 0 12px 34px rgba(0, 180, 216, .4);
        }

        .intro-start .arrow {
            transition: transform var(--transition);
        }

        .intro-start:hover .arrow {
            transform: translateX(5px);
        }

        .intro-progress {
            width: 170px;
            height: 3px;
            margin: 22px auto 0;
            overflow: hidden;
            border-radius: 10px;
            background: rgba(255, 255, 255, .12);
        }

        .intro-progress span {
            display: block;
            width: 0;
            height: 100%;
            background: linear-gradient(90deg, var(--cyan), var(--cyan-light));
        }

        #internproIntro.intro-loading .intro-progress span {
            animation: loadProgress 1.1s linear forwards;
        }

        #internproIntro.intro-loading .intro-start {
            opacity: .7;
            pointer-events: none;
        }

        @keyframes loadProgress {
            to { width: 100%; }
        }

        @keyframes introOrbit {
            from { transform: translate(-15px, 5px) scale(.94); }
            to { transform: translate(15px, -5px) scale(1.06); }
        }

        @keyframes textShimmer {
            to { background-position: 200% center; }
        }

        @keyframes enterUp {
            from { opacity: 0; transform: translateY(25px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* =========================================================
           NAVIGATION
           ========================================================= */

        .site-nav {
            position: fixed;
            z-index: 1000;
            top: 0;
            left: 0;
            display: grid;
            grid-template-columns: minmax(160px, 1fr) auto minmax(160px, 1fr);
            align-items: center;
            gap: 15px;
            width: 100%;
            min-height: 76px;
            padding: 11px 5%;
            border-bottom: 1px solid var(--border);
            background: rgba(7, 30, 61, .89);
            box-shadow: 0 8px 30px rgba(0, 0, 0, .13);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            animation: navEnter .7s ease both;
        }

        @keyframes navEnter {
            from { opacity: 0; transform: translateY(-15px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .brand {
            justify-self: start;
            min-width: 0;
            flex-shrink: 0;
        }

        .nav-links {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 4px;
            list-style: none;
        }

        .nav-links a {
            position: relative;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 42px;
            padding: 0 12px;
            border: 1px solid transparent;
            border-radius: 11px;
            color: #CBD5E1;
            font-size: 12px;
            white-space: nowrap;
            text-decoration: none;
            transition: color var(--transition), background var(--transition), border-color var(--transition), transform var(--transition);
        }

        .nav-links a:hover,
        .nav-links a[aria-current="page"] {
            color: #fff;
            border-color: rgba(56, 189, 248, .25);
            background: rgba(0, 180, 216, .10);
        }

        .nav-links a:hover {
            transform: translateY(-2px);
        }

        .nav-links a[aria-current="page"] {
            box-shadow: inset 0 0 20px rgba(0, 180, 216, .06);
        }

        .nav-auth {
            justify-self: end;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .btn-nav-login,
        .btn-nav-register {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 39px;
            padding: 8px 15px;
            border: 1px solid var(--border);
            border-radius: 9px;
            font-size: 12px;
            font-weight: 600;
            white-space: nowrap;
            text-decoration: none;
            transition: transform var(--transition), background var(--transition), box-shadow var(--transition), border-color var(--transition);
        }

        .btn-nav-login {
            background: rgba(255, 255, 255, .025);
        }

        .btn-nav-login:hover {
            border-color: var(--cyan);
            background: rgba(255, 255, 255, .08);
            transform: translateX(-2px);
        }

        .btn-nav-register {
            border-color: transparent;
            background: linear-gradient(120deg, #00B4D8, #0077B6);
            box-shadow: 0 4px 18px rgba(0, 180, 216, .22);
        }

        .btn-nav-register:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0, 180, 216, .38);
        }

        .menu-toggle {
            display: none;
            width: 42px;
            height: 42px;
            border: 1px solid var(--border);
            border-radius: 11px;
            color: #fff;
            background: rgba(13, 59, 102, .65);
            cursor: pointer;
        }

        .menu-toggle span {
            display: block;
            width: 18px;
            height: 2px;
            margin: 4px auto;
            border-radius: 5px;
            background: currentColor;
            transition: transform var(--transition);
        }

        .menu-toggle[aria-expanded="true"] span:first-child {
            transform: translateY(3px) rotate(45deg);
        }

        .menu-toggle[aria-expanded="true"] span:last-child {
            transform: translateY(-3px) rotate(-45deg);
        }

        /* =========================================================
           HERO
           ========================================================= */

        .hero-section {
            position: relative;
            display: grid;
            min-height: 100vh;
            place-items: center;
            padding: 155px 6% 100px;
            text-align: center;
            isolation: isolate;
        }

        .hero-section::before {
            position: absolute;
            z-index: -1;
            top: 15%;
            left: 50%;
            width: min(650px, 90vw);
            aspect-ratio: 1;
            border: 1px solid rgba(56, 189, 248, .13);
            border-radius: 50%;
            box-shadow: 0 0 90px rgba(0, 180, 216, .07), inset 0 0 90px rgba(0, 180, 216, .035);
            content: "";
            transform: translateX(-50%);
            animation: ringPulse 8s ease-in-out infinite alternate;
        }

        .hero-section::after {
            position: absolute;
            z-index: -1;
            top: 23%;
            left: 50%;
            width: min(470px, 70vw);
            aspect-ratio: 1;
            border: 1px dashed rgba(56, 189, 248, .20);
            border-radius: 50%;
            content: "";
            transform: translateX(-50%);
            animation: ringRotate 55s linear infinite;
        }

        @keyframes ringPulse {
            to {
                opacity: .4;
                transform: translateX(-50%) scale(1.08);
            }
        }

        @keyframes ringRotate {
            to { transform: translateX(-50%) rotate(360deg); }
        }

        .hero {
            position: relative;
            z-index: 2;
            width: min(940px, 100%);
            animation: enterUp 1s .1s both;
        }

        .hero-badge {
            display: inline-flex;
            align-items: center;
            gap: 9px;
            margin-bottom: 25px;
            padding: 8px 15px;
            border: 1px solid rgba(56, 189, 248, .20);
            border-radius: 999px;
            color: #BAE6FD;
            background: rgba(0, 180, 216, .08);
            font-size: 11px;
            letter-spacing: .4px;
            backdrop-filter: blur(10px);
        }

        .status-dot {
            width: 7px;
            height: 7px;
            border-radius: 50%;
            background: #86EFAC;
            box-shadow: 0 0 12px #86EFAC;
            animation: dotPulse 1.8s ease-in-out infinite;
        }

        @keyframes dotPulse {
            50% { opacity: .45; transform: scale(.75); }
        }

        .hero h1 {
            margin-bottom: 22px;
            font-family: 'Space Grotesk', sans-serif;
            font-size: clamp(42px, 7.2vw, 84px);
            font-weight: 700;
            line-height: 1.08;
            letter-spacing: -3px;
        }

        .hero p {
            max-width: 680px;
            margin: 0 auto 30px;
            color: #D7E4F0;
            font-size: clamp(14px, 1.6vw, 17px);
            font-weight: 300;
        }

        .hero-buttons {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 13px;
            margin-bottom: 38px;
        }

        .btn-secondary {
            border-color: rgba(255, 255, 255, .22);
            background: rgba(255, 255, 255, .045);
        }

        .btn-secondary:hover {
            transform: translateY(-3px);
            border-color: var(--cyan);
            background: rgba(0, 180, 216, .10);
        }

        .hero-metrics {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 30px;
            margin-top: 32px;
        }

        .hero-metric {
            min-width: 115px;
        }

        .hero-metric strong {
            display: block;
            color: #fff;
            font-family: 'Space Grotesk', sans-serif;
            font-size: 24px;
        }

        .hero-metric span {
            color: #B7C8DA;
            font-size: 11px;
        }

        .scroll-indicator {
            position: absolute;
            bottom: 25px;
            left: 50%;
            display: grid;
            justify-items: center;
            gap: 7px;
            color: #B7C8DA;
            font-size: 10px;
            letter-spacing: 2px;
            text-decoration: none;
            transform: translateX(-50%);
        }

        .scroll-indicator span {
            display: block;
            width: 1px;
            height: 27px;
            background: linear-gradient(var(--cyan), transparent);
            animation: scrollPulse 1.7s ease-in-out infinite;
        }

        /* =========================================================
           SECTIONS AND GLASS CARDS
           ========================================================= */

        section.content-section {
            position: relative;
            padding: 90px 6%;
        }

        .section-heading {
            max-width: 760px;
            margin: 0 auto 48px;
            text-align: center;
        }

        .section-heading .eyebrow {
            margin-bottom: 10px;
        }

        .section-title {
            font-family: 'Space Grotesk', sans-serif;
            font-size: clamp(28px, 4vw, 43px);
            font-weight: 700;
            line-height: 1.2;
            letter-spacing: -1.2px;
        }

        .section-subtitle {
            max-width: 650px;
            margin: 13px auto 0;
            color: #C3D0DF;
            font-size: 13px;
        }

        .glass-card {
            border: 1px solid var(--border);
            border-radius: var(--radius);
            background: var(--panel);
            box-shadow: 0 20px 60px rgba(0, 0, 0, .12);
            backdrop-filter: blur(18px);
            -webkit-backdrop-filter: blur(18px);
            transition: transform var(--transition), border-color var(--transition), background var(--transition), box-shadow var(--transition);
        }

        .glass-card:hover {
            transform: translateY(-6px);
            border-color: rgba(56, 189, 248, .48);
            background: var(--panel-hover);
            box-shadow: 0 20px 55px rgba(0, 0, 0, .20), 0 0 28px rgba(0, 180, 216, .09);
        }

        .features-grid,
        .steps-container,
        .internships-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 20px;
            max-width: 1250px;
            margin: 0 auto;
        }

        .feature-card {
            min-width: 0;
            padding: 27px 23px;
        }

        .feature-icon {
            display: grid;
            place-items: center;
            width: 52px;
            height: 52px;
            margin-bottom: 22px;
            border: 1px solid rgba(56, 189, 248, .23);
            border-radius: 15px;
            color: #BAE6FD;
            background: linear-gradient(135deg, rgba(0, 180, 216, .22), rgba(56, 189, 248, .06));
            font-size: 23px;
            transition: transform var(--transition), filter var(--transition);
        }

        .glass-card:hover .feature-icon {
            transform: rotate(-7deg) scale(1.1);
            filter: drop-shadow(0 0 9px var(--cyan));
        }

        .feature-card h3,
        .step-card h3,
        .journey-card h3 {
            margin-bottom: 9px;
            font-size: 15px;
            font-weight: 600;
        }

        .feature-card p,
        .step-card p,
        .journey-card p {
            color: #C3D0DF;
            font-size: 12px;
        }

        .steps-container {
            grid-template-columns: repeat(4, minmax(0, 1fr));
        }

        .step-card {
            padding: 28px 23px;
        }

        .step-number {
            margin-bottom: 18px;
            color: var(--cyan-light);
            font-family: 'Space Grotesk', sans-serif;
            font-size: 37px;
            font-weight: 700;
            letter-spacing: -2px;
        }

        .journey-container {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 18px;
            max-width: 1250px;
            margin: 0 auto;
        }

        .journey-card {
            display: flex;
            align-items: flex-start;
            gap: 14px;
            padding: 23px 18px;
        }

        .journey-icon {
            display: grid;
            flex: 0 0 43px;
            place-items: center;
            width: 43px;
            height: 43px;
            border: 1px solid rgba(56, 189, 248, .25);
            border-radius: 13px;
            color: #fff;
            background: linear-gradient(135deg, #00B4D8, #0077B6);
            font-weight: 800;
            box-shadow: 0 0 20px var(--glow);
            transition: transform var(--transition);
        }

        .journey-card:hover .journey-icon {
            transform: rotate(8deg) scale(1.1);
        }

        /* =========================================================
           SEARCH
           ========================================================= */

        .search-box-container {
            max-width: 1000px;
            margin: 0 auto;
            padding: clamp(22px, 4vw, 45px);
        }

        .search-form {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr auto;
            gap: 12px;
        }

        .search-input,
        .search-select,
        .form-control {
            width: 100%;
            min-width: 0;
            min-height: 48px;
            padding: 12px 14px;
            border: 1px solid rgba(255, 255, 255, .16);
            border-radius: 11px;
            color: #fff;
            background: rgba(255, 255, 255, .045);
            outline: none;
            font-size: 12px;
            transition: border-color var(--transition), background var(--transition), box-shadow var(--transition);
        }

        .search-input:focus,
        .search-select:focus,
        .form-control:focus {
            border-color: var(--cyan);
            background: rgba(0, 180, 216, .07);
            box-shadow: 0 0 0 3px rgba(0, 180, 216, .10);
        }

        .search-input::placeholder,
        .form-control::placeholder {
            color: #A3B6CA;
        }

        .search-select option {
            color: #fff;
            background: #0D3B66;
        }

        .search-note {
            margin-top: 15px;
            color: #AFC1D5;
            font-size: 11px;
            text-align: center;
        }

        /* =========================================================
           INTERNSHIP CARDS
           ========================================================= */

        .internship-card {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            padding: 25px;
        }

        .internship-label {
            display: inline-flex;
            align-self: flex-start;
            margin-bottom: 17px;
            padding: 5px 9px;
            border: 1px solid rgba(56, 189, 248, .20);
            border-radius: 8px;
            color: #BAE6FD;
            background: rgba(0, 180, 216, .08);
            font-size: 10px;
        }

        .internship-title {
            margin-bottom: 5px;
            font-size: 17px;
        }

        .company-name {
            margin-bottom: 18px;
            color: var(--cyan-light);
            font-size: 12px;
        }

        .internship-details {
            display: grid;
            gap: 9px;
            margin-bottom: 18px;
            color: #C3D0DF;
            font-size: 11px;
        }

        .detail-row {
            display: flex;
            align-items: center;
            gap: 9px;
        }

        .detail-row .symbol {
            display: inline-block;
            transition: transform var(--transition), filter var(--transition);
        }

        .detail-row:hover .symbol {
            transform: scale(1.2) rotate(-8deg);
            filter: drop-shadow(0 0 5px var(--cyan));
        }

        .skills-list {
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
            margin-bottom: 18px;
        }

        .skills-tag {
            padding: 5px 9px;
            border: 1px solid rgba(56, 189, 248, .15);
            border-radius: 7px;
            color: #BAE6FD;
            background: rgba(0, 180, 216, .08);
            font-size: 10px;
            transition: transform var(--transition), background var(--transition);
        }

        .skills-tag:hover {
            transform: translateY(-2px);
            background: rgba(0, 180, 216, .20);
        }

        .btn-details {
            display: block;
            padding: 10px 12px;
            border: 1px solid var(--border);
            border-radius: 10px;
            color: #fff;
            background: rgba(255, 255, 255, .035);
            font-size: 12px;
            text-align: center;
            text-decoration: none;
            transition: background var(--transition), border-color var(--transition), transform var(--transition);
        }

        .btn-details:hover {
            transform: translateY(-2px);
            border-color: var(--cyan);
            background: rgba(0, 180, 216, .15);
        }

        /* =========================================================
           FAQ
           ========================================================= */

        .faq-list {
            max-width: 900px;
            margin: 0 auto;
        }

        .faq-card {
            margin-bottom: 12px;
            overflow: hidden;
        }

        .faq-question {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 18px;
            width: 100%;
            padding: 19px 22px;
            border: 0;
            color: #fff;
            background: transparent;
            font-size: 13px;
            font-weight: 600;
            text-align: left;
            cursor: pointer;
        }

        .faq-question::after {
            flex-shrink: 0;
            color: var(--cyan);
            content: '+';
            font-size: 23px;
            transition: transform var(--transition);
        }

        .faq-card.active .faq-question::after {
            transform: rotate(45deg);
        }

        .faq-answer {
            display: grid;
            grid-template-rows: 0fr;
            transition: grid-template-rows .35s ease;
        }

        .faq-answer-inner {
            overflow: hidden;
            color: #C3D0DF;
            font-size: 12px;
        }

        .faq-card.active .faq-answer {
            grid-template-rows: 1fr;
        }

        .faq-answer-inner p {
            padding: 0 22px 20px;
        }

        /* =========================================================
           CONTACT
           ========================================================= */

        .contact-grid {
            display: grid;
            grid-template-columns: .8fr 1.2fr;
            gap: 22px;
            max-width: 1050px;
            margin: 0 auto;
        }

        .contact-info,
        .contact-form-box {
            padding: clamp(22px, 4vw, 35px);
        }

        .contact-info h3,
        .contact-form-box h3 {
            margin-bottom: 23px;
            font-size: 18px;
        }

        .info-item {
            margin-bottom: 23px;
            color: #C3D0DF;
            font-size: 12px;
            overflow-wrap: anywhere;
        }

        .info-item strong {
            display: block;
            margin-bottom: 4px;
            color: #fff;
            font-size: 12px;
        }

        .info-item a {
            text-decoration-color: rgba(0, 180, 216, .5);
            text-underline-offset: 4px;
        }

        .form-group {
            margin-bottom: 17px;
        }

        .form-group label {
            display: block;
            margin-bottom: 7px;
            color: #D7E4F0;
            font-size: 12px;
        }

        textarea.form-control {
            min-height: 125px;
            resize: vertical;
        }

        .alert-success {
            max-width: 1050px;
            margin: 0 auto 20px;
            padding: 15px;
            border: 1px solid #86EFAC;
            border-radius: 12px;
            color: #BBF7D0;
            background: rgba(34, 197, 94, .10);
        }

        /* =========================================================
           FOOTER
           ========================================================= */

        .site-footer {
            padding: 65px 6% 25px;
            border-top: 1px solid var(--border);
            background: rgba(4, 18, 36, .85);
        }

        .footer-grid {
            display: grid;
            grid-template-columns: 1.4fr 1fr 1fr;
            gap: 35px;
            max-width: 1200px;
            margin: 0 auto 38px;
        }

        .footer-col h4 {
            margin-bottom: 16px;
            font-size: 14px;
        }

        .footer-col p {
            max-width: 310px;
            margin-top: 16px;
            color: #AFC1D5;
            font-size: 12px;
        }

        .footer-col ul {
            display: grid;
            gap: 10px;
            list-style: none;
        }

        .footer-col ul a {
            display: inline-block;
            color: #AFC1D5;
            font-size: 12px;
            text-decoration: none;
            transition: color var(--transition), transform var(--transition);
        }

        .footer-col ul a:hover {
            color: var(--cyan-light);
            transform: translateX(4px);
        }

        .footer-bottom {
            max-width: 1200px;
            margin: 0 auto;
            padding-top: 22px;
            border-top: 1px solid var(--border);
            color: #94A3B8;
            font-size: 11px;
            text-align: center;
        }

        /* =========================================================
           VALIDATION NOTIFICATION
           ========================================================= */

        .warning-card {
            position: fixed;
            z-index: 12000;
            top: 20px;
            left: 50%;
            width: max-content;
            max-width: calc(100% - 32px);
            padding: 14px 20px;
            border: 1px solid rgba(248, 113, 113, .5);
            border-radius: 13px;
            color: #FECACA;
            background: rgba(69, 10, 10, .95);
            box-shadow: 0 12px 35px rgba(0, 0, 0, .3);
            opacity: 0;
            pointer-events: none;
            transform: translate(-50%, -20px);
            transition: opacity var(--transition), transform var(--transition);
            font-size: 12px;
        }

        .warning-card.show {
            opacity: 1;
            transform: translate(-50%, 0);
        }

        .shake {
            animation: inputShake .35s ease;
            border-color: #F87171 !important;
        }

        @keyframes inputShake {
            25% { transform: translateX(-4px); }
            50% { transform: translateX(4px); }
            75% { transform: translateX(-3px); }
        }

        /* =========================================================
           SCROLL REVEAL
           ========================================================= */

        .reveal {
            opacity: 0;
            transform: translateY(25px);
            transition: opacity .7s ease, transform .7s cubic-bezier(.2, .8, .2, 1);
        }

        .reveal.is-visible {
            opacity: 1;
            transform: translateY(0);
        }

        .reveal-delay-1 { transition-delay: .08s; }
        .reveal-delay-2 { transition-delay: .16s; }
        .reveal-delay-3 { transition-delay: .24s; }

        /* =========================================================
           TABLET
           ========================================================= */

        @media (max-width: 1100px) {
            .site-nav {
                grid-template-columns: minmax(140px, 1fr) auto minmax(140px, 1fr);
                gap: 10px;
                padding-inline: 3%;
            }

            .nav-links {
                gap: 2px;
            }

            .nav-links a {
                padding-inline: 8px;
                font-size: 11px;
            }

            .brand-name {
                font-size: 21px;
            }

            .btn-nav-login,
            .btn-nav-register {
                padding-inline: 11px;
            }

            .features-grid,
            .steps-container,
            .internships-grid,
            .journey-container {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            .search-form {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }

        /* =========================================================
           MOBILE
           ========================================================= */

        @media (max-width: 760px) {
            html {
                scroll-padding-top: 80px;
            }

            .site-nav {
                display: flex;
                justify-content: space-between;
                min-height: 68px;
                padding: 10px 5%;
            }

            .brand-name {
                font-size: 22px;
            }

            .brand img {
                width: 34px;
                height: 34px;
            }

            .nav-auth {
                margin-left: auto;
            }

            .btn-nav-login,
            .btn-nav-register {
                min-height: 37px;
                padding: 7px 10px;
                font-size: 11px;
            }

            .menu-toggle {
                display: block;
                order: 3;
                flex-shrink: 0;
                margin-left: 8px;
            }

            .nav-links {
                position: fixed;
                top: 68px;
                right: 0;
                left: 0;
                display: flex;
                flex-direction: column;
                align-items: stretch;
                gap: 7px;
                max-height: calc(100dvh - 68px);
                overflow-y: auto;
                padding: 16px 5% 24px;
                border-bottom: 1px solid var(--border);
                background: rgba(7, 30, 61, .98);
                opacity: 0;
                visibility: hidden;
                pointer-events: none;
                transform: translateY(-10px);
                transition: opacity var(--transition), transform var(--transition), visibility var(--transition);
            }

            .nav-links.menu-visible {
                opacity: 1;
                visibility: visible;
                pointer-events: auto;
                transform: translateY(0);
            }

            .nav-links a {
                justify-content: flex-start;
                width: 100%;
                min-height: 46px;
                padding-inline: 15px;
                font-size: 13px;
            }

            .hero-section {
                min-height: 94svh;
                padding: 130px 6% 100px;
            }

            .hero h1 {
                font-size: clamp(40px, 11vw, 62px);
                letter-spacing: -2px;
            }

            .hero-badge {
                font-size: 10px;
            }

            .hero-metrics {
                gap: 18px;
            }

            .hero-metric {
                min-width: 85px;
            }

            .hero-metric strong {
                font-size: 21px;
            }

            section.content-section {
                padding: 70px 5%;
            }

            .features-grid,
            .steps-container,
            .internships-grid,
            .journey-container {
                grid-template-columns: 1fr;
            }

            .feature-card,
            .step-card,
            .internship-card {
                padding: 23px;
            }

            .journey-card {
                align-items: center;
            }

            .contact-grid,
            .footer-grid {
                grid-template-columns: 1fr;
            }

            .footer-grid {
                gap: 25px;
            }

            .intro-journey {
                grid-template-columns: repeat(2, minmax(0, 1fr));
                gap: 10px;
            }

            .intro-step {
                padding: 17px 10px;
            }

            .intro-title {
                font-size: clamp(36px, 10vw, 54px);
                letter-spacing: -1.5px;
            }

            .intro-subtitle {
                font-size: 12px;
            }

            .scanline {
                opacity: .025;
            }
        }

        @media (max-width: 390px) {
            .brand-name {
                font-size: 19px;
            }

            .brand {
                gap: 6px;
            }

            .brand img {
                width: 29px;
                height: 29px;
            }

            .nav-auth {
                gap: 5px;
            }

            .btn-nav-login,
            .btn-nav-register {
                padding-inline: 8px;
                font-size: 10px;
            }

            .menu-toggle {
                width: 36px;
                height: 38px;
            }

            .search-form {
                grid-template-columns: 1fr;
            }

            .hero-buttons {
                flex-direction: column;
                align-items: stretch;
            }

            .hero-buttons a {
                width: 100%;
            }

            .hero-metrics {
                gap: 12px;
            }

            .hero-metric {
                min-width: 75px;
            }
        }

        /* =========================================================
           ACCESSIBILITY — REDUCED MOTION
           ========================================================= */

        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                scroll-behavior: auto !important;
                animation-duration: .01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: .01ms !important;
            }

            .reveal {
                opacity: 1;
                transform: none;
            }

            #particleCanvas,
            .scanline {
                display: none;
            }
        }
    </style>
</head>

<body class="intro-active">

    <!-- Global animated background -->

    <div class="ambient-background" aria-hidden="true">
        <div class="ambient-grid"></div>
        <div class="ambient-orb orb-one"></div>
        <div class="ambient-orb orb-two"></div>
        <div class="ambient-orb orb-three"></div>
        <canvas id="particleCanvas"></canvas>
    </div>

    <div class="scanline" aria-hidden="true"></div>

    <!-- Introduction -->

    <div
        id="internproIntro"
        role="dialog"
        aria-modal="true"
        aria-labelledby="introTitle"
    >
        <div class="intro-shell">

            <a href="index.php" class="intro-brand" aria-label="InternPro home">
                <img src="assets/logo.jpg" alt="">
                <span class="brand-name">Intern<span>Pro</span></span>
            </a>

            <span class="intro-kicker">YOUR INTERNSHIP JOURNEY</span>

            <h1 class="intro-title" id="introTitle">
                Start Your Journey.<br>
                <span class="gradient-text">Build Your Future.</span>
            </h1>

            <p class="intro-subtitle">
                Build your profile, discover opportunities, apply with confidence,
                and grow your career with InternPro.
            </p>

            <div class="intro-journey">

                <article class="intro-step">
                    <div class="intro-step-number">01</div>
                    <h3>Build</h3>
                    <p>Create your student profile</p>
                </article>

                <article class="intro-step">
                    <div class="intro-step-number">02</div>
                    <h3>Discover</h3>
                    <p>Find the right opportunity</p>
                </article>

                <article class="intro-step">
                    <div class="intro-step-number">03</div>
                    <h3>Apply</h3>
                    <p>Take your next step</p>
                </article>

                <article class="intro-step">
                    <div class="intro-step-number">04</div>
                    <h3>Grow</h3>
                    <p>Turn experience into progress</p>
                </article>

            </div>

            <button type="button" class="intro-start" id="introStartButton">
                Start Exploring
                <span class="arrow" aria-hidden="true">→</span>
            </button>

            <div class="intro-progress" aria-hidden="true">
                <span></span>
            </div>

        </div>
    </div>

    <!-- Validation notification -->

    <div class="warning-card" id="warningCard" role="alert" aria-live="polite">
        <span aria-hidden="true">⚠️</span>
        <span id="warningText">Please enter a search keyword.</span>
    </div>

    <!-- Navigation -->

    <nav class="site-nav" aria-label="Main navigation">

        <a href="index.php" class="brand" aria-label="InternPro home">
            <img src="assets/logo.jpg" alt="">
            <span class="brand-name">Intern<span>Pro</span></span>
        </a>

        <ul class="nav-links" id="navLinks">
            <li><a href="#internships">Internships</a></li>
            <li><a href="#how-it-works">How It Works</a></li>
            <li><a href="index.php" aria-current="page">Home</a></li>
            <li><a href="#faq">FAQ</a></li>
            <li><a href="#contact">Support</a></li>
        </ul>

        <div class="nav-auth">
            <a href="login.php" class="btn-nav-login">Login</a>
            <a href="register.php" class="btn-nav-register">Register</a>
        </div>

        <button
            type="button"
            class="menu-toggle"
            id="menuToggle"
            aria-label="Open navigation menu"
            aria-expanded="false"
            aria-controls="navLinks"
        >
            <span></span>
            <span></span>
        </button>

    </nav>

    <main>

        <!-- Hero -->

        <section class="hero-section" id="home">
            <div class="hero">

                <div class="hero-badge">
                    <span class="status-dot" aria-hidden="true"></span>
                    YOUR CAREER JOURNEY STARTS HERE
                </div>

                <h1>
                    Make Your College Years
                    <span class="gradient-text">Count.</span>
                </h1>

                <p>
                    Turn your college journey into skills, experience,
                    and career opportunities. Discover your next step
                    and make your potential count.
                </p>

                <div class="hero-buttons">
                    <a href="#internships" class="btn-primary">
                        Explore Internships
                        <span aria-hidden="true">↗</span>
                    </a>

                    <a href="register.php" class="btn-secondary">
                        Build Your Profile
                        <span aria-hidden="true">→</span>
                    </a>
                </div>

                <div class="hero-metrics">
                    <div class="hero-metric">
                        <strong>01</strong>
                        <span>Build your profile</span>
                    </div>

                    <div class="hero-metric">
                        <strong>02</strong>
                        <span>Discover opportunities</span>
                    </div>

                    <div class="hero-metric">
                        <strong>03</strong>
                        <span>Grow your career</span>
                    </div>
                </div>

            </div>

            <a href="#journey" class="scroll-indicator">
                EXPLORE
                <span></span>
            </a>
        </section>

        <!-- Internship journey -->

        <section class="content-section" id="journey">

            <div class="section-heading reveal">
                <span class="eyebrow">YOUR ROADMAP</span>
                <h2 class="section-title">Your Internship Journey</h2>
                <p class="section-subtitle">
                    From building your profile to tracking your application,
                    keep every step of your career journey organized.
                </p>
            </div>

            <div class="journey-container">

                <article class="journey-card glass-card reveal">
                    <div class="journey-icon" aria-hidden="true">01</div>
                    <div>
                        <h3>Build Your Profile</h3>
                        <p>Add your academic details, skills, interests and resume.</p>
                    </div>
                </article>

                <article class="journey-card glass-card reveal reveal-delay-1">
                    <div class="journey-icon" aria-hidden="true">02</div>
                    <div>
                        <h3>Discover Internships</h3>
                        <p>Explore opportunities that match your interests and skills.</p>
                    </div>
                </article>

                <article class="journey-card glass-card reveal reveal-delay-2">
                    <div class="journey-icon" aria-hidden="true">03</div>
                    <div>
                        <h3>Apply with Confidence</h3>
                        <p>Take your next step towards real-world experience.</p>
                    </div>
                </article>

                <article class="journey-card glass-card reveal reveal-delay-3">
                    <div class="journey-icon" aria-hidden="true">04</div>
                    <div>
                        <h3>Track Your Progress</h3>
                        <p>Follow your application through the recruitment process.</p>
                    </div>
                </article>

            </div>

        </section>

        <!-- Features -->

        <section class="content-section" id="why-us">

            <div class="section-heading reveal">
                <span class="eyebrow">BUILT FOR YOUR GROWTH</span>
                <h2 class="section-title">Everything You Need to Get Started</h2>
                <p class="section-subtitle">
                    Build your skills, discover opportunities, apply,
                    and manage your internship applications in one place.
                </p>
            </div>

            <div class="features-grid">

                <article class="feature-card glass-card reveal">
                    <div class="feature-icon" aria-hidden="true">🎓</div>
                    <h3>Build Your Profile</h3>
                    <p>
                        Create a student profile that represents your
                        academic background, skills and experience.
                    </p>
                </article>

                <article class="feature-card glass-card reveal reveal-delay-1">
                    <div class="feature-icon" aria-hidden="true">🔎</div>
                    <h3>Discover Opportunities</h3>
                    <p>
                        Explore opportunities by skill, location,
                        internship type and your career interests.
                    </p>
                </article>

                <article class="feature-card glass-card reveal reveal-delay-2">
                    <div class="feature-icon" aria-hidden="true">📄</div>
                    <h3>Apply Easily</h3>
                    <p>
                        Submit applications for suitable internships
                        through your student account.
                    </p>
                </article>

                <article class="feature-card glass-card reveal reveal-delay-3">
                    <div class="feature-icon" aria-hidden="true">📊</div>
                    <h3>Track Your Progress</h3>
                    <p>
                        Monitor recorded application statuses from
                        submission through the final decision.
                    </p>
                </article>

            </div>

        </section>

        <!-- How it works -->

        <section class="content-section" id="how-it-works">

            <div class="section-heading reveal">
                <span class="eyebrow">SIMPLE. CLEAR. ORGANIZED.</span>
                <h2 class="section-title">How It Works</h2>
                <p class="section-subtitle">
                    Four simple steps to help you move from your college profile
                    to practical industry experience.
                </p>
            </div>

            <div class="steps-container">

                <article class="step-card glass-card reveal">
                    <div class="step-number">01</div>
                    <h3>Create Your Profile</h3>
                    <p>Add your academic details, skills, interests and resume.</p>
                </article>

                <article class="step-card glass-card reveal reveal-delay-1">
                    <div class="step-number">02</div>
                    <h3>Find Opportunities</h3>
                    <p>Explore internship listings that match your interests.</p>
                </article>

                <article class="step-card glass-card reveal reveal-delay-2">
                    <div class="step-number">03</div>
                    <h3>Submit Applications</h3>
                    <p>Apply for internships that fit your career goals.</p>
                </article>

                <article class="step-card glass-card reveal reveal-delay-3">
                    <div class="step-number">04</div>
                    <h3>Follow Your Journey</h3>
                    <p>Check application updates through your student account.</p>
                </article>

            </div>

        </section>

        <!-- Search -->

        <section class="content-section" id="find-opportunity">

            <div class="search-box-container glass-card reveal">

                <div class="section-heading">
                    <span class="eyebrow">DISCOVER YOUR NEXT STEP</span>
                    <h2 class="section-title">Find Your Opportunity</h2>
                    <p class="section-subtitle">
                        Search by role, skill, company, location or internship type.
                    </p>
                </div>

                <form
                    id="mainSearchForm"
                    action="login.php"
                    method="GET"
                    class="search-form"
                >
                    <input
                        type="search"
                        id="mainSearchInput"
                        name="query"
                        class="search-input"
                        placeholder="Search role, skill or company"
                        aria-label="Search by role, skill or company"
                        maxlength="150"
                        required
                    >

                    <select name="location" class="search-select" aria-label="Location">
                        <option value="">All Locations</option>
                        <option value="remote">Remote</option>
                        <option value="bengaluru">Bengaluru</option>
                        <option value="chennai">Chennai</option>
                        <option value="hyderabad">Hyderabad</option>
                    </select>

                    <select name="type" class="search-select" aria-label="Internship type">
                        <option value="">Internship Type</option>
                        <option value="full-time">Full-time</option>
                        <option value="part-time">Part-time</option>
                    </select>

                    <button type="submit" class="btn-search">
                        Search <span aria-hidden="true">↗</span>
                    </button>
                </form>

                <p class="search-note">
                    You may need to log in to continue with internship-related actions.
                </p>

            </div>

        </section>

        <!-- Featured opportunities -->

        <section class="content-section" id="internships">

            <div class="section-heading reveal">
                <span class="eyebrow">EXPLORE POSSIBILITIES</span>
                <h2 class="section-title">Featured Opportunities</h2>
                <p class="section-subtitle">
                    Example listings for the portal interface.
                    Confirm actual openings before presenting these as live vacancies.
                </p>
            </div>

            <div class="internships-grid">

                <article class="internship-card glass-card reveal">
                    <div>
                        <span class="internship-label">WEB DEVELOPMENT</span>
                        <h3 class="internship-title">Web Developer</h3>
                        <p class="company-name">TechCorp Solutions</p>

                        <div class="internship-details">
                            <div class="detail-row"><span class="symbol" aria-hidden="true">📍</span> Remote / Hybrid</div>
                            <div class="detail-row"><span class="symbol" aria-hidden="true">⏱️</span> 3 Months</div>
                            <div class="detail-row"><span class="symbol" aria-hidden="true">💰</span> Example: ₹15,000 / month</div>
                        </div>

                        <div class="skills-list">
                            <span class="skills-tag">PHP</span>
                            <span class="skills-tag">JavaScript</span>
                            <span class="skills-tag">MySQL</span>
                        </div>
                    </div>

                    <a href="login.php" class="btn-details">View Details →</a>
                </article>

                <article class="internship-card glass-card reveal reveal-delay-1">
                    <div>
                        <span class="internship-label">SOFTWARE DEVELOPMENT</span>
                        <h3 class="internship-title">Java Developer</h3>
                        <p class="company-name">InnoSoft Systems</p>

                        <div class="internship-details">
                            <div class="detail-row"><span class="symbol" aria-hidden="true">📍</span> Bengaluru</div>
                            <div class="detail-row"><span class="symbol" aria-hidden="true">⏱️</span> 6 Months</div>
                            <div class="detail-row"><span class="symbol" aria-hidden="true">💰</span> Example: ₹20,000 / month</div>
                        </div>

                        <div class="skills-list">
                            <span class="skills-tag">Java</span>
                            <span class="skills-tag">Spring Boot</span>
                            <span class="skills-tag">SQL</span>
                        </div>
                    </div>

                    <a href="login.php" class="btn-details">View Details →</a>
                </article>

                <article class="internship-card glass-card reveal reveal-delay-2">
                    <div>
                        <span class="internship-label">ARTIFICIAL INTELLIGENCE</span>
                        <h3 class="internship-title">AI / Python Intern</h3>
                        <p class="company-name">NextGen AI Labs</p>

                        <div class="internship-details">
                            <div class="detail-row"><span class="symbol" aria-hidden="true">📍</span> Chennai</div>
                            <div class="detail-row"><span class="symbol" aria-hidden="true">⏱️</span> 6 Months</div>
                            <div class="detail-row"><span class="symbol" aria-hidden="true">💰</span> Example: ₹18,000 / month</div>
                        </div>

                        <div class="skills-list">
                            <span class="skills-tag">Python</span>
                            <span class="skills-tag">Machine Learning</span>
                            <span class="skills-tag">Pandas</span>
                        </div>
                    </div>

                    <a href="login.php" class="btn-details">View Details →</a>
                </article>

                <article class="internship-card glass-card reveal reveal-delay-3">
                    <div>
                        <span class="internship-label">START YOUR JOURNEY</span>
                        <h3 class="internship-title">Find Your Opportunity</h3>
                        <p class="company-name">Explore your interests</p>

                        <div class="internship-details">
                            <div class="detail-row"><span class="symbol" aria-hidden="true">🔎</span> Search opportunities</div>
                            <div class="detail-row"><span class="symbol" aria-hidden="true">🧠</span> Match your skills</div>
                            <div class="detail-row"><span class="symbol" aria-hidden="true">🚀</span> Take your next step</div>
                        </div>

                        <div class="skills-list">
                            <span class="skills-tag">Your Skills</span>
                            <span class="skills-tag">Your Goals</span>
                        </div>
                    </div>

                    <a href="register.php" class="btn-details">Get Started →</a>
                </article>

            </div>

        </section>

        <!-- FAQ -->

        <section class="content-section" id="faq">

            <div class="section-heading reveal">
                <span class="eyebrow">GOT QUESTIONS?</span>
                <h2 class="section-title">Frequently Asked Questions</h2>
                <p class="section-subtitle">
                    Helpful answers about using the internship portal.
                </p>
            </div>

            <div class="faq-list">

                <article class="faq-card glass-card reveal">
                    <button type="button" class="faq-question" aria-expanded="false">
                        Who can apply for internships on InternPro?
                    </button>
                    <div class="faq-answer">
                        <div class="faq-answer-inner">
                            <p>
                                Students who meet the eligibility requirements of an
                                internship can apply through the portal.
                            </p>
                        </div>
                    </div>
                </article>

                <article class="faq-card glass-card reveal">
                    <button type="button" class="faq-question" aria-expanded="false">
                        Are all internships paid?
                    </button>
                    <div class="faq-answer">
                        <div class="faq-answer-inner">
                            <p>
                                Payment depends on the individual opportunity.
                                Check each listing for stipend details and conditions.
                            </p>
                        </div>
                    </div>
                </article>

                <article class="faq-card glass-card reveal">
                    <button type="button" class="faq-question" aria-expanded="false">
                        How do I apply for an internship?
                    </button>
                    <div class="faq-answer">
                        <div class="faq-answer-inner">
                            <p>
                                Create an account, complete your student profile,
                                explore an internship and follow the application process.
                            </p>
                        </div>
                    </div>
                </article>

                <article class="faq-card glass-card reveal">
                    <button type="button" class="faq-question" aria-expanded="false">
                        Can I track my application status?
                    </button>
                    <div class="faq-answer">
                        <div class="faq-answer-inner">
                            <p>
                                Your student area can display the application status
                                recorded by the portal.
                            </p>
                        </div>
                    </div>
                </article>

                <article class="faq-card glass-card reveal">
                    <button type="button" class="faq-question" aria-expanded="false">
                        Can I upload my resume?
                    </button>
                    <div class="faq-answer">
                        <div class="faq-answer-inner">
                            <p>
                                Use the resume upload feature if it is enabled in your
                                student profile, and follow the supported file requirements.
                            </p>
                        </div>
                    </div>
                </article>

                <article class="faq-card glass-card reveal">
                    <button type="button" class="faq-question" aria-expanded="false">
                        Can companies manage applicants?
                    </button>
                    <div class="faq-answer">
                        <div class="faq-answer-inner">
                            <p>
                                Authorized company accounts can manage internship listings
                                and review applicants according to portal permissions.
                            </p>
                        </div>
                    </div>
                </article>

            </div>

        </section>

        <!-- Contact -->

        <section class="content-section" id="contact">

            <div class="section-heading reveal">
                <span class="eyebrow">WE'RE HERE TO HELP</span>
                <h2 class="section-title">Support & Contact</h2>
                <p class="section-subtitle">
                    Have a question about the portal? Reach out to the support team.
                </p>
            </div>

            <?php if ($contact_sent): ?>
                <div class="alert-success" role="status">
                    Your form was submitted, but message delivery has not been confirmed.
                </div>
            <?php endif; ?>

            <div class="contact-grid">

                <div class="contact-info glass-card reveal">
                    <h3>Get in Touch</h3>

                    <div class="info-item">
                        <strong>✉️ Email</strong>
                        <a href="mailto:support@internpro.com">
                            support@internpro.com
                        </a>
                    </div>

                    <div class="info-item">
                        <strong>📍 Location</strong>
                        Chennai, India
                    </div>

                    <div class="info-item">
                        <strong>💡 Need help?</strong>
                        Include enough detail about your question so the support team
                        can understand what you need.
                    </div>
                </div>

                <div class="contact-form-box glass-card reveal reveal-delay-1">
                    <h3>Send a Message</h3>

                    <form action="index.php#contact" method="POST" id="contactForm">

                        <div class="form-group">
                            <label for="contactName">Your Name</label>
                            <input
                                type="text"
                                id="contactName"
                                name="name"
                                class="form-control"
                                placeholder="Enter your name"
                                autocomplete="name"
                                maxlength="100"
                                required
                            >
                        </div>

                        <div class="form-group">
                            <label for="contactEmail">Your Email</label>
                            <input
                                type="email"
                                id="contactEmail"
                                name="email"
                                class="form-control"
                                placeholder="Enter your email"
                                autocomplete="email"
                                maxlength="254"
                                required
                            >
                        </div>

                        <div class="form-group">
                            <label for="contactMessage">Message</label>
                            <textarea
                                id="contactMessage"
                                name="message"
                                class="form-control"
                                placeholder="Tell us how we can help..."
                                maxlength="3000"
                                required
                            ></textarea>
                        </div>

                        <button
                            type="submit"
                            name="contact_submit"
                            value="1"
                            class="btn-submit"
                        >
                            Submit Message <span aria-hidden="true">→</span>
                        </button>

                        <p class="search-note">
                            Message delivery requires a configured backend handler.
                        </p>

                    </form>
                </div>

            </div>

        </section>

    </main>

    <!-- Footer -->

    <footer class="site-footer">

        <div class="footer-grid">

            <div class="footer-col">
                <a href="index.php" class="brand">
                    <img src="assets/logo.jpg" alt="">
                    <span class="brand-name">Intern<span>Pro</span></span>
                </a>

                <p>
                    Helping students discover opportunities, develop skills,
                    and take their next career step.
                </p>
            </div>

            <div class="footer-col">
                <h4>Explore</h4>
                <ul>
                    <li><a href="#journey">Your Journey</a></li>
                    <li><a href="#how-it-works">How It Works</a></li>
                    <li><a href="#internships">Internships</a></li>
                    <li><a href="#find-opportunity">Find Opportunities</a></li>
                </ul>
            </div>

            <div class="footer-col">
                <h4>Your Account</h4>
                <ul>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="register.php">Register</a></li>
                    <li><a href="#faq">Frequently Asked Questions</a></li>
                    <li><a href="#contact">Contact Support</a></li>
                </ul>
            </div>

        </div>

        <div class="footer-bottom">
            &copy; <?php echo date('Y'); ?> InternPro. All rights reserved.
        </div>

    </footer>

    <script>
        'use strict';

        /* =========================================================
           INTRO EXPERIENCE
           ========================================================= */

        (function initIntro() {
            const intro = document.getElementById('internproIntro');
            const startButton = document.getElementById('introStartButton');
            const reducedMotion = window.matchMedia(
                '(prefers-reduced-motion: reduce)'
            );

            if (!intro || !startButton) {
                document.body.classList.remove('intro-active');
                return;
            }

            let closed = false;

            function closeIntro() {
                if (closed) return;

                closed = true;
                startButton.disabled = true;
                intro.classList.add('intro-loading');

                window.setTimeout(function () {
                    intro.classList.add('intro-leaving');
                    document.body.classList.remove('intro-active');

                    window.setTimeout(function () {
                        intro.remove();
                    }, reducedMotion.matches ? 0 : 750);

                }, reducedMotion.matches ? 0 : 1100);
            }

            startButton.addEventListener('click', closeIntro);

            document.addEventListener('keydown', function (event) {
                if (event.key === 'Escape' && !closed) {
                    closeIntro();
                }
            });
        })();

        /* =========================================================
           RESPONSIVE MOBILE NAVIGATION
           ========================================================= */

        (function initMobileNavigation() {
            const toggle = document.getElementById('menuToggle');
            const links = document.getElementById('navLinks');

            if (!toggle || !links) return;

            function setMenu(open) {
                toggle.setAttribute('aria-expanded', String(open));

                toggle.setAttribute(
                    'aria-label',
                    open ? 'Close navigation menu' : 'Open navigation menu'
                );

                links.classList.toggle('menu-visible', open);
                document.body.classList.toggle('menu-open', open);
            }

            toggle.addEventListener('click', function () {
                const open = toggle.getAttribute('aria-expanded') === 'true';
                setMenu(!open);
            });

            links.querySelectorAll('a').forEach(function (link) {
                link.addEventListener('click', function () {
                    setMenu(false);
                });
            });

            document.addEventListener('keydown', function (event) {
                if (event.key === 'Escape') {
                    setMenu(false);
                }
            });

            document.addEventListener('click', function (event) {
                if (
                    toggle.getAttribute('aria-expanded') === 'true' &&
                    !links.contains(event.target) &&
                    !toggle.contains(event.target)
                ) {
                    setMenu(false);
                }
            });

            window.addEventListener('resize', function () {
                if (window.innerWidth > 760) {
                    setMenu(false);
                }
            });
        })();

        /* =========================================================
           ACCESSIBLE FAQ ACCORDION
           ========================================================= */

        document.querySelectorAll('.faq-question').forEach(function (button) {
            button.addEventListener('click', function () {
                const card = button.closest('.faq-card');

                if (!card) return;

                const shouldOpen = !card.classList.contains('active');

                card.classList.toggle('active', shouldOpen);
                button.setAttribute('aria-expanded', String(shouldOpen));
            });
        });

        /* =========================================================
           SCROLL REVEAL
           ========================================================= */

        (function initScrollReveal() {
            const elements = document.querySelectorAll('.reveal');

            if (!('IntersectionObserver' in window)) {
                elements.forEach(function (element) {
                    element.classList.add('is-visible');
                });

                return;
            }

            const observer = new IntersectionObserver(function (entries) {
                entries.forEach(function (entry) {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('is-visible');
                        observer.unobserve(entry.target);
                    }
                });
            }, {
                threshold: 0.12,
                rootMargin: '0px 0px -25px 0px'
            });

            elements.forEach(function (element) {
                observer.observe(element);
            });
        })();

        /* =========================================================
           SEARCH VALIDATION
           ========================================================= */

        (function initSearchValidation() {
            const form = document.getElementById('mainSearchForm');
            const input = document.getElementById('mainSearchInput');
            const warning = document.getElementById('warningCard');
            const warningText = document.getElementById('warningText');

            if (!form || !input || !warning || !warningText) return;

            let warningTimer;

            function showWarning(message) {
                warningText.textContent = message;
                warning.classList.add('show');

                window.clearTimeout(warningTimer);

                warningTimer = window.setTimeout(function () {
                    warning.classList.remove('show');
                }, 2600);
            }

            form.addEventListener('submit', function (event) {
                if (!input.value.trim()) {
                    event.preventDefault();

                    input.classList.remove('shake');
                    void input.offsetWidth;
                    input.classList.add('shake');

                    input.focus();

                    showWarning('Please enter a role, skill or company.');
                    return;
                }

                input.value = input.value.trim();
            });

            input.addEventListener('animationend', function () {
                input.classList.remove('shake');
            });
        })();

        /* =========================================================
           CYAN PARTICLE NETWORK
           Optimized rendering, visibility pause and reduced motion.
           ========================================================= */

        (function initParticles() {
            const canvas = document.getElementById('particleCanvas');

            if (!canvas) return;

            const context = canvas.getContext('2d');

            if (!context) return;

            const reducedMotion = window.matchMedia(
                '(prefers-reduced-motion: reduce)'
            );

            const particles = [];

            let width = 0;
            let height = 0;
            let frameId = 0;
            let lastFrame = 0;
            let pixelRatio = 1;

            function resizeCanvas() {
                pixelRatio = Math.min(window.devicePixelRatio || 1, 1.5);

                width = window.innerWidth;
                height = window.innerHeight;

                canvas.width = Math.floor(width * pixelRatio);
                canvas.height = Math.floor(height * pixelRatio);

                context.setTransform(
                    pixelRatio,
                    0,
                    0,
                    pixelRatio,
                    0,
                    0
                );

                const count = Math.min(
                    60,
                    Math.max(20, Math.floor(width / 23))
                );

                particles.length = 0;

                for (let i = 0; i < count; i++) {
                    particles.push({
                        x: Math.random() * width,
                        y: Math.random() * height,
                        radius: Math.random() * 1.6 + .5,
                        speed: Math.random() * .25 + .07,
                        alpha: Math.random() * .5 + .15,
                        phase: Math.random() * Math.PI * 2
                    });
                }
            }

            function draw(timestamp) {
                if (reducedMotion.matches || document.hidden) {
                    frameId = 0;
                    return;
                }

                // Limit canvas work to roughly 30 frames per second.
                if (timestamp - lastFrame < 33) {
                    frameId = requestAnimationFrame(draw);
                    return;
                }

                lastFrame = timestamp;

                context.clearRect(0, 0, width, height);

                particles.forEach(function (particle, index) {
                    particle.y -= particle.speed;
                    particle.phase += .012;

                    if (particle.y < -5) {
                        particle.y = height + 5;
                        particle.x = Math.random() * width;
                    }

                    const alpha = particle.alpha *
                        (.72 + Math.sin(particle.phase) * .28);

                    context.beginPath();

                    context.arc(
                        particle.x,
                        particle.y,
                        particle.radius,
                        0,
                        Math.PI * 2
                    );

                    context.fillStyle = index % 5 === 0
                        ? 'rgba(0,180,216,' + alpha + ')'
                        : 'rgba(56,189,248,' + alpha + ')';

                    context.fill();

                    // Connect only nearby particles.
                    for (let j = index + 1; j < particles.length; j++) {
                        const other = particles[j];
                        const dx = particle.x - other.x;
                        const dy = particle.y - other.y;
                        const distance = Math.sqrt(dx * dx + dy * dy);

                        if (distance < 100) {
                            context.beginPath();
                            context.moveTo(particle.x, particle.y);
                            context.lineTo(other.x, other.y);

                            context.strokeStyle =
                                'rgba(0,180,216,' +
                                ((1 - distance / 100) * .14) + ')';

                            context.lineWidth = .6;
                            context.stroke();
                        }
                    }
                });

                frameId = requestAnimationFrame(draw);
            }

            function stopAnimation() {
                if (frameId) {
                    cancelAnimationFrame(frameId);
                    frameId = 0;
                }
            }

            function startAnimation() {
                stopAnimation();

                if (reducedMotion.matches || document.hidden) return;

                frameId = requestAnimationFrame(draw);
            }

            resizeCanvas();
            startAnimation();

            window.addEventListener('resize', function () {
                resizeCanvas();
                startAnimation();
            }, { passive: true });

            document.addEventListener('visibilitychange', function () {
                if (document.hidden) {
                    stopAnimation();
                } else {
                    startAnimation();
                }
            });

            if (reducedMotion.addEventListener) {
                reducedMotion.addEventListener('change', function () {
                    if (reducedMotion.matches) {
                        stopAnimation();
                        context.clearRect(0, 0, width, height);
                    } else {
                        startAnimation();
                    }
                });
            }
        })();
    </script>

</body>
</html>
