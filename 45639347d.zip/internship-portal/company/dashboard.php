<?php
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (
    !isset($_SESSION['user_id'], $_SESSION['role']) ||
    !in_array(strtolower((string) $_SESSION['role']), ['company', 'recruiter'], true)
) {
    header('Location: ../login.php');
    exit;
}

require_once __DIR__ . '/../config/database.php';

if (!isset($pdo) || !($pdo instanceof PDO)) {
    http_response_code(500);
    exit('Database connection is not configured correctly. Please check config/database.php.');
}

$userId = (int) $_SESSION['user_id'];
$companyName = $_SESSION['name'] ?? $_SESSION['company_name'] ?? 'Company';
$companyId = null;

$stats = [
    'internships' => 0,
    'active' => 0,
    'applications' => 0,
    'shortlisted' => 0,
];

$recentApplications = [];
$recentInternships = [];
$dbWarning = '';

function h($value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function getColumns(PDO $pdo, string $table): array
{
    $allowedTables = [
        'users',
        'companies',
        'internships',
        'applications',
        'students',
    ];

    if (!in_array($table, $allowedTables, true)) {
        return [];
    }

    try {
        $stmt = $pdo->query("SHOW COLUMNS FROM `$table`");
        return array_column($stmt->fetchAll(PDO::FETCH_ASSOC), 'Field');
    } catch (Throwable $e) {
        return [];
    }
}

function firstColumn(array $columns, array $candidates): ?string
{
    foreach ($candidates as $candidate) {
        if (in_array($candidate, $columns, true)) {
            return $candidate;
        }
    }

    return null;
}

try {
    $companyColumns = getColumns($pdo, 'companies');
    $internshipColumns = getColumns($pdo, 'internships');
    $applicationColumns = getColumns($pdo, 'applications');
    $studentColumns = getColumns($pdo, 'students');

    // Resolve the company record associated with the logged-in user.
    if (
        in_array('id', $companyColumns, true) &&
        in_array('user_id', $companyColumns, true)
    ) {
        $stmt = $pdo->prepare(
            'SELECT * FROM companies WHERE user_id = :user_id LIMIT 1'
        );
        $stmt->execute(['user_id' => $userId]);
        $company = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($company) {
            $companyId = (int) $company['id'];

            foreach (['company_name', 'name', 'organization_name'] as $nameColumn) {
                if (!empty($company[$nameColumn])) {
                    $companyName = $company[$nameColumn];
                    break;
                }
            }
        }
    }

    // If the companies table does not have a user_id mapping, try users.name.
    if (!$companyId && in_array('name', getColumns($pdo, 'users'), true)) {
        $stmt = $pdo->prepare('SELECT name FROM users WHERE id = :id LIMIT 1');
        $stmt->execute(['id' => $userId]);
        $name = $stmt->fetchColumn();

        if ($name) {
            $companyName = $name;
        }
    }

    // Count internships belonging to this company.
    $internshipCompanyColumn = firstColumn(
        $internshipColumns,
        ['company_id', 'employer_id']
    );

    $internshipIdColumn = firstColumn($internshipColumns, ['id']);
    $internshipTitleColumn = firstColumn(
        $internshipColumns,
        ['title', 'internship_title', 'position']
    );
    $internshipStatusColumn = firstColumn(
        $internshipColumns,
        ['status', 'application_status']
    );
    $internshipCreatedColumn = firstColumn(
        $internshipColumns,
        ['created_at', 'posted_at', 'date_posted']
    );

    if ($companyId && $internshipCompanyColumn && $internshipIdColumn) {
        $where = "`$internshipCompanyColumn` = :company_id";

        $stmt = $pdo->prepare(
            "SELECT COUNT(*) FROM internships WHERE $where"
        );
        $stmt->execute(['company_id' => $companyId]);
        $stats['internships'] = (int) $stmt->fetchColumn();

        if ($internshipStatusColumn) {
            $stmt = $pdo->prepare(
                "SELECT COUNT(*) FROM internships
                 WHERE `$internshipCompanyColumn` = :company_id
                 AND LOWER(`$internshipStatusColumn`) IN ('active', 'open', 'published')"
            );
            $stmt->execute(['company_id' => $companyId]);
            $stats['active'] = (int) $stmt->fetchColumn();
        } else {
            $stats['active'] = $stats['internships'];
        }

        $orderBy = $internshipCreatedColumn
            ? " ORDER BY `$internshipCreatedColumn` DESC"
            : " ORDER BY `$internshipIdColumn` DESC";

        $titleSelect = $internshipTitleColumn
            ? "`$internshipTitleColumn` AS title"
            : "'Untitled internship' AS title";

        $recentSql = "SELECT `$internshipIdColumn` AS id, $titleSelect"
            . " FROM internships WHERE `$internshipCompanyColumn` = :company_id"
            . $orderBy . ' LIMIT 5';

        $stmt = $pdo->prepare($recentSql);
        $stmt->execute(['company_id' => $companyId]);
        $recentInternships = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Resolve application joins only when the expected relationships exist.
    $applicationInternshipColumn = firstColumn(
        $applicationColumns,
        ['internship_id']
    );
    $applicationStudentColumn = firstColumn(
        $applicationColumns,
        ['student_id']
    );
    $applicationIdColumn = firstColumn($applicationColumns, ['id']);
    $applicationStatusColumn = firstColumn(
        $applicationColumns,
        ['status', 'application_status']
    );
    $applicationCreatedColumn = firstColumn(
        $applicationColumns,
        ['created_at', 'applied_at', 'application_date']
    );

    if (
        $companyId &&
        $internshipIdColumn &&
        $internshipCompanyColumn &&
        $applicationInternshipColumn
    ) {
        $join = " FROM applications a
                  INNER JOIN internships i
                  ON a.`$applicationInternshipColumn` = i.`$internshipIdColumn`
                  WHERE i.`$internshipCompanyColumn` = :company_id";

        $stmt = $pdo->prepare("SELECT COUNT(*)" . $join);
        $stmt->execute(['company_id' => $companyId]);
        $stats['applications'] = (int) $stmt->fetchColumn();

        if ($applicationStatusColumn) {
            $stmt = $pdo->prepare(
                "SELECT COUNT(*)" . $join .
                " AND LOWER(a.`$applicationStatusColumn`) = 'shortlisted'"
            );
            $stmt->execute(['company_id' => $companyId]);
            $stats['shortlisted'] = (int) $stmt->fetchColumn();
        }

        $studentNameColumn = firstColumn(
            $studentColumns,
            ['name', 'full_name', 'student_name']
        );
        $studentUserIdColumn = firstColumn($studentColumns, ['user_id']);
        $studentIdColumn = firstColumn($studentColumns, ['id']);

        $studentJoin = '';
        $studentNameSelect = "'Student applicant' AS student_name";

        if (
            $applicationStudentColumn &&
            $studentIdColumn &&
            $studentNameColumn
        ) {
            $studentJoin =
                " LEFT JOIN students s ON a.`$applicationStudentColumn` = s.`$studentIdColumn`";
            $studentNameSelect = "s.`$studentNameColumn` AS student_name";
        }

        $applicationStatusSelect = $applicationStatusColumn
            ? "a.`$applicationStatusColumn` AS status"
            : "'Applied' AS status";

        $recentApplicationDate = $applicationCreatedColumn
            ? "a.`$applicationCreatedColumn`"
            : ($applicationIdColumn ? "a.`$applicationIdColumn`" : 'i.`' . $internshipIdColumn . '`');

        $applicationTitleSelect = $internshipTitleColumn
            ? "i.`$internshipTitleColumn` AS internship_title"
            : "'Internship' AS internship_title";

        $applicationOrder = " ORDER BY $recentApplicationDate DESC";

        $recentApplicationSql =
            "SELECT " .
            ($applicationIdColumn ? "a.`$applicationIdColumn` AS id," : '') .
            "$studentNameSelect, $applicationTitleSelect, $applicationStatusSelect" .
            $join . $studentJoin . $applicationOrder . ' LIMIT 6';

        $stmt = $pdo->prepare($recentApplicationSql);
        $stmt->execute(['company_id' => $companyId]);
        $recentApplications = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (Throwable $e) {
    // Keep internal database details out of the dashboard.
    $dbWarning = 'Some dashboard statistics could not be loaded. Check your database schema and company account mapping.';
    error_log('InternPro company dashboard: ' . $e->getMessage());
}

$firstName = preg_split('/\s+/', trim((string) $companyName))[0] ?? 'Company';
$hour = (int) date('G');

$greeting = $hour < 12
    ? 'Good morning'
    : ($hour < 17 ? 'Good afternoon' : 'Good evening');

function statusClass(string $status): string
{
    $status = strtolower(trim($status));

    if (in_array($status, ['selected', 'shortlisted', 'interview'], true)) {
        return 'status-success';
    }

    if (in_array($status, ['rejected', 'closed', 'inactive'], true)) {
        return 'status-danger';
    }

    if (in_array($status, ['under review', 'reviewing', 'pending'], true)) {
        return 'status-review';
    }

    return 'status-applied';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#070b18">
    <title>Company Dashboard | InternPro</title>
    <link rel="icon" type="image/jpeg" href="../assets/logo.jpg">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #070b18;
            --panel: rgba(13, 22, 43, .82);
            --panel-strong: #101b33;
            --line: rgba(86, 164, 255, .18);
            --blue: #438bff;
            --cyan: #35e5ff;
            --text: #eef6ff;
            --muted: #8fa4c4;
            --green: #4df5bd;
            --red: #ff648b;
            --purple: #a98aff;
            --radius: 22px;
        }

        * { box-sizing: border-box; }

        html { scroll-behavior: smooth; }

        body {
            margin: 0;
            min-height: 100vh;
            overflow-x: hidden;
            color: var(--text);
            font-family: Inter, sans-serif;
            background:
                radial-gradient(ellipse at 8% 0%, rgba(36, 105, 232, .16), transparent 34%),
                radial-gradient(ellipse at 95% 45%, rgba(31, 212, 255, .08), transparent 32%),
                var(--bg);
        }

        body::before {
            content: "";
            position: fixed;
            inset: 0;
            pointer-events: none;
            z-index: -1;
            opacity: .19;
            background-image:
                linear-gradient(rgba(74, 143, 255, .11) 1px, transparent 1px),
                linear-gradient(90deg, rgba(74, 143, 255, .11) 1px, transparent 1px);
            background-size: 48px 48px;
            mask-image: linear-gradient(to bottom, black, transparent 85%);
        }

        a { color: inherit; text-decoration: none; }

        button, a { -webkit-tap-highlight-color: transparent; }

        button, input { font: inherit; }

        :focus-visible {
            outline: 2px solid var(--cyan);
            outline-offset: 4px;
        }

        .ambient {
            position: fixed;
            width: 300px;
            height: 300px;
            border-radius: 50%;
            filter: blur(90px);
            opacity: .13;
            pointer-events: none;
            z-index: -1;
            animation: ambientFloat 12s ease-in-out infinite alternate;
        }

        .ambient.one { top: 15%; left: -160px; background: #287bff; }
        .ambient.two {
            right: -170px;
            bottom: 4%;
            background: #00e5ff;
            animation-delay: -5s;
        }

        .corner {
            position: fixed;
            width: 44px;
            height: 44px;
            z-index: 20;
            pointer-events: none;
            opacity: .75;
        }

        .corner::before, .corner::after {
            content: "";
            position: absolute;
            background: var(--cyan);
            box-shadow: 0 0 12px rgba(53, 229, 255, .65);
        }

        .corner::before { width: 25px; height: 2px; }
        .corner::after { width: 2px; height: 25px; }
        .corner.tl { top: 12px; left: 12px; }
        .corner.tr { top: 12px; right: 12px; transform: rotate(90deg); }
        .corner.bl { bottom: 12px; left: 12px; transform: rotate(-90deg); }
        .corner.br { bottom: 12px; right: 12px; transform: rotate(180deg); }

        .topbar {
            position: sticky;
            top: 0;
            z-index: 15;
            border-bottom: 1px solid var(--line);
            background: rgba(7, 11, 24, .83);
            backdrop-filter: blur(20px);
        }

        .nav-inner {
            max-width: 1440px;
            min-height: 78px;
            margin: auto;
            padding: 12px 34px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 24px;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 12px;
            min-width: 170px;
        }

        .brand img {
            width: 45px;
            height: 45px;
            object-fit: cover;
            border-radius: 13px;
            border: 1px solid rgba(53, 229, 255, .4);
            box-shadow: 0 0 24px rgba(53, 229, 255, .13);
            transition: transform .35s, box-shadow .35s, border-color .35s;
        }

        .brand:hover img {
            transform: rotate(-5deg) scale(1.08);
            border-color: var(--cyan);
            box-shadow: 0 0 28px rgba(53, 229, 255, .35);
        }

        .brand-name {
            font: 700 22px 'Space Grotesk', sans-serif;
            letter-spacing: -.8px;
        }

        .brand-name span { color: var(--cyan); }

        .nav-links {
            display: flex;
            align-items: center;
            justify-content: center;
            flex-wrap: wrap;
            gap: 7px;
        }

        .nav-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 11px 13px;
            border: 1px solid transparent;
            border-radius: 12px;
            color: var(--muted);
            font-size: 13px;
            font-weight: 600;
            transition: color .25s, background .25s, border-color .25s, transform .25s, box-shadow .25s;
        }

        .nav-link .nav-icon {
            display: inline-block;
            transition: transform .3s, filter .3s;
        }

        .nav-link:hover, .nav-link.active {
            color: var(--cyan);
            border-color: rgba(53, 229, 255, .18);
            background: rgba(53, 229, 255, .07);
            box-shadow: 0 0 20px rgba(53, 229, 255, .06);
            transform: translateY(-2px);
        }

        .nav-link:hover .nav-icon {
            transform: scale(1.2) rotate(-8deg);
            filter: drop-shadow(0 0 5px var(--cyan));
        }

        .nav-user {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .avatar {
            width: 39px;
            height: 39px;
            display: grid;
            place-items: center;
            border: 1px solid rgba(53, 229, 255, .35);
            border-radius: 13px;
            color: var(--cyan);
            font-weight: 800;
            background: linear-gradient(135deg, rgba(67, 139, 255, .22), rgba(53, 229, 255, .08));
            transition: transform .3s, box-shadow .3s;
        }

        .nav-user:hover .avatar {
            transform: rotate(5deg) scale(1.08);
            box-shadow: 0 0 20px rgba(53, 229, 255, .2);
        }

        .user-caption { color: var(--muted); font-size: 11px; margin-top: 3px; }
        .user-name { max-width: 145px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 12px; font-weight: 700; }

        .page {
            width: min(1372px, calc(100% - 68px));
            margin: 0 auto;
            padding: 38px 0 60px;
        }

        .reveal {
            opacity: 0;
            transform: translateY(18px);
            animation: reveal .65s cubic-bezier(.2, .75, .25, 1) forwards;
        }

        .delay-1 { animation-delay: .08s; }
        .delay-2 { animation-delay: .16s; }
        .delay-3 { animation-delay: .24s; }
        .delay-4 { animation-delay: .32s; }

        .eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: var(--cyan);
            text-transform: uppercase;
            font-size: 10px;
            font-weight: 800;
            letter-spacing: 2px;
        }

        .pulse-dot {
            width: 7px;
            height: 7px;
            border-radius: 50%;
            background: var(--green);
            box-shadow: 0 0 12px var(--green);
            animation: pulse 1.8s ease-in-out infinite;
        }

        .hero {
            position: relative;
            isolation: isolate;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 28px;
            min-height: 235px;
            padding: 38px 40px;
            border: 1px solid rgba(75, 154, 255, .25);
            border-radius: 28px;
            background:
                radial-gradient(ellipse at 80% 30%, rgba(0, 208, 255, .13), transparent 38%),
                linear-gradient(120deg, rgba(16, 30, 59, .97), rgba(9, 17, 35, .94));
            box-shadow: 0 25px 80px rgba(0, 0, 0, .18), inset 0 1px rgba(255,255,255,.035);
        }

        .hero::before {
            content: "";
            position: absolute;
            inset: 0;
            z-index: -1;
            pointer-events: none;
            background: linear-gradient(110deg, transparent 30%, rgba(53, 229, 255, .07), transparent 68%);
            transform: translateX(-100%);
            animation: scan 8s ease-in-out infinite;
        }

        .hero::after {
            content: "";
            position: absolute;
            top: -95px;
            right: 12%;
            width: 240px;
            height: 240px;
            border: 1px solid rgba(53, 229, 255, .12);
            border-radius: 50%;
            box-shadow: 0 0 0 30px rgba(53,229,255,.025), 0 0 0 60px rgba(53,229,255,.02);
            pointer-events: none;
            animation: orbit 22s linear infinite;
        }

        .hero-content { position: relative; z-index: 1; }

        .hero h1 {
            margin: 15px 0 10px;
            font: 700 clamp(28px, 3.2vw, 43px)/1.15 'Space Grotesk', sans-serif;
            letter-spacing: -1.6px;
        }

        .hero h1 span {
            color: var(--cyan);
            text-shadow: 0 0 30px rgba(53, 229, 255, .22);
        }

        .hero p { margin: 0; max-width: 590px; color: var(--muted); font-size: 14px; line-height: 1.8; }

        .hero-actions { display: flex; gap: 12px; flex-wrap: wrap; margin-top: 24px; }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 9px;
            min-height: 45px;
            padding: 12px 17px;
            border: 1px solid transparent;
            border-radius: 12px;
            cursor: pointer;
            font-size: 12px;
            font-weight: 800;
            transition: transform .25s, box-shadow .25s, background .25s, border-color .25s, color .25s;
        }

        .btn .btn-icon { display: inline-block; transition: transform .3s; }

        .btn-primary {
            color: #04121e;
            background: linear-gradient(115deg, var(--cyan), #6ba6ff);
            box-shadow: 0 7px 24px rgba(53, 229, 255, .16);
        }

        .btn-secondary {
            color: var(--text);
            background: rgba(255,255,255,.035);
            border-color: var(--line);
        }

        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 30px rgba(53, 229, 255, .18);
        }

        .btn:hover .btn-icon { transform: rotate(-10deg) scale(1.2); }
        .btn-secondary:hover { color: var(--cyan); border-color: rgba(53,229,255,.5); background: rgba(53,229,255,.07); }

        .hero-visual {
            position: relative;
            z-index: 1;
            width: 170px;
            height: 170px;
            flex: 0 0 170px;
            display: grid;
            place-items: center;
            border: 1px solid rgba(53,229,255,.2);
            border-radius: 50%;
            background: radial-gradient(circle, rgba(53,229,255,.11), rgba(53,229,255,.02) 65%);
            box-shadow: 0 0 50px rgba(53,229,255,.06), inset 0 0 35px rgba(53,229,255,.06);
            animation: float 5s ease-in-out infinite;
        }

        .hero-visual::before, .hero-visual::after {
            content: "";
            position: absolute;
            inset: 13px;
            border: 1px dashed rgba(53,229,255,.35);
            border-radius: 50%;
            animation: orbit 18s linear infinite;
        }

        .hero-visual::after {
            inset: -9px;
            border-style: solid;
            border-color: rgba(67,139,255,.2);
            animation-direction: reverse;
            animation-duration: 24s;
        }

        .hero-symbol { font-size: 55px; filter: drop-shadow(0 0 17px rgba(53,229,255,.4)); transition: transform .35s; }
        .hero-visual:hover .hero-symbol { transform: scale(1.16) rotate(10deg); }

        .section-heading {
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            gap: 18px;
            margin: 35px 0 17px;
        }

        .section-heading h2 {
            margin: 8px 0 0;
            font: 700 21px 'Space Grotesk', sans-serif;
            letter-spacing: -.5px;
        }

        .section-heading p { margin: 7px 0 0; color: var(--muted); font-size: 12px; }

        .text-link {
            color: var(--cyan);
            font-size: 12px;
            font-weight: 700;
            transition: color .2s, transform .2s;
        }

        .text-link:hover { color: #fff; transform: translateX(3px); }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 17px;
        }

        .stat-card {
            position: relative;
            overflow: hidden;
            min-height: 158px;
            padding: 22px;
            border: 1px solid var(--line);
            border-radius: var(--radius);
            background: linear-gradient(145deg, rgba(17, 30, 55, .91), rgba(10, 18, 35, .9));
            box-shadow: inset 0 1px rgba(255,255,255,.025);
            transition: transform .3s, border-color .3s, box-shadow .3s, background .3s;
        }

        .stat-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 15%;
            width: 70%;
            height: 1px;
            background: linear-gradient(90deg, transparent, var(--cyan), transparent);
            opacity: .5;
            transition: opacity .3s, width .3s;
        }

        .stat-card::after {
            content: "";
            position: absolute;
            right: -40px;
            bottom: -60px;
            width: 130px;
            height: 130px;
            border-radius: 50%;
            background: var(--glow, rgba(53,229,255,.12));
            filter: blur(42px);
            transition: transform .4s, opacity .4s;
            opacity: .65;
        }

        .stat-card:hover {
            transform: translateY(-7px);
            border-color: rgba(53,229,255,.45);
            box-shadow: 0 20px 42px rgba(0,0,0,.18), 0 0 25px rgba(53,229,255,.06);
        }

        .stat-card:hover::before { opacity: 1; width: 90%; }
        .stat-card:hover::after { transform: scale(1.5); opacity: 1; }

        .stat-top { display: flex; align-items: center; justify-content: space-between; gap: 10px; }

        .stat-icon {
            width: 43px;
            height: 43px;
            display: grid;
            place-items: center;
            border: 1px solid rgba(53,229,255,.18);
            border-radius: 14px;
            color: var(--accent, var(--cyan));
            background: var(--icon-bg, rgba(53,229,255,.08));
            font-size: 20px;
            transition: transform .35s, box-shadow .35s, background .35s;
        }

        .stat-card:hover .stat-icon {
            transform: rotate(-8deg) scale(1.12);
            box-shadow: 0 0 22px var(--glow, rgba(53,229,255,.14));
            background: rgba(53,229,255,.13);
        }

        .stat-trend { color: var(--muted); font-size: 10px; }
        .stat-number { position: relative; z-index: 1; margin-top: 19px; font: 700 30px 'Space Grotesk', sans-serif; }
        .stat-label { position: relative; z-index: 1; margin-top: 5px; color: var(--muted); font-size: 12px; }

        .main-grid {
            display: grid;
            grid-template-columns: minmax(0, 1.55fr) minmax(280px, .85fr);
            gap: 18px;
            margin-top: 22px;
        }

        .panel {
            min-width: 0;
            overflow: hidden;
            border: 1px solid var(--line);
            border-radius: var(--radius);
            background: linear-gradient(150deg, rgba(15, 26, 48, .9), rgba(9, 16, 31, .9));
            box-shadow: 0 14px 40px rgba(0,0,0,.09);
            transition: border-color .3s, box-shadow .3s;
        }

        .panel:hover { border-color: rgba(53,229,255,.32); box-shadow: 0 18px 48px rgba(0,0,0,.15); }

        .panel-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding: 22px 23px;
            border-bottom: 1px solid rgba(86,164,255,.12);
        }

        .panel-header h3 { margin: 0; font: 700 16px 'Space Grotesk', sans-serif; }
        .panel-header p { margin: 5px 0 0; color: var(--muted); font-size: 11px; }
        .panel-header-icon { color: var(--cyan); display: inline-block; transition: transform .3s, filter .3s; }
        .panel:hover .panel-header-icon { transform: rotate(10deg) scale(1.12); filter: drop-shadow(0 0 6px var(--cyan)); }

        .table-wrap { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; text-align: left; }
        th { padding: 14px 20px; color: #6f87a9; background: rgba(255,255,255,.012); font-size: 9px; letter-spacing: 1px; text-transform: uppercase; white-space: nowrap; }
        td { padding: 16px 20px; border-top: 1px solid rgba(86,164,255,.09); font-size: 11px; color: #c8d7eb; vertical-align: middle; }
        tbody tr { transition: background .2s; }
        tbody tr:hover { background: rgba(53,229,255,.035); }
        .primary-cell { color: var(--text); font-weight: 700; }
        .secondary-cell { display: block; color: var(--muted); font-size: 10px; margin-top: 5px; }

        .status {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 9px;
            border: 1px solid transparent;
            border-radius: 8px;
            font-size: 9px;
            font-weight: 800;
            white-space: nowrap;
        }

        .status::before { content: ""; width: 5px; height: 5px; border-radius: 50%; background: currentColor; }
        .status-success { color: var(--green); background: rgba(77,245,189,.07); border-color: rgba(77,245,189,.14); }
        .status-danger { color: var(--red); background: rgba(255,100,139,.07); border-color: rgba(255,100,139,.14); }
        .status-review { color: #86aaff; background: rgba(67,139,255,.09); border-color: rgba(67,139,255,.17); }
        .status-applied { color: var(--cyan); background: rgba(53,229,255,.06); border-color: rgba(53,229,255,.15); }

        .empty {
            padding: 34px 22px;
            text-align: center;
            color: var(--muted);
        }

        .empty-icon {
            display: inline-grid;
            place-items: center;
            width: 48px;
            height: 48px;
            margin-bottom: 12px;
            border: 1px solid var(--line);
            border-radius: 16px;
            background: rgba(53,229,255,.05);
            font-size: 21px;
            transition: transform .3s, box-shadow .3s;
        }

        .empty:hover .empty-icon { transform: translateY(-4px) rotate(7deg); box-shadow: 0 0 25px rgba(53,229,255,.13); }
        .empty strong { display: block; color: #d9e8fa; font-size: 12px; }
        .empty p { margin: 7px 0 0; font-size: 11px; line-height: 1.7; }

        .internship-list { padding: 5px 20px 14px; }

        .internship-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 15px 3px;
            border-bottom: 1px solid rgba(86,164,255,.09);
            transition: transform .25s, padding .25s;
        }

        .internship-item:last-child { border-bottom: 0; }
        .internship-item:hover { transform: translateX(4px); padding-left: 7px; }

        .internship-symbol {
            flex: 0 0 40px;
            height: 40px;
            display: grid;
            place-items: center;
            border: 1px solid rgba(53,229,255,.17);
            border-radius: 12px;
            background: rgba(53,229,255,.055);
            color: var(--cyan);
            transition: transform .3s, box-shadow .3s;
        }

        .internship-item:hover .internship-symbol { transform: rotate(-7deg) scale(1.08); box-shadow: 0 0 18px rgba(53,229,255,.12); }
        .internship-title { overflow-wrap: anywhere; color: var(--text); font-size: 11px; font-weight: 700; }
        .internship-subtitle { margin-top: 5px; color: var(--muted); font-size: 10px; }

        .quick-actions {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 14px;
            margin-top: 22px;
        }

        .quick-card {
            display: flex;
            align-items: center;
            gap: 15px;
            min-width: 0;
            padding: 19px;
            border: 1px solid var(--line);
            border-radius: 18px;
            background: rgba(13,22,43,.7);
            transition: transform .3s, border-color .3s, box-shadow .3s;
        }

        .quick-card:hover { transform: translateY(-5px); border-color: rgba(53,229,255,.4); box-shadow: 0 15px 35px rgba(0,0,0,.15), 0 0 20px rgba(53,229,255,.05); }

        .quick-icon {
            flex: 0 0 43px;
            height: 43px;
            display: grid;
            place-items: center;
            border-radius: 13px;
            border: 1px solid rgba(53,229,255,.16);
            color: var(--cyan);
            background: rgba(53,229,255,.06);
            font-size: 19px;
            transition: transform .3s, filter .3s;
        }

        .quick-card:hover .quick-icon { transform: rotate(9deg) scale(1.12); filter: drop-shadow(0 0 8px rgba(53,229,255,.35)); }
        .quick-title { font-size: 12px; font-weight: 800; }
        .quick-description { margin-top: 5px; color: var(--muted); font-size: 10px; line-height: 1.6; }

        .warning {
            margin-top: 16px;
            padding: 13px 16px;
            border: 1px solid rgba(255,100,139,.25);
            border-radius: 12px;
            background: rgba(255,100,139,.06);
            color: #ffb4c8;
            font-size: 12px;
        }

        footer {
            display: flex;
            justify-content: space-between;
            gap: 16px;
            margin-top: 34px;
            padding-top: 20px;
            border-top: 1px solid rgba(86,164,255,.12);
            color: #667c9d;
            font-size: 10px;
        }

        footer span { transition: color .25s; }
        footer span:hover { color: var(--cyan); }

        @keyframes reveal { to { opacity: 1; transform: translateY(0); } }
        @keyframes pulse { 0%,100% { opacity: 1; transform: scale(1); } 50% { opacity: .55; transform: scale(.75); } }
        @keyframes float { 0%,100% { transform: translateY(0); } 50% { transform: translateY(-9px); } }
        @keyframes ambientFloat { from { transform: translate(0,0) scale(1); } to { transform: translate(45px,-35px) scale(1.12); } }
        @keyframes orbit { to { transform: rotate(360deg); } }
        @keyframes scan { 0%,35% { transform: translateX(-100%); } 75%,100% { transform: translateX(100%); } }

        @media (max-width: 1100px) {
            .nav-inner { padding: 12px 24px; flex-wrap: wrap; }
            .brand { min-width: auto; }
            .nav-links { order: 3; width: 100%; justify-content: flex-start; overflow-x: auto; padding-bottom: 3px; }
            .stats-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
            .page { width: calc(100% - 48px); }
        }

        @media (max-width: 780px) {
            .page { width: calc(100% - 32px); padding-top: 25px; }
            .hero { padding: 28px 24px; }
            .hero-visual { width: 115px; height: 115px; flex-basis: 115px; }
            .hero-symbol { font-size: 40px; }
            .main-grid { grid-template-columns: 1fr; }
            .quick-actions { grid-template-columns: 1fr; }
            .section-heading { margin-top: 27px; }
        }

        @media (max-width: 520px) {
            .nav-inner { padding: 12px 18px; gap: 12px; }
            .brand img { width: 38px; height: 38px; }
            .brand-name { font-size: 19px; }
            .nav-user .user-details { display: none; }
            .nav-link { padding: 10px 11px; font-size: 11px; }
            .hero { min-height: auto; padding: 25px 20px; }
            .hero-visual { display: none; }
            .hero h1 { font-size: 31px; }
            .hero p { font-size: 12px; }
            .stats-grid { gap: 11px; }
            .stat-card { padding: 16px; min-height: 143px; }
            .stat-icon { width: 37px; height: 37px; font-size: 17px; }
            .stat-number { font-size: 26px; margin-top: 15px; }
            .stat-label { font-size: 11px; }
            .stat-trend { font-size: 9px; }
            .panel-header { padding: 18px; }
            th, td { padding: 13px 14px; }
            footer { flex-direction: column; }
            .corner { opacity: .4; }
        }

        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                scroll-behavior: auto !important;
                animation-duration: .01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: .01ms !important;
            }

            .reveal { opacity: 1; transform: none; }
        }
    </style>
</head>
<body>
    <div class="ambient one" aria-hidden="true"></div>
    <div class="ambient two" aria-hidden="true"></div>
    <div class="corner tl" aria-hidden="true"></div>
    <div class="corner tr" aria-hidden="true"></div>
    <div class="corner bl" aria-hidden="true"></div>
    <div class="corner br" aria-hidden="true"></div>

    <header class="topbar">
        <div class="nav-inner">
            <a class="brand" href="dashboard.php" aria-label="InternPro company dashboard">
                <img src="../assets/logo.jpg" alt="InternPro logo">
                <span class="brand-name">Intern<span>Pro</span></span>
            </a>

            <nav class="nav-links" aria-label="Company navigation">
                <a class="nav-link active" href="dashboard.php" aria-current="page">
                    <span class="nav-icon">⌂</span> Dashboard
                </a>
                <a class="nav-link" href="internships.php">
                    <span class="nav-icon">▤</span> My Internships
                </a>
                <a class="nav-link" href="add_internship.php">
                    <span class="nav-icon">＋</span> Post Internship
                </a>
                <a class="nav-link" href="applicants.php">
                    <span class="nav-icon">♙</span> Applicants
                </a>
            </nav>

            <div class="nav-user">
                <div class="avatar" aria-hidden="true">
                    <?= h(strtoupper(substr((string) $firstName, 0, 1))) ?>
                </div>
                <div class="user-details">
                    <div class="user-name"><?= h($companyName) ?></div>
                    <div class="user-caption">Company workspace</div>
                </div>
            </div>
        </div>
    </header>

    <main class="page">
        <section class="hero reveal">
            <div class="hero-content">
                <div class="eyebrow"><span class="pulse-dot"></span> COMPANY CONTROL CENTER</div>
                <h1><?= h($greeting) ?>,<br><span><?= h($firstName) ?>.</span></h1>
                <p>
                    Your next great intern is out there. Manage opportunities,
                    discover promising candidates, and build your future team
                    from one workspace.
                </p>
                <div class="hero-actions">
                    <a class="btn btn-primary" href="add_internship.php">
                        <span class="btn-icon">＋</span> Post an internship
                    </a>
                    <a class="btn btn-secondary" href="applicants.php">
                        <span class="btn-icon">↗</span> Explore applicants
                    </a>
                </div>
            </div>

            <div class="hero-visual" aria-label="Career growth symbol">
                <span class="hero-symbol" aria-hidden="true">⌘</span>
            </div>
        </section>

        <?php if ($dbWarning !== ''): ?>
            <div class="warning" role="status"><?= h($dbWarning) ?></div>
        <?php endif; ?>

        <section class="reveal delay-1" aria-labelledby="stats-title">
            <div class="section-heading">
                <div>
                    <div class="eyebrow">◈ LIVE OVERVIEW</div>
                    <h2 id="stats-title">Your workspace at a glance</h2>
                    <p>Track your hiring activity and internship performance.</p>
                </div>
            </div>

            <div class="stats-grid">
                <article class="stat-card" style="--accent:#35e5ff;--glow:rgba(53,229,255,.16)">
                    <div class="stat-top">
                        <div class="stat-icon" aria-hidden="true">▤</div>
                        <span class="stat-trend">ALL POSTS</span>
                    </div>
                    <div class="stat-number"><?= number_format($stats['internships']) ?></div>
                    <div class="stat-label">Total internships</div>
                </article>

                <article class="stat-card" style="--accent:#4df5bd;--glow:rgba(77,245,189,.15);--icon-bg:rgba(77,245,189,.07)">
                    <div class="stat-top">
                        <div class="stat-icon" aria-hidden="true">◉</div>
                        <span class="stat-trend">OPEN ROLES</span>
                    </div>
                    <div class="stat-number"><?= number_format($stats['active']) ?></div>
                    <div class="stat-label">Active internships</div>
                </article>

                <article class="stat-card" style="--accent:#a98aff;--glow:rgba(169,138,255,.16);--icon-bg:rgba(169,138,255,.07)">
                    <div class="stat-top">
                        <div class="stat-icon" aria-hidden="true">♙</div>
                        <span class="stat-trend">CANDIDATES</span>
                    </div>
                    <div class="stat-number"><?= number_format($stats['applications']) ?></div>
                    <div class="stat-label">Total applications</div>
                </article>

                <article class="stat-card" style="--accent:#ff8fba;--glow:rgba(255,143,186,.15);--icon-bg:rgba(255,143,186,.07)">
                    <div class="stat-top">
                        <div class="stat-icon" aria-hidden="true">✧</div>
                        <span class="stat-trend">TOP PICKS</span>
                    </div>
                    <div class="stat-number"><?= number_format($stats['shortlisted']) ?></div>
                    <div class="stat-label">Shortlisted candidates</div>
                </article>
            </div>
        </section>

        <div class="main-grid reveal delay-2">
            <section class="panel" aria-labelledby="applications-title">
                <div class="panel-header">
                    <div>
                        <h3 id="applications-title">Recent applications</h3>
                        <p>Keep an eye on your incoming talent.</p>
                    </div>
                    <a class="text-link" href="applicants.php">View all ↗</a>
                </div>

                <?php if ($recentApplications): ?>
                    <div class="table-wrap">
                        <table>
                            <thead>
                                <tr>
                                    <th>Candidate</th>
                                    <th>Internship</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentApplications as $application): ?>
                                    <?php
                                    $status = (string) ($application['status'] ?? 'Applied');
                                    ?>
                                    <tr>
                                        <td>
                                            <span class="primary-cell"><?= h($application['student_name'] ?? 'Student applicant') ?></span>
                                        </td>
                                        <td><?= h($application['internship_title'] ?? 'Internship') ?></td>
                                        <td>
                                            <span class="status <?= h(statusClass($status)) ?>">
                                                <?= h(ucwords(str_replace('_', ' ', $status))) ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="empty">
                        <span class="empty-icon" aria-hidden="true">⌕</span>
                        <strong>No applications to display yet</strong>
                        <p>Once students apply to your internships, their applications will appear here.</p>
                    </div>
                <?php endif; ?>
            </section>

            <section class="panel" aria-labelledby="internships-title">
                <div class="panel-header">
                    <div>
                        <h3 id="internships-title">Recent internships</h3>
                        <p>Your latest posted opportunities.</p>
                    </div>
                    <a class="text-link" href="internships.php">Manage ↗</a>
                </div>

                <?php if ($recentInternships): ?>
                    <div class="internship-list">
                        <?php foreach ($recentInternships as $internship): ?>
                            <a class="internship-item" href="internships.php">
                                <span class="internship-symbol" aria-hidden="true">⌘</span>
                                <span>
                                    <span class="internship-title"><?= h($internship['title'] ?? 'Untitled internship') ?></span>
                                    <span class="internship-subtitle">Internship ID #<?= (int) ($internship['id'] ?? 0) ?></span>
                                </span>
                                <span style="margin-left:auto;color:var(--cyan)" aria-hidden="true">↗</span>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="empty">
                        <span class="empty-icon" aria-hidden="true">＋</span>
                        <strong>Your first opportunity starts here</strong>
                        <p>Post an internship to connect with talented students.</p>
                        <div style="margin-top:16px">
                            <a class="btn btn-primary" href="add_internship.php">
                                <span class="btn-icon">＋</span> Create internship
                            </a>
                        </div>
                    </div>
                <?php endif; ?>
            </section>
        </div>

        <section class="reveal delay-3" aria-labelledby="quick-title">
            <div class="section-heading">
                <div>
                    <div class="eyebrow">◈ QUICK COMMANDS</div>
                    <h2 id="quick-title">Ready for your next move?</h2>
                    <p>Jump straight into the tools you need.</p>
                </div>
            </div>

            <div class="quick-actions">
                <a class="quick-card" href="add_internship.php">
                    <span class="quick-icon" aria-hidden="true">＋</span>
                    <span>
                        <span class="quick-title">Create an opening</span>
                        <span class="quick-description">Publish a new internship opportunity.</span>
                    </span>
                </a>

                <a class="quick-card" href="internships.php">
                    <span class="quick-icon" aria-hidden="true">▤</span>
                    <span>
                        <span class="quick-title">Manage internships</span>
                        <span class="quick-description">Review and manage your posted roles.</span>
                    </span>
                </a>

                <a class="quick-card" href="applicants.php">
                    <span class="quick-icon" aria-hidden="true">♙</span>
                    <span>
                        <span class="quick-title">Review candidates</span>
                        <span class="quick-description">Explore applications and hiring progress.</span>
                    </span>
                </a>
            </div>
        </section>

        <footer class="reveal delay-4">
            <span>© <?= date('Y') ?> InternPro · Company workspace</span>
            <span>Built for talent. Designed for the future. <span style="color:var(--cyan)">◆</span></span>
        </footer>
    </main>
</body>
</html>