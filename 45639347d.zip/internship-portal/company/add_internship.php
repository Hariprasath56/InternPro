<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (
    !isset($_SESSION['user_id'], $_SESSION['role']) ||
    !in_array(strtolower((string) $_SESSION['role']), ['company', 'recruiter'], true)
) {
    header('Location: ../login.php');
    exit;
}

require_once __DIR__ . '/../config/database.php';

if (!isset($pdo) || !($pdo instanceof PDO)) {
    http_response_code(500);
    exit('Database connection is not configured correctly.');
}

$userId = (int) $_SESSION['user_id'];
$companyId = null;
$companyName = $_SESSION['company_name'] ?? $_SESSION['name'] ?? 'Company';
$errors = [];

$old = [
    'title' => '',
    'description' => '',
    'location' => '',
    'type' => 'Full-time',
    'stipend' => '',
    'duration' => '',
    'deadline' => ''
];

if (empty($_SESSION['internpro_csrf'])) {
    $_SESSION['internpro_csrf'] = bin2hex(random_bytes(32));
}

function h($value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function tableColumns(PDO $pdo, string $table): array
{
    $allowed = ['companies', 'internships'];

    if (!in_array($table, $allowed, true)) {
        return [];
    }

    $stmt = $pdo->query("SHOW COLUMNS FROM `$table`");

    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function findColumnName(array $columns, array $candidates): ?string
{
    $names = array_column($columns, 'Field');

    foreach ($candidates as $candidate) {
        if (in_array($candidate, $names, true)) {
            return $candidate;
        }
    }

    return null;
}

function hasColumn(array $columns, string $name): bool
{
    return in_array($name, array_column($columns, 'Field'), true);
}

function isBlank($value): bool
{
    return trim((string) $value) === '';
}

try {
    $companyColumns = tableColumns($pdo, 'companies');

    if (
        hasColumn($companyColumns, 'id') &&
        hasColumn($companyColumns, 'user_id')
    ) {
        $stmt = $pdo->prepare(
            'SELECT * FROM companies WHERE user_id = :user_id LIMIT 1'
        );

        $stmt->execute(['user_id' => $userId]);
        $company = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($company) {
            $companyId = (int) $company['id'];

            foreach (['company_name', 'name', 'organization_name'] as $nameColumn) {
                if (!empty($company[$nameColumn])) {
                    $companyName = $company[$nameColumn];
                    break;
                }
            }
        }
    }
} catch (Throwable $e) {
    error_log('InternPro add internship company lookup: ' . $e->getMessage());
    $errors[] = 'Unable to verify your company profile. Please check your database configuration.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($old as $key => $value) {
        if (isset($_POST[$key]) && is_string($_POST[$key])) {
            $old[$key] = trim($_POST[$key]);
        }
    }

    $csrfToken = $_POST['csrf_token'] ?? '';

    if (
        !is_string($csrfToken) ||
        !hash_equals($_SESSION['internpro_csrf'], $csrfToken)
    ) {
        $errors[] = 'Your session token has expired. Refresh the page and try again.';
    }

    if (isBlank($old['title'])) {
        $errors[] = 'Please enter an internship title.';
    } elseif (mb_strlen($old['title']) > 200) {
        $errors[] = 'The internship title must be 200 characters or fewer.';
    }

    if (isBlank($old['description'])) {
        $errors[] = 'Please enter an internship description.';
    } elseif (mb_strlen($old['description']) > 20000) {
        $errors[] = 'The description is too long. Please keep it within 20,000 characters.';
    }

    if (mb_strlen($old['location']) > 150) {
        $errors[] = 'The location must be 150 characters or fewer.';
    }

    $allowedTypes = [
        'Full-time',
        'Part-time',
        'Remote',
        'Hybrid',
        'On-site'
    ];

    if (!in_array($old['type'], $allowedTypes, true)) {
        $errors[] = 'Please select a valid internship type.';
    }

    if (mb_strlen($old['stipend']) > 100) {
        $errors[] = 'The stipend must be 100 characters or fewer.';
    }

    if (mb_strlen($old['duration']) > 100) {
        $errors[] = 'The duration must be 100 characters or fewer.';
    }

    if ($old['deadline'] !== '') {
        $date = DateTimeImmutable::createFromFormat('!Y-m-d', $old['deadline']);
        $dateErrors = DateTimeImmutable::getLastErrors();

        if (
            !$date ||
            (
                $dateErrors !== false &&
                (
                    $dateErrors['warning_count'] > 0 ||
                    $dateErrors['error_count'] > 0
                )
            ) ||
            $date->format('Y-m-d') !== $old['deadline']
        ) {
            $errors[] = 'Please enter a valid application deadline.';
        } elseif ($date < new DateTimeImmutable('today')) {
            $errors[] = 'The application deadline cannot be in the past.';
        }
    }

    if (!$companyId) {
        $errors[] = 'Your account does not have a linked company profile. Please resolve this before posting an internship.';
    }

    if (!$errors) {
        try {
            $internshipColumns = tableColumns($pdo, 'internships');

            if (!$internshipColumns) {
                throw new RuntimeException(
                    'Unable to retrieve the internships table structure.'
                );
            }

            $titleColumn = findColumnName(
                $internshipColumns,
                ['title', 'internship_title', 'position']
            );

            $companyColumn = findColumnName(
                $internshipColumns,
                ['company_id', 'employer_id']
            );

            if (!$titleColumn || !$companyColumn) {
                throw new RuntimeException(
                    'The internships table needs a title column and a company relationship column.'
                );
            }

            $descriptionColumn = findColumnName(
                $internshipColumns,
                ['description', 'details', 'job_description']
            );

            $locationColumn = findColumnName(
                $internshipColumns,
                ['location', 'work_location', 'city']
            );

            $typeColumn = findColumnName(
                $internshipColumns,
                ['type', 'internship_type', 'job_type']
            );

            $stipendColumn = findColumnName(
                $internshipColumns,
                ['stipend', 'salary', 'salary_range']
            );

            $durationColumn = findColumnName(
                $internshipColumns,
                ['duration', 'duration_months']
            );

            $deadlineColumn = findColumnName(
                $internshipColumns,
                ['deadline', 'application_deadline', 'last_date']
            );

            $statusColumn = findColumnName(
                $internshipColumns,
                ['status', 'application_status']
            );

            $createdColumn = findColumnName(
                $internshipColumns,
                ['created_at', 'posted_at', 'date_posted']
            );

            $values = [
                $companyColumn => $companyId,
                $titleColumn => $old['title']
            ];

            if ($descriptionColumn) {
                $values[$descriptionColumn] = $old['description'];
            }

            if ($locationColumn) {
                $values[$locationColumn] = $old['location'] !== ''
                    ? $old['location']
                    : null;
            }

            if ($typeColumn) {
                $values[$typeColumn] = $old['type'];
            }

            if ($stipendColumn) {
                $values[$stipendColumn] = $old['stipend'] !== ''
                    ? $old['stipend']
                    : null;
            }

            if ($durationColumn) {
                $values[$durationColumn] = $old['duration'] !== ''
                    ? $old['duration']
                    : null;
            }

            if ($deadlineColumn) {
                $values[$deadlineColumn] = $old['deadline'] !== ''
                    ? $old['deadline']
                    : null;
            }

            if ($statusColumn) {
                $values[$statusColumn] = 'published';
            }

            if ($createdColumn) {
                $values[$createdColumn] = date('Y-m-d H:i:s');
            }

            foreach ($internshipColumns as $columnInfo) {
                $columnName = $columnInfo['Field'];
                $columnDefault = $columnInfo['Default'] ?? null;
                $extra = strtolower((string) ($columnInfo['Extra'] ?? ''));
                $nullable = strtoupper((string) ($columnInfo['Null'] ?? 'NO')) === 'YES';

                if (
                    array_key_exists($columnName, $values) ||
                    $columnDefault !== null ||
                    str_contains($extra, 'auto_increment') ||
                    $nullable ||
                    str_contains($extra, 'generated')
                ) {
                    continue;
                }

                throw new RuntimeException(
                    'The internships table has another required field (' .
                    $columnName .
                    ') that this form does not yet provide.'
                );
            }

            $insertColumns = array_keys($values);

            $quotedColumns = array_map(
                static fn($column) => '`' . str_replace('`', '``', $column) . '`',
                $insertColumns
            );

            $placeholders = [];
            $params = [];

            foreach ($insertColumns as $index => $column) {
                $placeholder = ':field_' . $index;
                $placeholders[] = $placeholder;
                $params[$placeholder] = $values[$column];
            }

            $sql = 'INSERT INTO internships (' .
                implode(', ', $quotedColumns) .
                ') VALUES (' .
                implode(', ', $placeholders) .
                ')';

            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);

            $_SESSION['internpro_csrf'] = bin2hex(random_bytes(32));
            $_SESSION['internpro_internship_flash'] =
                'Your internship has been published successfully.';

            header('Location: internships.php?created=1');
            exit;
        } catch (Throwable $e) {
            error_log('InternPro add internship insert: ' . $e->getMessage());

            $errors[] = $e instanceof RuntimeException
                ? $e->getMessage()
                : 'The internship could not be saved. Please verify the internships table fields and try again.';
        }
    }
}

$firstNameParts = preg_split('/\s+/', trim((string) $companyName));
$firstName = $firstNameParts[0] ?? 'Company';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#070b18">
    <title>Post Internship | InternPro</title>
    <link rel="icon" type="image/jpeg" href="../assets/logo.jpg">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #070b18;
            --panel: rgba(13,22,43,.86);
            --line: rgba(86,164,255,.18);
            --blue: #438bff;
            --cyan: #35e5ff;
            --text: #eef6ff;
            --muted: #8fa4c4;
            --green: #4df5bd;
            --red: #ff648b;
        }

        * { box-sizing: border-box; }
        html { scroll-behavior: smooth; }

        body {
            margin: 0;
            min-height: 100vh;
            overflow-x: hidden;
            color: var(--text);
            font-family: Inter, sans-serif;
            background:
                radial-gradient(ellipse at 8% 0%, rgba(36,105,232,.16), transparent 34%),
                radial-gradient(ellipse at 95% 45%, rgba(31,212,255,.08), transparent 32%),
                var(--bg);
        }

        body::before {
            content: "";
            position: fixed;
            inset: 0;
            z-index: -1;
            pointer-events: none;
            opacity: .18;
            background-image:
                linear-gradient(rgba(74,143,255,.11) 1px, transparent 1px),
                linear-gradient(90deg, rgba(74,143,255,.11) 1px, transparent 1px);
            background-size: 48px 48px;
            mask-image: linear-gradient(to bottom, black, transparent 85%);
        }

        a { color: inherit; text-decoration: none; }
        input, textarea, select, button { font: inherit; }
        :focus-visible { outline: 2px solid var(--cyan); outline-offset: 4px; }

        .ambient {
            position: fixed;
            width: 300px;
            height: 300px;
            border-radius: 50%;
            filter: blur(90px);
            opacity: .13;
            pointer-events: none;
            z-index: -1;
            animation: ambientFloat 12s ease-in-out infinite alternate;
        }

        .ambient.one { top: 15%; left: -160px; background: #287bff; }
        .ambient.two { right: -170px; bottom: 4%; background: #00e5ff; animation-delay: -5s; }

        .corner {
            position: fixed;
            width: 28px;
            height: 28px;
            z-index: 20;
            pointer-events: none;
            opacity: .65;
        }

        .corner::before, .corner::after {
            content: "";
            position: absolute;
            background: var(--cyan);
            box-shadow: 0 0 12px rgba(53,229,255,.65);
        }

        .corner::before { width: 25px; height: 2px; }
        .corner::after { width: 2px; height: 25px; }
        .corner.tl { top: 12px; left: 12px; }
        .corner.tr { top: 12px; right: 12px; transform: rotate(90deg); }
        .corner.bl { bottom: 12px; left: 12px; transform: rotate(-90deg); }
        .corner.br { bottom: 12px; right: 12px; transform: rotate(180deg); }

        .topbar {
            position: sticky;
            top: 0;
            z-index: 15;
            border-bottom: 1px solid var(--line);
            background: rgba(7,11,24,.86);
            backdrop-filter: blur(20px);
        }

        .nav-inner {
            max-width: 1440px;
            min-height: 78px;
            margin: auto;
            padding: 12px 34px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 24px;
        }

        .brand { display: flex; align-items: center; gap: 12px; min-width: 170px; }

        .brand img {
            width: 45px;
            height: 45px;
            object-fit: cover;
            border-radius: 13px;
            border: 1px solid rgba(53,229,255,.4);
            box-shadow: 0 0 24px rgba(53,229,255,.13);
            transition: transform .35s, box-shadow .35s;
        }

        .brand:hover img { transform: rotate(-5deg) scale(1.08); box-shadow: 0 0 28px rgba(53,229,255,.35); }
        .brand-name { font: 700 22px 'Space Grotesk',sans-serif; letter-spacing: -.8px; }
        .brand-name span { color: var(--cyan); }

        .nav-links { display: flex; align-items: center; justify-content: center; flex-wrap: wrap; gap: 7px; }

        .nav-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 11px 13px;
            border: 1px solid transparent;
            border-radius: 12px;
            color: var(--muted);
            font-size: 13px;
            font-weight: 600;
            transition: color .25s, background .25s, border-color .25s, transform .25s;
        }

        .nav-icon { display: inline-block; transition: transform .3s, filter .3s; }

        .nav-link:hover, .nav-link.active {
            color: var(--cyan);
            border-color: rgba(53,229,255,.18);
            background: rgba(53,229,255,.07);
            transform: translateY(-2px);
        }

        .nav-link:hover .nav-icon { transform: scale(1.2) rotate(-8deg); filter: drop-shadow(0 0 5px var(--cyan)); }

        .nav-user { display: flex; align-items: center; gap: 10px; }
        .avatar {
            width: 39px;
            height: 39px;
            display: grid;
            place-items: center;
            border: 1px solid rgba(53,229,255,.35);
            border-radius: 13px;
            color: var(--cyan);
            font-weight: 800;
            background: linear-gradient(135deg, rgba(67,139,255,.22), rgba(53,229,255,.08));
            transition: transform .3s, box-shadow .3s;
        }

        .nav-user:hover .avatar { transform: rotate(5deg) scale(1.08); box-shadow: 0 0 20px rgba(53,229,255,.2); }
        .user-name { max-width: 145px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 12px; font-weight: 700; }
        .user-caption { margin-top: 3px; color: var(--muted); font-size: 11px; }

        .page { width: min(1200px, calc(100% - 68px)); margin: 0 auto; padding: 38px 0 60px; }

        .reveal { opacity: 0; transform: translateY(18px); animation: reveal .65s cubic-bezier(.2,.75,.25,1) forwards; }
        .delay-1 { animation-delay: .08s; }
        .delay-2 { animation-delay: .16s; }

        .eyebrow { display: inline-flex; align-items: center; gap: 8px; color: var(--cyan); text-transform: uppercase; font-size: 10px; font-weight: 800; letter-spacing: 2px; }
        .pulse-dot { width: 7px; height: 7px; border-radius: 50%; background: var(--green); box-shadow: 0 0 12px var(--green); animation: pulse 1.8s ease-in-out infinite; }

        .heading {
            display: flex;
            align-items: flex-end;
            justify-content: space-between;
            gap: 20px;
            margin-bottom: 26px;
        }

        .heading h1 { margin: 13px 0 9px; font: 700 clamp(28px,3vw,40px)/1.15 'Space Grotesk',sans-serif; letter-spacing: -1.4px; }
        .heading h1 span { color: var(--cyan); text-shadow: 0 0 28px rgba(53,229,255,.18); }
        .heading p { max-width: 620px; margin: 0; color: var(--muted); font-size: 13px; line-height: 1.8; }

        .back-link { display: inline-flex; align-items: center; gap: 8px; color: var(--muted); font-size: 11px; font-weight: 700; transition: color .25s, transform .25s; }
        .back-link span { display: inline-block; transition: transform .25s; }
        .back-link:hover { color: var(--cyan); transform: translateX(-2px); }
        .back-link:hover span { transform: translateX(-3px); }

        .layout { display: grid; grid-template-columns: minmax(0,1.5fr) minmax(250px,.75fr); align-items: start; gap: 22px; }

        .form-panel, .side-panel {
            min-width: 0;
            overflow: hidden;
            border: 1px solid var(--line);
            border-radius: 23px;
            background: linear-gradient(150deg, rgba(15,26,48,.94), rgba(9,16,31,.94));
            box-shadow: 0 20px 55px rgba(0,0,0,.13);
            transition: border-color .3s, box-shadow .3s;
        }

        .form-panel:hover, .side-panel:hover { border-color: rgba(53,229,255,.3); box-shadow: 0 22px 60px rgba(0,0,0,.16); }

        .panel-header { padding: 24px 27px; border-bottom: 1px solid rgba(86,164,255,.12); }
        .panel-header h2 { margin: 0; font: 700 18px 'Space Grotesk',sans-serif; }
        .panel-header p { margin: 7px 0 0; color: var(--muted); font-size: 11px; line-height: 1.7; }

        .form-body { padding: 27px; }

        .form-section-title { display: flex; align-items: center; gap: 10px; margin: 0 0 19px; color: #dfeeff; font: 700 13px 'Space Grotesk',sans-serif; }
        .section-icon { display: inline-grid; place-items: center; width: 29px; height: 29px; border: 1px solid rgba(53,229,255,.19); border-radius: 9px; color: var(--cyan); background: rgba(53,229,255,.06); transition: transform .3s, box-shadow .3s; }
        .form-section-title:hover .section-icon { transform: rotate(-8deg) scale(1.08); box-shadow: 0 0 15px rgba(53,229,255,.12); }

        .form-grid { display: grid; grid-template-columns: repeat(2,minmax(0,1fr)); gap: 19px; }
        .field { display: flex; flex-direction: column; min-width: 0; gap: 8px; }
        .field.full { grid-column: 1 / -1; }
        .field label { color: #b7c9e2; font-size: 11px; font-weight: 700; }
        .required { color: var(--cyan); margin-left: 3px; }
        .field-hint { color: #7186a6; font-size: 10px; line-height: 1.6; }

        .input-wrap { position: relative; }

        .field-control {
            width: 100%;
            min-height: 46px;
            padding: 13px 14px;
            border: 1px solid rgba(86,164,255,.2);
            border-radius: 11px;
            color: var(--text);
            background: rgba(4,12,27,.62);
            font-size: 12px;
            outline: none;
            transition: border-color .25s, box-shadow .25s, background .25s;
        }

        .field-control::placeholder { color: #647b9d; }

        .field-control:hover { border-color: rgba(53,229,255,.32); }

        .field-control:focus {
            border-color: var(--cyan);
            background: rgba(4,15,32,.9);
            box-shadow: 0 0 0 3px rgba(53,229,255,.07), 0 0 22px rgba(53,229,255,.035);
        }

        textarea.field-control { min-height: 165px; resize: vertical; line-height: 1.8; }
        select.field-control { cursor: pointer; }
        select.field-control option { color: var(--text); background: #0b152a; }
        input[type="date"].field-control { color-scheme: dark; }

        .description-counter { display: flex; justify-content: space-between; gap: 10px; color: #7186a6; font-size: 10px; }

        .form-divider { height: 1px; margin: 26px 0; background: rgba(86,164,255,.12); }

        .error-list {
            margin-bottom: 21px;
            padding: 15px 18px;
            border: 1px solid rgba(255,100,139,.28);
            border-radius: 13px;
            background: rgba(255,100,139,.065);
            color: #ffb5c8;
            font-size: 12px;
            line-height: 1.8;
        }

        .error-list strong { display: block; margin-bottom: 6px; }
        .error-list ul { margin: 0; padding-left: 19px; }

        .form-actions { display: flex; align-items: center; justify-content: space-between; gap: 14px; flex-wrap: wrap; margin-top: 25px; }
        .form-note { display: flex; align-items: center; gap: 8px; color: var(--muted); font-size: 10px; }
        .form-note span { color: var(--green); transition: transform .25s; }
        .form-note:hover span { transform: scale(1.2); }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 9px;
            min-height: 45px;
            padding: 12px 17px;
            border: 1px solid transparent;
            border-radius: 12px;
            cursor: pointer;
            font-size: 12px;
            font-weight: 800;
            transition: transform .25s, box-shadow .25s, background .25s, border-color .25s, color .25s;
        }

        .btn-icon { display: inline-block; transition: transform .3s; }

        .btn-primary { color: #04121e; background: linear-gradient(115deg,var(--cyan),#6ba6ff); box-shadow: 0 7px 24px rgba(53,229,255,.16); }
        .btn-primary:hover { transform: translateY(-3px); box-shadow: 0 12px 30px rgba(53,229,255,.22); }
        .btn-primary:hover .btn-icon { transform: rotate(-10deg) scale(1.2); }

        .btn-secondary { color: var(--text); border-color: var(--line); background: rgba(255,255,255,.025); }
        .btn-secondary:hover { transform: translateY(-2px); color: var(--cyan); border-color: rgba(53,229,255,.35); background: rgba(53,229,255,.06); }
        .btn-secondary:hover .btn-icon { transform: translateX(-3px); }

        .side-content { padding: 23px; }

        .side-visual {
            position: relative;
            display: grid;
            place-items: center;
            width: 112px;
            height: 112px;
            margin: 2px auto 23px;
            border: 1px solid rgba(53,229,255,.2);
            border-radius: 50%;
            background: radial-gradient(circle,rgba(53,229,255,.11),rgba(53,229,255,.02) 67%);
            box-shadow: inset 0 0 28px rgba(53,229,255,.05);
            animation: float 5s ease-in-out infinite;
        }

        .side-visual::before, .side-visual::after { content: ""; position: absolute; inset: 10px; border: 1px dashed rgba(53,229,255,.3); border-radius: 50%; animation: orbit 18s linear infinite; }
        .side-visual::after { inset: -8px; border-style: solid; border-color: rgba(67,139,255,.18); animation-direction: reverse; }
        .side-visual span { font-size: 39px; filter: drop-shadow(0 0 13px rgba(53,229,255,.35)); transition: transform .3s; }
        .side-visual:hover span { transform: scale(1.14) rotate(8deg); }

        .side-heading { margin: 0 0 9px; text-align: center; font: 700 18px 'Space Grotesk',sans-serif; }
        .side-description { margin: 0 auto 23px; max-width: 290px; text-align: center; color: var(--muted); font-size: 11px; line-height: 1.8; }

        .tip-list { display: grid; gap: 12px; }

        .tip {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            padding: 13px;
            border: 1px solid rgba(86,164,255,.12);
            border-radius: 13px;
            background: rgba(255,255,255,.018);
            transition: transform .25s, border-color .25s, background .25s;
        }

        .tip:hover { transform: translateX(4px); border-color: rgba(53,229,255,.25); background: rgba(53,229,255,.035); }

        .tip-icon { display: grid; place-items: center; flex: 0 0 31px; height: 31px; border: 1px solid rgba(53,229,255,.17); border-radius: 10px; color: var(--cyan); background: rgba(53,229,255,.055); transition: transform .3s, box-shadow .3s; }
        .tip:hover .tip-icon { transform: rotate(-8deg) scale(1.08); box-shadow: 0 0 14px rgba(53,229,255,.12); }
        .tip strong { display: block; margin: 2px 0 5px; color: #dceaff; font-size: 11px; }
        .tip p { margin: 0; color: var(--muted); font-size: 10px; line-height: 1.7; }

        .privacy-note { margin-top: 19px; padding: 13px; border: 1px solid rgba(77,245,189,.16); border-radius: 12px; color: #a5d9c8; background: rgba(77,245,189,.035); font-size: 10px; line-height: 1.7; }
        .privacy-note strong { color: var(--green); }

        footer { display: flex; justify-content: space-between; gap: 16px; margin-top: 35px; padding-top: 20px; border-top: 1px solid rgba(86,164,255,.12); color: #667c9d; font-size: 10px; }
        footer span { transition: color .25s; }
        footer span:hover { color: var(--cyan); }

        @keyframes reveal { to { opacity: 1; transform: translateY(0); } }
        @keyframes pulse { 0%,100% { opacity: 1; transform: scale(1); } 50% { opacity: .55; transform: scale(.75); } }
        @keyframes float { 0%,100% { transform: translateY(0); } 50% { transform: translateY(-8px); } }
        @keyframes orbit { to { transform: rotate(360deg); } }
        @keyframes ambientFloat { from { transform: translate(0,0) scale(1); } to { transform: translate(45px,-35px) scale(1.12); } }

        @media (max-width: 1100px) {
            .nav-inner { padding: 12px 24px; flex-wrap: wrap; }
            .brand { min-width: auto; }
            .nav-links { order: 3; width: 100%; justify-content: flex-start; overflow-x: auto; padding-bottom: 3px; }
            .page { width: calc(100% - 48px); }
            .layout { grid-template-columns: minmax(0,1.2fr) minmax(230px,.8fr); gap: 16px; }
            .form-body { padding: 22px; }
            .panel-header { padding: 22px; }
        }

        @media (max-width: 800px) {
            .page { width: calc(100% - 32px); padding-top: 27px; }
            .layout { grid-template-columns: 1fr; }
            .side-panel { order: 2; }
            .side-content { padding: 24px; }
            .tip-list { grid-template-columns: repeat(2,minmax(0,1fr)); }
        }

        @media (max-width: 540px) {
            .nav-inner { padding: 12px 18px; gap: 12px; }
            .brand img { width: 38px; height: 38px; }
            .brand-name { font-size: 19px; }
            .nav-user .user-details { display: none; }
            .nav-link { padding: 10px 11px; font-size: 11px; }
            .heading { align-items: flex-start; flex-direction: column; }
            .heading h1 { font-size: 32px; }
            .form-body { padding: 19px; }
            .panel-header { padding: 20px; }
            .form-grid { grid-template-columns: 1fr; gap: 17px; }
            .field.full { grid-column: auto; }
            .form-actions { align-items: stretch; flex-direction: column; }
            .form-actions .btn { width: 100%; }
            .tip-list { grid-template-columns: 1fr; }
            footer { flex-direction: column; }
            .corner { opacity: .35; }
        }

        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                scroll-behavior: auto !important;
                animation-duration: .01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: .01ms !important;
            }

            .reveal { opacity: 1; transform: none; }
        }
    </style>
</head>
<body>
    <div class="ambient one" aria-hidden="true"></div>
    <div class="ambient two" aria-hidden="true"></div>
    <div class="corner tl" aria-hidden="true"></div>
    <div class="corner tr" aria-hidden="true"></div>
    <div class="corner bl" aria-hidden="true"></div>
    <div class="corner br" aria-hidden="true"></div>

    <header class="topbar">
        <div class="nav-inner">
            <a class="brand" href="dashboard.php" aria-label="InternPro company dashboard">
                <img src="../assets/logo.jpg" alt="InternPro logo">
                <span class="brand-name">Intern<span>Pro</span></span>
            </a>

            <nav class="nav-links" aria-label="Company navigation">
                <a class="nav-link" href="dashboard.php"><span class="nav-icon">⌂</span> Dashboard</a>
                <a class="nav-link" href="internships.php"><span class="nav-icon">▤</span> My Internships</a>
                <a class="nav-link active" href="add_internship.php" aria-current="page"><span class="nav-icon">＋</span> Post Internship</a>
                <a class="nav-link" href="applicants.php"><span class="nav-icon">♙</span> Applicants</a>
            </nav>

            <div class="nav-user">
                <div class="avatar" aria-hidden="true"><?= h(strtoupper(substr((string) $firstName, 0, 1))) ?></div>
                <div class="user-details">
                    <div class="user-name"><?= h($companyName) ?></div>
                    <div class="user-caption">Company workspace</div>
                </div>
            </div>
        </div>
    </header>

    <main class="page">
        <section class="heading reveal">
            <div>
                <div class="eyebrow"><span class="pulse-dot"></span> CREATE AN OPPORTUNITY</div>
                <h1>Post an <span>Internship</span></h1>
                <p>Share an exciting opportunity with emerging talent. Give students the details they need to imagine their future with your team.</p>
            </div>
            <a class="back-link" href="internships.php"><span>←</span> Back to internships</a>
        </section>

        <div class="layout">
            <section class="form-panel reveal delay-1">
                <div class="panel-header">
                    <h2>Internship details</h2>
                    <p>Complete the information below. Fields marked with <span style="color:var(--cyan)">*</span> are required.</p>
                </div>

                <div class="form-body">
                    <?php if ($errors): ?>
                        <div class="error-list" role="alert" aria-live="polite">
                            <strong>Please review the following:</strong>
                            <ul>
                                <?php foreach (array_unique($errors) as $error): ?>
                                    <li><?= h($error) ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form method="post" action="add_internship.php" id="internshipForm">
                        <input type="hidden" name="csrf_token" value="<?= h($_SESSION['internpro_csrf']) ?>">

                        <h3 class="form-section-title"><span class="section-icon" aria-hidden="true">⌘</span> Opportunity overview</h3>

                        <div class="form-grid">
                            <div class="field full">
                                <label for="title">Internship title <span class="required">*</span></label>
                                <input class="field-control" id="title" name="title" type="text" maxlength="200" required placeholder="e.g. Frontend Developer Intern" value="<?= h($old['title']) ?>">
                                <span class="field-hint">Choose a clear title that tells students what they'll be working on.</span>
                            </div>

                            <div class="field full">
                                <label for="description">Description and responsibilities <span class="required">*</span></label>
                                <textarea class="field-control" id="description" name="description" maxlength="20000" required placeholder="Describe the role, responsibilities, required skills, learning opportunities, and what makes your team special..."><?= h($old['description']) ?></textarea>
                                <div class="description-counter">
                                    <span>Make the opportunity clear and welcoming.</span>
                                    <span id="descriptionCount">0 / 20,000</span>
                                </div>
                            </div>
                        </div>

                        <div class="form-divider"></div>

                        <h3 class="form-section-title"><span class="section-icon" aria-hidden="true">◈</span> Work arrangement</h3>

                        <div class="form-grid">
                            <div class="field">
                                <label for="location">Location</label>
                                <input class="field-control" id="location" name="location" type="text" maxlength="150" placeholder="e.g. Chennai or Work from anywhere" value="<?= h($old['location']) ?>">
                                <span class="field-hint">City, office location, or remote.</span>
                            </div>

                            <div class="field">
                                <label for="type">Work type <span class="required">*</span></label>
                                <select class="field-control" id="type" name="type" required>
                                    <?php foreach (['Full-time', 'Part-time', 'Remote', 'Hybrid', 'On-site'] as $type): ?>
                                        <option value="<?= h($type) ?>" <?= $old['type'] === $type ? 'selected' : '' ?>><?= h($type) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <span class="field-hint">Choose the arrangement that best fits this role.</span>
                            </div>

                            <div class="field">
                                <label for="stipend">Stipend or compensation</label>
                                <input class="field-control" id="stipend" name="stipend" type="text" maxlength="100" placeholder="e.g. ₹10,000 per month or Unpaid" value="<?= h($old['stipend']) ?>">
                                <span class="field-hint">Be transparent about compensation.</span>
                            </div>

                            <div class="field">
                                <label for="duration">Duration</label>
                                <input class="field-control" id="duration" name="duration" type="text" maxlength="100" placeholder="e.g. 3 months" value="<?= h($old['duration']) ?>">
                                <span class="field-hint">Specify the expected internship length.</span>
                            </div>

                            <div class="field full">
                                <label for="deadline">Application deadline</label>
                                <input class="field-control" id="deadline" name="deadline" type="date" value="<?= h($old['deadline']) ?>" min="<?= h(date('Y-m-d')) ?>">
                                <span class="field-hint">Leave this blank if you haven't decided on a deadline.</span>
                            </div>
                        </div>

                        <div class="form-actions">
                            <div class="form-note"><span aria-hidden="true">✓</span> Your post will be associated with your company account.</div>
                            <button class="btn btn-primary" type="submit">
                                <span class="btn-icon" aria-hidden="true">↗</span> Publish internship
                            </button>
                        </div>
                    </form>
                </div>
            </section>

            <aside class="side-panel reveal delay-2">
                <div class="panel-header">
                    <h2>Make your post stand out</h2>
                    <p>A few details can help the right students discover your opportunity.</p>
                </div>

                <div class="side-content">
                    <div class="side-visual" aria-hidden="true"><span>✧</span></div>
                    <h3 class="side-heading">Build your future team</h3>
                    <p class="side-description">A thoughtful internship description can help students understand the opportunity and decide whether it fits their goals.</p>

                    <div class="tip-list">
                        <article class="tip">
                            <span class="tip-icon" aria-hidden="true">◎</span>
                            <div>
                                <strong>Be specific</strong>
                                <p>Explain the role, responsibilities, and skills students can develop.</p>
                            </div>
                        </article>

                        <article class="tip">
                            <span class="tip-icon" aria-hidden="true">₹</span>
                            <div>
                                <strong>Share compensation</strong>
                                <p>Include stipend details and duration when you know them.</p>
                            </div>
                        </article>

                        <article class="tip">
                            <span class="tip-icon" aria-hidden="true">⌖</span>
                            <div>
                                <strong>Clarify the location</strong>
                                <p>Let students know whether the role is remote, hybrid, or office-based.</p>
                            </div>
                        </article>

                        <article class="tip">
                            <span class="tip-icon" aria-hidden="true">◷</span>
                            <div>
                                <strong>Set expectations</strong>
                                <p>Add a realistic application deadline and internship duration.</p>
                            </div>
                        </article>
                    </div>

                    <div class="privacy-note">
                        <strong>✓ Secure submission</strong><br>
                        Your form is protected with a session token and server-side validation.
                    </div>
                </div>
            </aside>
        </div>

        <footer>
            <span>© <?= date('Y') ?> InternPro · Company workspace</span>
            <span>Built for talent. Designed for the future. <span style="color:var(--cyan)">◆</span></span>
        </footer>
    </main>

    <script>
        (() => {
            const description = document.getElementById('description');
            const counter = document.getElementById('descriptionCount');
            const form = document.getElementById('internshipForm');
            const deadline = document.getElementById('deadline');

            const updateCount = () => {
                if (description && counter) {
                    counter.textContent = `${description.value.length.toLocaleString()} / 20,000`;
                }
            };

            if (description) {
                description.addEventListener('input', updateCount);
                updateCount();
            }

            if (deadline) {
                const today = new Date();
                const localToday = new Date(
                    today.getTime() - today.getTimezoneOffset() * 60000
                ).toISOString().slice(0, 10);

                deadline.min = localToday;
            }

            if (form) {
                form.addEventListener('submit', (event) => {
                    if (!form.checkValidity()) {
                        event.preventDefault();
                        form.reportValidity();
                        return;
                    }

                    const submitButton = form.querySelector('button[type="submit"]');

                    if (submitButton) {
                        submitButton.disabled = true;
                        submitButton.style.opacity = '0.75';
                        submitButton.style.cursor = 'wait';
                        submitButton.innerHTML = '<span class="btn-icon">◌</span> Publishing...';
                    }
                });
            }
        })();
    </script>
</body>
</html>
