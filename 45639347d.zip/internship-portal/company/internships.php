<?php
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (
    !isset($_SESSION['user_id'], $_SESSION['role']) ||
    !in_array(strtolower((string) $_SESSION['role']), ['company', 'recruiter'], true)
) {
    header('Location: ../login.php');
    exit;
}

require_once __DIR__ . '/../config/database.php';

if (!isset($pdo) || !($pdo instanceof PDO)) {
    http_response_code(500);
    exit('Database connection is not configured correctly.');
}

$userId = (int) $_SESSION['user_id'];
$companyId = null;
$companyName = $_SESSION['name'] ?? $_SESSION['company_name'] ?? 'Company';
$errorMessage = '';
$successMessage = '';
$internships = [];
$stats = [
    'total' => 0,
    'active' => 0,
    'closed' => 0,
    'applications' => 0,
];

function h($value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function getColumns(PDO $pdo, string $table): array
{
    $allowed = ['companies', 'users', 'internships', 'applications'];

    if (!in_array($table, $allowed, true)) {
        return [];
    }

    try {
        $stmt = $pdo->query("SHOW COLUMNS FROM `$table`");
        return array_column($stmt->fetchAll(PDO::FETCH_ASSOC), 'Field');
    } catch (Throwable $e) {
        return [];
    }
}

function findColumn(array $columns, array $candidates): ?string
{
    foreach ($candidates as $candidate) {
        if (in_array($candidate, $columns, true)) {
            return $candidate;
        }
    }

    return null;
}

function displayStatus($value): string
{
    $status = strtolower(trim((string) $value));

    if ($status === '') {
        return 'Unknown';
    }

    return ucwords(str_replace(['_', '-'], ' ', $status));
}

function statusClass($value): string
{
    $status = strtolower(trim((string) $value));

    if (in_array($status, ['active', 'open', 'published', 'approved'], true)) {
        return 'status-active';
    }

    if (in_array($status, ['closed', 'inactive', 'expired', 'archived'], true)) {
        return 'status-closed';
    }

    if (in_array($status, ['draft', 'pending', 'under_review'], true)) {
        return 'status-pending';
    }

    return 'status-neutral';
}

function formatDateValue($value): string
{
    if (!$value) {
        return 'Date not available';
    }

    try {
        return (new DateTime((string) $value))->format('d M Y');
    } catch (Throwable $e) {
        return (string) $value;
    }
}

try {
    $companyColumns = getColumns($pdo, 'companies');
    $internshipColumns = getColumns($pdo, 'internships');
    $applicationColumns = getColumns($pdo, 'applications');

    if (
        in_array('id', $companyColumns, true) &&
        in_array('user_id', $companyColumns, true)
    ) {
        $stmt = $pdo->prepare(
            'SELECT * FROM companies WHERE user_id = :user_id LIMIT 1'
        );
        $stmt->execute(['user_id' => $userId]);
        $company = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($company) {
            $companyId = (int) $company['id'];

            foreach (['company_name', 'name', 'organization_name'] as $column) {
                if (!empty($company[$column])) {
                    $companyName = $company[$column];
                    break;
                }
            }
        }
    }

    $idColumn = findColumn($internshipColumns, ['id']);
    $companyColumn = findColumn($internshipColumns, ['company_id', 'employer_id']);
    $titleColumn = findColumn($internshipColumns, ['title', 'internship_title', 'position']);
    $descriptionColumn = findColumn($internshipColumns, ['description', 'details', 'job_description']);
    $statusColumn = findColumn($internshipColumns, ['status', 'application_status']);
    $locationColumn = findColumn($internshipColumns, ['location', 'work_location', 'city']);
    $typeColumn = findColumn($internshipColumns, ['type', 'internship_type', 'job_type']);
    $stipendColumn = findColumn($internshipColumns, ['stipend', 'salary', 'salary_range']);
    $deadlineColumn = findColumn($internshipColumns, ['deadline', 'application_deadline', 'last_date']);
    $createdColumn = findColumn($internshipColumns, ['created_at', 'posted_at', 'date_posted']);
    $durationColumn = findColumn($internshipColumns, ['duration', 'duration_months']);
    $idApplicationColumn = findColumn($applicationColumns, ['id']);
    $applicationInternshipColumn = findColumn($applicationColumns, ['internship_id']);

    if (!$companyId) {
        $errorMessage = 'No company profile is linked to your account. Please check your company profile and account mapping.';
    } elseif (!$idColumn || !$companyColumn) {
        $errorMessage = 'The internships table is missing its ID or company relationship column. Please check your database schema.';
    } else {
        $where = " WHERE i.`$companyColumn` = :company_id";
        $params = ['company_id' => $companyId];

        $search = trim((string) ($_GET['q'] ?? ''));
        $statusFilter = strtolower(trim((string) ($_GET['status'] ?? 'all')));

        if ($search !== '') {
            $searchable = [];

            foreach ([$titleColumn, $descriptionColumn, $locationColumn, $typeColumn] as $column) {
                if ($column !== null) {
                    $searchable[] = "i.`$column` LIKE :search";
                }
            }

            if ($searchable) {
                $where .= ' AND (' . implode(' OR ', $searchable) . ')';
                $params['search'] = '%' . $search . '%';
            }
        }

        if ($statusColumn && $statusFilter !== '' && $statusFilter !== 'all') {
            $where .= " AND LOWER(COALESCE(i.`$statusColumn`, '')) = :status_filter";
            $params['status_filter'] = $statusFilter;
        }

        $titleSelect = $titleColumn
            ? "i.`$titleColumn` AS internship_title"
            : "'Untitled internship' AS internship_title";

        $descriptionSelect = $descriptionColumn
            ? "i.`$descriptionColumn` AS internship_description"
            : "'' AS internship_description";

        $statusSelect = $statusColumn
            ? "i.`$statusColumn` AS internship_status"
            : "'active' AS internship_status";

        $locationSelect = $locationColumn
            ? "i.`$locationColumn` AS internship_location"
            : "'' AS internship_location";

        $typeSelect = $typeColumn
            ? "i.`$typeColumn` AS internship_type"
            : "'' AS internship_type";

        $stipendSelect = $stipendColumn
            ? "i.`$stipendColumn` AS internship_stipend"
            : "'' AS internship_stipend";

        $deadlineSelect = $deadlineColumn
            ? "i.`$deadlineColumn` AS internship_deadline"
            : "NULL AS internship_deadline";

        $createdSelect = $createdColumn
            ? "i.`$createdColumn` AS internship_created"
            : "NULL AS internship_created";

        $durationSelect = $durationColumn
            ? "i.`$durationColumn` AS internship_duration"
            : "'' AS internship_duration";

        $applicationCountSelect = '0 AS application_count';

        if (
            $idApplicationColumn &&
            $applicationInternshipColumn &&
            in_array($idColumn, $internshipColumns, true)
        ) {
            $applicationCountSelect =
                "(SELECT COUNT(*) FROM applications a " .
                "WHERE a.`$applicationInternshipColumn` = i.`$idColumn`) AS application_count";
        }

        $orderBy = $createdColumn
            ? "i.`$createdColumn` DESC"
            : "i.`$idColumn` DESC";

        $sql = "SELECT
                    i.`$idColumn` AS internship_id,
                    $titleSelect,
                    $descriptionSelect,
                    $statusSelect,
                    $locationSelect,
                    $typeSelect,
                    $stipendSelect,
                    $deadlineSelect,
                    $createdSelect,
                    $durationSelect,
                    $applicationCountSelect
                FROM internships i
                $where
                ORDER BY $orderBy";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $internships = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $stats['total'] = count($internships);

        foreach ($internships as $internship) {
            $status = strtolower((string) ($internship['internship_status'] ?? ''));

            if (in_array($status, ['active', 'open', 'published', 'approved'], true)) {
                $stats['active']++;
            } elseif (in_array($status, ['closed', 'inactive', 'expired', 'archived'], true)) {
                $stats['closed']++;
            }

            $stats['applications'] += (int) ($internship['application_count'] ?? 0);
        }
    }
} catch (Throwable $e) {
    $errorMessage = 'Internships could not be loaded. Please check your database schema and company account mapping.';
    error_log('InternPro company internships: ' . $e->getMessage());
}

$firstName = preg_split('/\s+/', trim((string) $companyName))[0] ?? 'Company';
$searchValue = trim((string) ($_GET['q'] ?? ''));
$currentStatus = strtolower(trim((string) ($_GET['status'] ?? 'all')));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#070b18">
    <title>My Internships | InternPro</title>
    <link rel="icon" type="image/jpeg" href="../assets/logo.jpg">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #070b18;
            --panel: rgba(13,22,43,.86);
            --line: rgba(86,164,255,.18);
            --blue: #438bff;
            --cyan: #35e5ff;
            --text: #eef6ff;
            --muted: #8fa4c4;
            --green: #4df5bd;
            --red: #ff648b;
            --purple: #a98aff;
        }

        * { box-sizing: border-box; }
        html { scroll-behavior: smooth; }

        body {
            margin: 0;
            min-height: 100vh;
            overflow-x: hidden;
            color: var(--text);
            font-family: Inter, sans-serif;
            background:
                radial-gradient(ellipse at 8% 0%, rgba(36,105,232,.16), transparent 34%),
                radial-gradient(ellipse at 95% 45%, rgba(31,212,255,.08), transparent 32%),
                var(--bg);
        }

        body::before {
            content: "";
            position: fixed;
            inset: 0;
            pointer-events: none;
            z-index: -1;
            opacity: .18;
            background-image:
                linear-gradient(rgba(74,143,255,.11) 1px, transparent 1px),
                linear-gradient(90deg, rgba(74,143,255,.11) 1px, transparent 1px);
            background-size: 48px 48px;
            mask-image: linear-gradient(to bottom, black, transparent 85%);
        }

        a { color: inherit; text-decoration: none; }
        button, input, select { font: inherit; }
        :focus-visible { outline: 2px solid var(--cyan); outline-offset: 4px; }

        .ambient {
            position: fixed;
            width: 300px;
            height: 300px;
            border-radius: 50%;
            filter: blur(90px);
            opacity: .13;
            pointer-events: none;
            z-index: -1;
            animation: ambientFloat 12s ease-in-out infinite alternate;
        }

        .ambient.one { top: 15%; left: -160px; background: #287bff; }
        .ambient.two { right: -170px; bottom: 4%; background: #00e5ff; animation-delay: -5s; }

        .corner {
            position: fixed;
            width: 28px;
            height: 28px;
            z-index: 20;
            pointer-events: none;
            opacity: .65;
        }

        .corner::before, .corner::after {
            content: "";
            position: absolute;
            background: var(--cyan);
            box-shadow: 0 0 12px rgba(53,229,255,.65);
        }

        .corner::before { width: 25px; height: 2px; }
        .corner::after { width: 2px; height: 25px; }
        .corner.tl { top: 12px; left: 12px; }
        .corner.tr { top: 12px; right: 12px; transform: rotate(90deg); }
        .corner.bl { bottom: 12px; left: 12px; transform: rotate(-90deg); }
        .corner.br { bottom: 12px; right: 12px; transform: rotate(180deg); }

        .topbar {
            position: sticky;
            top: 0;
            z-index: 15;
            border-bottom: 1px solid var(--line);
            background: rgba(7,11,24,.86);
            backdrop-filter: blur(20px);
        }

        .nav-inner {
            max-width: 1440px;
            min-height: 78px;
            margin: auto;
            padding: 12px 34px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 24px;
        }

        .brand { display: flex; align-items: center; gap: 12px; min-width: 170px; }

        .brand img {
            width: 45px;
            height: 45px;
            object-fit: cover;
            border-radius: 13px;
            border: 1px solid rgba(53,229,255,.4);
            box-shadow: 0 0 24px rgba(53,229,255,.13);
            transition: transform .35s, box-shadow .35s;
        }

        .brand:hover img { transform: rotate(-5deg) scale(1.08); box-shadow: 0 0 28px rgba(53,229,255,.35); }
        .brand-name { font: 700 22px 'Space Grotesk', sans-serif; letter-spacing: -.8px; }
        .brand-name span { color: var(--cyan); }

        .nav-links { display: flex; align-items: center; justify-content: center; flex-wrap: wrap; gap: 7px; }

        .nav-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 11px 13px;
            border: 1px solid transparent;
            border-radius: 12px;
            color: var(--muted);
            font-size: 13px;
            font-weight: 600;
            transition: color .25s, background .25s, border-color .25s, transform .25s;
        }

        .nav-icon { display: inline-block; transition: transform .3s, filter .3s; }

        .nav-link:hover, .nav-link.active {
            color: var(--cyan);
            border-color: rgba(53,229,255,.18);
            background: rgba(53,229,255,.07);
            transform: translateY(-2px);
        }

        .nav-link:hover .nav-icon { transform: scale(1.2) rotate(-8deg); filter: drop-shadow(0 0 5px var(--cyan)); }

        .nav-user { display: flex; align-items: center; gap: 10px; }
        .avatar {
            width: 39px;
            height: 39px;
            display: grid;
            place-items: center;
            border: 1px solid rgba(53,229,255,.35);
            border-radius: 13px;
            color: var(--cyan);
            font-weight: 800;
            background: linear-gradient(135deg, rgba(67,139,255,.22), rgba(53,229,255,.08));
            transition: transform .3s, box-shadow .3s;
        }

        .nav-user:hover .avatar { transform: rotate(5deg) scale(1.08); box-shadow: 0 0 20px rgba(53,229,255,.2); }
        .user-name { max-width: 145px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 12px; font-weight: 700; }
        .user-caption { color: var(--muted); font-size: 11px; margin-top: 3px; }

        .page { width: min(1372px, calc(100% - 68px)); margin: 0 auto; padding: 38px 0 60px; }
        .reveal { opacity: 0; transform: translateY(18px); animation: reveal .65s cubic-bezier(.2,.75,.25,1) forwards; }
        .delay-1 { animation-delay: .08s; }
        .delay-2 { animation-delay: .16s; }
        .delay-3 { animation-delay: .24s; }

        .eyebrow { display: inline-flex; align-items: center; gap: 8px; color: var(--cyan); text-transform: uppercase; font-size: 10px; font-weight: 800; letter-spacing: 2px; }
        .pulse-dot { width: 7px; height: 7px; border-radius: 50%; background: var(--green); box-shadow: 0 0 12px var(--green); animation: pulse 1.8s ease-in-out infinite; }

        .page-heading {
            display: flex;
            align-items: flex-end;
            justify-content: space-between;
            gap: 24px;
            margin-bottom: 26px;
        }

        .page-heading h1 {
            margin: 13px 0 9px;
            font: 700 clamp(28px, 3vw, 40px)/1.15 'Space Grotesk', sans-serif;
            letter-spacing: -1.4px;
        }

        .page-heading h1 span { color: var(--cyan); text-shadow: 0 0 28px rgba(53,229,255,.18); }
        .page-heading p { max-width: 630px; margin: 0; color: var(--muted); font-size: 13px; line-height: 1.8; }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 9px;
            min-height: 44px;
            padding: 12px 17px;
            border: 1px solid transparent;
            border-radius: 12px;
            cursor: pointer;
            font-size: 12px;
            font-weight: 800;
            white-space: nowrap;
            transition: transform .25s, box-shadow .25s, background .25s, border-color .25s, color .25s;
        }

        .btn-icon { display: inline-block; transition: transform .3s; }

        .btn-primary {
            color: #04121e;
            background: linear-gradient(115deg, var(--cyan), #6ba6ff);
            box-shadow: 0 7px 24px rgba(53,229,255,.16);
        }

        .btn-primary:hover { transform: translateY(-3px); box-shadow: 0 12px 30px rgba(53,229,255,.2); }
        .btn-primary:hover .btn-icon { transform: rotate(-10deg) scale(1.2); }

        .stats-grid { display: grid; grid-template-columns: repeat(4, minmax(0,1fr)); gap: 16px; }

        .stat-card {
            position: relative;
            overflow: hidden;
            min-height: 140px;
            padding: 21px;
            border: 1px solid var(--line);
            border-radius: 20px;
            background: linear-gradient(145deg, rgba(17,30,55,.91), rgba(10,18,35,.9));
            transition: transform .3s, border-color .3s, box-shadow .3s;
        }

        .stat-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 15%;
            width: 70%;
            height: 1px;
            background: linear-gradient(90deg, transparent, var(--accent,var(--cyan)), transparent);
            opacity: .6;
        }

        .stat-card::after {
            content: "";
            position: absolute;
            right: -45px;
            bottom: -55px;
            width: 125px;
            height: 125px;
            border-radius: 50%;
            background: var(--glow,rgba(53,229,255,.13));
            filter: blur(40px);
            transition: transform .4s;
        }

        .stat-card:hover { transform: translateY(-6px); border-color: rgba(53,229,255,.4); box-shadow: 0 18px 38px rgba(0,0,0,.17); }
        .stat-card:hover::after { transform: scale(1.4); }

        .stat-top { display: flex; align-items: center; justify-content: space-between; gap: 10px; }
        .stat-icon { width: 40px; height: 40px; display: grid; place-items: center; border: 1px solid rgba(53,229,255,.18); border-radius: 13px; color: var(--accent,var(--cyan)); background: rgba(53,229,255,.07); font-size: 19px; transition: transform .3s, box-shadow .3s; }
        .stat-card:hover .stat-icon { transform: rotate(-8deg) scale(1.12); box-shadow: 0 0 20px var(--glow,rgba(53,229,255,.14)); }
        .stat-caption { color: var(--muted); font-size: 10px; }
        .stat-number { position: relative; z-index: 1; margin-top: 15px; font: 700 28px 'Space Grotesk',sans-serif; }
        .stat-label { position: relative; z-index: 1; margin-top: 4px; color: var(--muted); font-size: 11px; }

        .toolbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
            flex-wrap: wrap;
            margin: 28px 0 20px;
            padding: 17px;
            border: 1px solid var(--line);
            border-radius: 18px;
            background: rgba(13,22,43,.72);
        }

        .toolbar-title { font: 700 16px 'Space Grotesk',sans-serif; }
        .toolbar-subtitle { margin-top: 5px; color: var(--muted); font-size: 11px; }

        .filters { display: flex; align-items: center; justify-content: flex-end; gap: 10px; flex-wrap: wrap; }

        .search-box {
            display: flex;
            align-items: center;
            gap: 9px;
            min-width: 230px;
            padding: 0 13px;
            border: 1px solid rgba(86,164,255,.2);
            border-radius: 11px;
            background: rgba(4,12,27,.6);
            transition: border-color .25s, box-shadow .25s;
        }

        .search-box:focus-within { border-color: var(--cyan); box-shadow: 0 0 0 3px rgba(53,229,255,.06); }
        .search-symbol { color: var(--cyan); transition: transform .25s; }
        .search-box:focus-within .search-symbol { transform: scale(1.15); }

        .search-box input {
            width: 100%;
            min-height: 42px;
            color: var(--text);
            background: transparent;
            border: 0;
            outline: 0;
            font-size: 11px;
        }

        .search-box input::placeholder { color: #6e82a1; }

        .filter-select {
            min-height: 44px;
            padding: 0 33px 0 12px;
            color: var(--text);
            border: 1px solid rgba(86,164,255,.2);
            border-radius: 11px;
            background: #0b152a;
            font-size: 11px;
            cursor: pointer;
            transition: border-color .25s, box-shadow .25s;
        }

        .filter-select:focus { border-color: var(--cyan); box-shadow: 0 0 0 3px rgba(53,229,255,.06); }
        .filter-select option { background: #0b152a; color: var(--text); }

        .filter-submit {
            min-height: 44px;
            padding: 0 15px;
            color: var(--cyan);
            border: 1px solid rgba(53,229,255,.24);
            border-radius: 11px;
            background: rgba(53,229,255,.06);
            font-size: 11px;
            font-weight: 800;
            cursor: pointer;
            transition: transform .25s, background .25s, box-shadow .25s;
        }

        .filter-submit:hover { transform: translateY(-2px); background: rgba(53,229,255,.12); box-shadow: 0 8px 22px rgba(53,229,255,.08); }

        .alert {
            margin-bottom: 18px;
            padding: 14px 17px;
            border: 1px solid rgba(255,100,139,.25);
            border-radius: 12px;
            background: rgba(255,100,139,.06);
            color: #ffb4c8;
            font-size: 12px;
            line-height: 1.7;
        }

        .results-line { display: flex; align-items: center; justify-content: space-between; gap: 12px; margin: 0 2px 15px; color: var(--muted); font-size: 11px; }
        .results-line strong { color: var(--text); }

        .internship-grid { display: grid; grid-template-columns: repeat(3,minmax(0,1fr)); gap: 18px; }

        .internship-card {
            position: relative;
            display: flex;
            flex-direction: column;
            min-width: 0;
            overflow: hidden;
            padding: 22px;
            border: 1px solid var(--line);
            border-radius: 21px;
            background: linear-gradient(150deg, rgba(15,26,48,.94), rgba(9,16,31,.92));
            box-shadow: 0 12px 35px rgba(0,0,0,.09);
            transition: transform .3s, border-color .3s, box-shadow .3s;
        }

        .internship-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 14%;
            width: 72%;
            height: 1px;
            background: linear-gradient(90deg, transparent, var(--cyan), transparent);
            opacity: .35;
            transition: opacity .3s;
        }

        .internship-card:hover { transform: translateY(-6px); border-color: rgba(53,229,255,.4); box-shadow: 0 20px 42px rgba(0,0,0,.2), 0 0 22px rgba(53,229,255,.045); }
        .internship-card:hover::before { opacity: 1; }

        .card-top { display: flex; align-items: flex-start; justify-content: space-between; gap: 12px; }

        .card-symbol {
            width: 48px;
            height: 48px;
            display: grid;
            place-items: center;
            flex: 0 0 48px;
            border: 1px solid rgba(53,229,255,.2);
            border-radius: 15px;
            color: var(--cyan);
            background: rgba(53,229,255,.07);
            font-size: 21px;
            transition: transform .35s, box-shadow .35s;
        }

        .internship-card:hover .card-symbol { transform: rotate(-8deg) scale(1.1); box-shadow: 0 0 22px rgba(53,229,255,.14); }

        .status {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 7px 9px;
            border: 1px solid transparent;
            border-radius: 9px;
            font-size: 9px;
            font-weight: 800;
            white-space: nowrap;
        }

        .status::before { content: ""; width: 5px; height: 5px; border-radius: 50%; background: currentColor; }
        .status-active { color: var(--green); background: rgba(77,245,189,.07); border-color: rgba(77,245,189,.16); }
        .status-closed { color: var(--red); background: rgba(255,100,139,.07); border-color: rgba(255,100,139,.16); }
        .status-pending { color: #91b1ff; background: rgba(67,139,255,.08); border-color: rgba(67,139,255,.17); }
        .status-neutral { color: #c5d3e7; background: rgba(197,211,231,.06); border-color: rgba(197,211,231,.12); }

        .card-title { margin: 19px 0 8px; font: 700 18px/1.4 'Space Grotesk',sans-serif; overflow-wrap: anywhere; }
        .card-description { display: -webkit-box; overflow: hidden; -webkit-line-clamp: 3; -webkit-box-orient: vertical; min-height: 57px; color: var(--muted); font-size: 11px; line-height: 1.75; overflow-wrap: anywhere; }

        .meta-list { display: flex; flex-wrap: wrap; gap: 8px; margin: 17px 0; }

        .meta-chip {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            max-width: 100%;
            padding: 7px 9px;
            color: #a7bbd7;
            border: 1px solid rgba(86,164,255,.13);
            border-radius: 9px;
            background: rgba(255,255,255,.02);
            font-size: 10px;
            overflow-wrap: anywhere;
            transition: color .25s, border-color .25s, background .25s;
        }

        .meta-chip span:first-child { color: var(--cyan); transition: transform .25s; }
        .internship-card:hover .meta-chip span:first-child { transform: scale(1.12); }
        .meta-chip:hover { color: var(--text); border-color: rgba(53,229,255,.25); background: rgba(53,229,255,.04); }

        .card-footer {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            margin-top: auto;
            padding-top: 16px;
            border-top: 1px solid rgba(86,164,255,.12);
        }

        .application-count { color: var(--muted); font-size: 10px; line-height: 1.6; }
        .application-count strong { display: block; color: var(--text); font-size: 17px; font-family: 'Space Grotesk',sans-serif; }
        .card-link { display: inline-flex; align-items: center; gap: 7px; color: var(--cyan); font-size: 11px; font-weight: 800; transition: transform .25s, color .25s; }
        .card-link:hover { transform: translateX(3px); color: #fff; }
        .card-link span { transition: transform .25s; }
        .card-link:hover span { transform: rotate(-10deg); }

        .empty-state {
            padding: 55px 22px;
            text-align: center;
            border: 1px dashed rgba(86,164,255,.25);
            border-radius: 22px;
            background: rgba(13,22,43,.45);
        }

        .empty-icon {
            display: inline-grid;
            place-items: center;
            width: 65px;
            height: 65px;
            margin-bottom: 17px;
            border: 1px solid rgba(53,229,255,.2);
            border-radius: 20px;
            color: var(--cyan);
            background: rgba(53,229,255,.06);
            font-size: 28px;
            transition: transform .35s, box-shadow .35s;
        }

        .empty-state:hover .empty-icon { transform: translateY(-5px) rotate(7deg); box-shadow: 0 0 25px rgba(53,229,255,.13); }
        .empty-state h2 { margin: 0; font: 700 21px 'Space Grotesk',sans-serif; }
        .empty-state p { max-width: 460px; margin: 10px auto 21px; color: var(--muted); font-size: 12px; line-height: 1.8; }

        footer { display: flex; justify-content: space-between; gap: 16px; margin-top: 35px; padding-top: 20px; border-top: 1px solid rgba(86,164,255,.12); color: #667c9d; font-size: 10px; }
        footer span { transition: color .25s; }
        footer span:hover { color: var(--cyan); }

        @keyframes reveal { to { opacity: 1; transform: translateY(0); } }
        @keyframes pulse { 0%,100% { opacity: 1; transform: scale(1); } 50% { opacity: .55; transform: scale(.75); } }
        @keyframes ambientFloat { from { transform: translate(0,0) scale(1); } to { transform: translate(45px,-35px) scale(1.12); } }

        @media (max-width: 1150px) {
            .nav-inner { padding: 12px 24px; flex-wrap: wrap; }
            .brand { min-width: auto; }
            .nav-links { order: 3; width: 100%; justify-content: flex-start; overflow-x: auto; padding-bottom: 3px; }
            .page { width: calc(100% - 48px); }
            .internship-grid { grid-template-columns: repeat(2,minmax(0,1fr)); }
        }

        @media (max-width: 780px) {
            .page { width: calc(100% - 32px); padding-top: 27px; }
            .page-heading { align-items: flex-start; flex-direction: column; }
            .stats-grid { grid-template-columns: repeat(2,minmax(0,1fr)); gap: 12px; }
            .toolbar { align-items: flex-start; }
            .filters { width: 100%; justify-content: flex-start; }
            .search-box { flex: 1 1 220px; }
        }

        @media (max-width: 540px) {
            .nav-inner { padding: 12px 18px; gap: 12px; }
            .brand img { width: 38px; height: 38px; }
            .brand-name { font-size: 19px; }
            .nav-user .user-details { display: none; }
            .nav-link { padding: 10px 11px; font-size: 11px; }
            .internship-grid { grid-template-columns: 1fr; }
            .stat-card { padding: 16px; min-height: 132px; }
            .stat-number { font-size: 25px; }
            .toolbar { padding: 14px; }
            .filters { display: grid; grid-template-columns: 1fr 1fr; }
            .search-box { grid-column: 1 / -1; min-width: 0; }
            .filter-select { width: 100%; }
            .filter-submit { width: 100%; }
            footer { flex-direction: column; }
            .corner { opacity: .35; }
        }

        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                scroll-behavior: auto !important;
                animation-duration: .01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: .01ms !important;
            }

            .reveal { opacity: 1; transform: none; }
        }
    </style>
</head>
<body>
    <div class="ambient one" aria-hidden="true"></div>
    <div class="ambient two" aria-hidden="true"></div>
    <div class="corner tl" aria-hidden="true"></div>
    <div class="corner tr" aria-hidden="true"></div>
    <div class="corner bl" aria-hidden="true"></div>
    <div class="corner br" aria-hidden="true"></div>

    <header class="topbar">
        <div class="nav-inner">
            <a class="brand" href="dashboard.php" aria-label="InternPro company dashboard">
                <img src="../assets/logo.jpg" alt="InternPro logo">
                <span class="brand-name">Intern<span>Pro</span></span>
            </a>

            <nav class="nav-links" aria-label="Company navigation">
                <a class="nav-link" href="dashboard.php">
                    <span class="nav-icon">⌂</span> Dashboard
                </a>
                <a class="nav-link active" href="internships.php" aria-current="page">
                    <span class="nav-icon">▤</span> My Internships
                </a>
                <a class="nav-link" href="add_internship.php">
                    <span class="nav-icon">＋</span> Post Internship
                </a>
                <a class="nav-link" href="applicants.php">
                    <span class="nav-icon">♙</span> Applicants
                </a>
            </nav>

            <div class="nav-user">
                <div class="avatar" aria-hidden="true"><?= h(strtoupper(substr((string) $firstName, 0, 1))) ?></div>
                <div class="user-details">
                    <div class="user-name"><?= h($companyName) ?></div>
                    <div class="user-caption">Company workspace</div>
                </div>
            </div>
        </div>
    </header>

    <main class="page">
        <section class="page-heading reveal">
            <div>
                <div class="eyebrow"><span class="pulse-dot"></span> OPPORTUNITY CONTROL</div>
                <h1>My <span>Internships</span></h1>
                <p>Manage your opportunities, monitor applications, and find the right talent to grow your team.</p>
            </div>
            <a class="btn btn-primary" href="add_internship.php">
                <span class="btn-icon">＋</span> Post internship
            </a>
        </section>

        <?php if ($errorMessage !== ''): ?>
            <div class="alert reveal" role="alert"><?= h($errorMessage) ?></div>
        <?php endif; ?>

        <section class="stats-grid reveal delay-1" aria-label="Internship statistics">
            <article class="stat-card" style="--accent:#35e5ff;--glow:rgba(53,229,255,.14)">
                <div class="stat-top">
                    <span class="stat-icon" aria-hidden="true">▤</span>
                    <span class="stat-caption">ALL POSTS</span>
                </div>
                <div class="stat-number"><?= number_format($stats['total']) ?></div>
                <div class="stat-label">Matching internships</div>
            </article>

            <article class="stat-card" style="--accent:#4df5bd;--glow:rgba(77,245,189,.14)">
                <div class="stat-top">
                    <span class="stat-icon" aria-hidden="true">◉</span>
                    <span class="stat-caption">OPEN ROLES</span>
                </div>
                <div class="stat-number"><?= number_format($stats['active']) ?></div>
                <div class="stat-label">Active opportunities</div>
            </article>

            <article class="stat-card" style="--accent:#ff648b;--glow:rgba(255,100,139,.14)">
                <div class="stat-top">
                    <span class="stat-icon" aria-hidden="true">◌</span>
                    <span class="stat-caption">NOT ACTIVE</span>
                </div>
                <div class="stat-number"><?= number_format($stats['closed']) ?></div>
                <div class="stat-label">Closed or archived</div>
            </article>

            <article class="stat-card" style="--accent:#a98aff;--glow:rgba(169,138,255,.14)">
                <div class="stat-top">
                    <span class="stat-icon" aria-hidden="true">♙</span>
                    <span class="stat-caption">CANDIDATES</span>
                </div>
                <div class="stat-number"><?= number_format($stats['applications']) ?></div>
                <div class="stat-label">Applications received</div>
            </article>
        </section>

        <section class="toolbar reveal delay-2" aria-label="Search and filter internships">
            <div>
                <div class="toolbar-title">Opportunity directory</div>
                <div class="toolbar-subtitle">Find and review your posted internships.</div>
            </div>

            <form class="filters" method="get" action="internships.php">
                <label class="search-box">
                    <span class="search-symbol" aria-hidden="true">⌕</span>
                    <input
                        type="search"
                        name="q"
                        value="<?= h($searchValue) ?>"
                        placeholder="Search title, location, skills..."
                        aria-label="Search internships"
                    >
                </label>

                <select class="filter-select" name="status" aria-label="Filter by status">
                    <option value="all" <?= $currentStatus === 'all' ? 'selected' : '' ?>>All statuses</option>
                    <option value="active" <?= $currentStatus === 'active' ? 'selected' : '' ?>>Active</option>
                    <option value="open" <?= $currentStatus === 'open' ? 'selected' : '' ?>>Open</option>
                    <option value="published" <?= $currentStatus === 'published' ? 'selected' : '' ?>>Published</option>
                    <option value="closed" <?= $currentStatus === 'closed' ? 'selected' : '' ?>>Closed</option>
                    <option value="inactive" <?= $currentStatus === 'inactive' ? 'selected' : '' ?>>Inactive</option>
                    <option value="draft" <?= $currentStatus === 'draft' ? 'selected' : '' ?>>Draft</option>
                    <option value="pending" <?= $currentStatus === 'pending' ? 'selected' : '' ?>>Pending</option>
                </select>

                <button class="filter-submit" type="submit">⌕ Filter</button>
            </form>
        </section>

        <section class="reveal delay-3" aria-label="Internship results">
            <div class="results-line">
                <span>Showing <strong><?= count($internships) ?></strong> matching opportunities</span>
                <?php if ($searchValue !== '' || $currentStatus !== 'all'): ?>
                    <a class="card-link" href="internships.php">Clear filters <span>↻</span></a>
                <?php endif; ?>
            </div>

            <?php if ($internships): ?>
                <div class="internship-grid">
                    <?php foreach ($internships as $internship): ?>
                        <?php
                        $status = (string) ($internship['internship_status'] ?? 'Unknown');
                        $description = trim(strip_tags((string) ($internship['internship_description'] ?? '')));
                        $description = preg_replace('/\s+/', ' ', $description) ?? $description;
                        $deadline = $internship['internship_deadline'] ?? null;
                        $created = $internship['internship_created'] ?? null;
                        ?>
                        <article class="internship-card">
                            <div class="card-top">
                                <span class="card-symbol" aria-hidden="true">⌘</span>
                                <span class="status <?= h(statusClass($status)) ?>">
                                    <?= h(displayStatus($status)) ?>
                                </span>
                            </div>

                            <h2 class="card-title"><?= h($internship['internship_title'] ?? 'Untitled internship') ?></h2>

                            <div class="card-description">
                                <?= h($description !== '' ? $description : 'No description has been added to this internship yet.') ?>
                            </div>

                            <div class="meta-list">
                                <?php if (!empty($internship['internship_location'])): ?>
                                    <span class="meta-chip"><span aria-hidden="true">⌖</span> <?= h($internship['internship_location']) ?></span>
                                <?php endif; ?>

                                <?php if (!empty($internship['internship_type'])): ?>
                                    <span class="meta-chip"><span aria-hidden="true">◈</span> <?= h($internship['internship_type']) ?></span>
                                <?php endif; ?>

                                <?php if (isset($internship['internship_stipend']) && trim((string) $internship['internship_stipend']) !== ''): ?>
                                    <span class="meta-chip"><span aria-hidden="true">₹</span> <?= h($internship['internship_stipend']) ?></span>
                                <?php endif; ?>

                                <?php if (!empty($internship['internship_duration'])): ?>
                                    <span class="meta-chip"><span aria-hidden="true">◷</span> <?= h($internship['internship_duration']) ?></span>
                                <?php endif; ?>

                                <?php if ($created): ?>
                                    <span class="meta-chip"><span aria-hidden="true">▦</span> Posted <?= h(formatDateValue($created)) ?></span>
                                <?php endif; ?>

                                <?php if ($deadline): ?>
                                    <span class="meta-chip"><span aria-hidden="true">⌛</span> Deadline <?= h(formatDateValue($deadline)) ?></span>
                                <?php endif; ?>
                            </div>

                            <div class="card-footer">
                                <div class="application-count">
                                    <strong><?= number_format((int) ($internship['application_count'] ?? 0)) ?></strong>
                                    applications
                                </div>
                                <a class="card-link" href="applicants.php">
                                    Review applicants <span>↗</span>
                                </a>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <div class="empty-icon" aria-hidden="true">⌕</div>

                    <?php if ($searchValue !== '' || $currentStatus !== 'all'): ?>
                        <h2>No matching internships found</h2>
                        <p>Try another search term or status filter. Your other posted internships may still be available.</p>
                        <a class="btn btn-primary" href="internships.php">
                            <span class="btn-icon">↻</span> Reset filters
                        </a>
                    <?php else: ?>
                        <h2>Your opportunities start here</h2>
                        <p>You haven't posted any internships yet, or no internships are linked to your company account. Create your first opportunity to start connecting with talented students.</p>
                        <a class="btn btn-primary" href="add_internship.php">
                            <span class="btn-icon">＋</span> Create internship
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </section>

        <footer>
            <span>© <?= date('Y') ?> InternPro · Company workspace</span>
            <span>Built for talent. Designed for the future. <span style="color:var(--cyan)">◆</span></span>
        </footer>
    </main>
</body>
</html>