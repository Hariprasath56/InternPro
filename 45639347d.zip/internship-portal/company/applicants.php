<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (
    !isset($_SESSION['user_id'], $_SESSION['role']) ||
    !in_array(strtolower((string) $_SESSION['role']), ['company', 'recruiter'], true)
) {
    header('Location: ../login.php');
    exit;
}

require_once __DIR__ . '/../config/database.php';

if (!isset($pdo) || !($pdo instanceof PDO)) {
    http_response_code(500);
    exit('Database connection is not configured correctly.');
}

$userId = (int) $_SESSION['user_id'];
$companyId = null;
$companyName = $_SESSION['company_name'] ?? $_SESSION['name'] ?? 'Company';
$applicants = [];
$errors = [];
$search = trim((string) ($_GET['q'] ?? ''));
$filterStatus = strtolower(trim((string) ($_GET['status'] ?? 'all')));
$flashMessage = $_SESSION['internpro_applicants_flash'] ?? '';
unset($_SESSION['internpro_applicants_flash']);

if (empty($_SESSION['internpro_applicants_csrf'])) {
    $_SESSION['internpro_applicants_csrf'] = bin2hex(random_bytes(32));
}

function h($value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function applicantColumns(PDO $pdo, string $table): array
{
    $allowed = ['companies', 'users', 'students', 'student_profiles', 'internships', 'applications'];

    if (!in_array($table, $allowed, true)) {
        return [];
    }

    try {
        $stmt = $pdo->query("SHOW COLUMNS FROM `$table`");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        return [];
    }
}

function applicantColumn(array $columns, array $candidates): ?string
{
    $names = array_column($columns, 'Field');

    foreach ($candidates as $candidate) {
        if (in_array($candidate, $names, true)) {
            return $candidate;
        }
    }

    return null;
}

function applicantStatusClass(string $status): string
{
    $status = strtolower(trim($status));

    if (in_array($status, ['selected', 'shortlisted'], true)) {
        return 'status-success';
    }

    if ($status === 'interview') {
        return 'status-interview';
    }

    if (in_array($status, ['rejected', 'withdrawn'], true)) {
        return 'status-danger';
    }

    if (in_array($status, ['under review', 'under_review', 'reviewing'], true)) {
        return 'status-review';
    }

    return 'status-applied';
}

function applicantStatusLabel(string $status): string
{
    return ucwords(str_replace(['_', '-'], ' ', trim($status)));
}

function applicantDate($value): string
{
    if (!$value) {
        return 'Date unavailable';
    }

    try {
        return (new DateTime((string) $value))->format('d M Y');
    } catch (Throwable $e) {
        return (string) $value;
    }
}

function safeIdentifier(string $name): string
{
    return '`' . str_replace('`', '``', $name) . '`';
}

try {
    $companyColumns = applicantColumns($pdo, 'companies');

    if (
        in_array('id', array_column($companyColumns, 'Field'), true) &&
        in_array('user_id', array_column($companyColumns, 'Field'), true)
    ) {
        $stmt = $pdo->prepare(
            'SELECT * FROM companies WHERE user_id = :user_id LIMIT 1'
        );
        $stmt->execute(['user_id' => $userId]);
        $company = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($company) {
            $companyId = (int) $company['id'];

            foreach (['company_name', 'name', 'organization_name'] as $column) {
                if (!empty($company[$column])) {
                    $companyName = $company[$column];
                    break;
                }
            }
        }
    }

    if (!$companyId) {
        $errors[] = 'Your account does not have a linked company profile. Please check the companies table and your account mapping.';
    }

    $applicationColumns = applicantColumns($pdo, 'applications');
    $internshipColumns = applicantColumns($pdo, 'internships');
    $studentColumns = applicantColumns($pdo, 'students');
    $userColumns = applicantColumns($pdo, 'users');
    $profileColumns = applicantColumns($pdo, 'student_profiles');

    $applicationId = applicantColumn($applicationColumns, ['id']);
    $applicationStudentId = applicantColumn($applicationColumns, ['student_id']);
    $applicationInternshipId = applicantColumn($applicationColumns, ['internship_id']);
    $applicationStatus = applicantColumn($applicationColumns, ['status', 'application_status']);
    $applicationDate = applicantColumn($applicationColumns, ['created_at', 'applied_at', 'application_date']);
    $resumeColumn = applicantColumn($applicationColumns, ['resume_path', 'resume', 'cv_path']);
    $coverLetterColumn = applicantColumn($applicationColumns, ['cover_letter', 'message', 'application_message']);

    $internshipId = applicantColumn($internshipColumns, ['id']);
    $internshipCompanyId = applicantColumn($internshipColumns, ['company_id', 'employer_id']);
    $internshipTitle = applicantColumn($internshipColumns, ['title', 'internship_title', 'position']);

    $studentId = applicantColumn($studentColumns, ['id']);
    $studentUserId = applicantColumn($studentColumns, ['user_id']);
    $studentName = applicantColumn($studentColumns, ['name', 'full_name', 'student_name']);
    $studentEmail = applicantColumn($studentColumns, ['email']);
    $studentPhone = applicantColumn($studentColumns, ['phone', 'phone_number', 'mobile']);

    $userIdColumn = applicantColumn($userColumns, ['id']);
    $userName = applicantColumn($userColumns, ['name', 'full_name']);
    $userEmail = applicantColumn($userColumns, ['email']);

    $profileStudentId = applicantColumn($profileColumns, ['student_id', 'user_id']);
    $profileSkills = applicantColumn($profileColumns, ['skills', 'skill_set', 'technical_skills']);
    $profileLinkedIn = applicantColumn($profileColumns, ['linkedin_url', 'linkedin']);
    $profileGitHub = applicantColumn($profileColumns, ['github_url', 'github']);
    $profilePortfolio = applicantColumn($profileColumns, ['portfolio_url', 'portfolio', 'website']);

    $allowedStatuses = [
        'applied' => 'Applied',
        'under review' => 'Under Review',
        'shortlisted' => 'Shortlisted',
        'interview' => 'Interview',
        'selected' => 'Selected',
        'rejected' => 'Rejected',
    ];

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $postedToken = $_POST['csrf_token'] ?? '';

        if (
            !is_string($postedToken) ||
            !hash_equals($_SESSION['internpro_applicants_csrf'], $postedToken)
        ) {
            $errors[] = 'Your session token has expired. Refresh the page and try again.';
        } elseif (!$companyId) {
            $errors[] = 'Your company profile could not be verified.';
        } elseif (!$applicationId || !$applicationStudentId || !$applicationInternshipId || !$applicationStatus || !$internshipId || !$internshipCompanyId) {
            $errors[] = 'Your database is missing required application relationship or status columns.';
        } else {
            $postedApplicationId = filter_var(
                $_POST['application_id'] ?? null,
                FILTER_VALIDATE_INT
            );

            $newStatus = strtolower(trim((string) ($_POST['new_status'] ?? '')));

            if (!$postedApplicationId || !isset($allowedStatuses[$newStatus])) {
                $errors[] = 'Please select a valid application and status.';
            } else {
                try {
                    $checkSql = 'SELECT a.' . safeIdentifier($applicationId) .
                        ' FROM applications a INNER JOIN internships i ON a.' .
                        safeIdentifier($applicationInternshipId) . ' = i.' .
                        safeIdentifier($internshipId) .
                        ' WHERE a.' . safeIdentifier($applicationId) . ' = :application_id' .
                        ' AND i.' . safeIdentifier($internshipCompanyId) . ' = :company_id LIMIT 1';

                    $check = $pdo->prepare($checkSql);
                    $check->execute([
                        'application_id' => $postedApplicationId,
                        'company_id' => $companyId,
                    ]);

                    if (!$check->fetchColumn()) {
                        $errors[] = 'This application was not found under your company.';
                    } else {
                        $updateSql = 'UPDATE applications a INNER JOIN internships i ON a.' .
                            safeIdentifier($applicationInternshipId) . ' = i.' .
                            safeIdentifier($internshipId) .
                            ' SET a.' . safeIdentifier($applicationStatus) . ' = :new_status' .
                            ' WHERE a.' . safeIdentifier($applicationId) . ' = :application_id' .
                            ' AND i.' . safeIdentifier($internshipCompanyId) . ' = :company_id';

                        $update = $pdo->prepare($updateSql);
                        $update->execute([
                            'new_status' => $allowedStatuses[$newStatus],
                            'application_id' => $postedApplicationId,
                            'company_id' => $companyId,
                        ]);

                        $_SESSION['internpro_applicants_csrf'] = bin2hex(random_bytes(32));
                        $_SESSION['internpro_applicants_flash'] = 'Application status updated successfully.';

                        header('Location: applicants.php?updated=1');
                        exit;
                    }
                } catch (Throwable $e) {
                    error_log('InternPro applicant status update: ' . $e->getMessage());
                    $errors[] = 'The status could not be updated. Check whether your database accepts the selected status values.';
                }
            }
        }
    }

    if (
        $companyId &&
        $applicationId &&
        $applicationStudentId &&
        $applicationInternshipId &&
        $applicationStatus &&
        $internshipId &&
        $internshipCompanyId
    ) {
        $select = [
            'a.' . safeIdentifier($applicationId) . ' AS application_id',
            'a.' . safeIdentifier($applicationStatus) . ' AS application_status',
            'i.' . safeIdentifier($internshipId) . ' AS internship_id',
        ];

        if ($applicationDate) {
            $select[] = 'a.' . safeIdentifier($applicationDate) . ' AS applied_date';
        } else {
            $select[] = 'NULL AS applied_date';
        }

        if ($internshipTitle) {
            $select[] = 'i.' . safeIdentifier($internshipTitle) . ' AS internship_title';
        } else {
            $select[] = "'Internship' AS internship_title";
        }

        if ($resumeColumn) {
            $select[] = 'a.' . safeIdentifier($resumeColumn) . ' AS resume_path';
        } else {
            $select[] = 'NULL AS resume_path';
        }

        if ($coverLetterColumn) {
            $select[] = 'a.' . safeIdentifier($coverLetterColumn) . ' AS cover_letter';
        } else {
            $select[] = 'NULL AS cover_letter';
        }

        $studentJoin = '';
        $nameSelect = "'Student applicant' AS applicant_name";
        $emailSelect = "'' AS applicant_email";
        $phoneSelect = "'' AS applicant_phone";

        if ($studentId) {
            $studentJoin = ' LEFT JOIN students s ON a.' .
                safeIdentifier($applicationStudentId) . ' = s.' .
                safeIdentifier($studentId);

            if ($studentName) {
                $nameSelect = 's.' . safeIdentifier($studentName) . ' AS applicant_name';
            }

            if ($studentEmail) {
                $emailSelect = 's.' . safeIdentifier($studentEmail) . ' AS applicant_email';
            }

            if ($studentPhone) {
                $phoneSelect = 's.' . safeIdentifier($studentPhone) . ' AS applicant_phone';
            }

            if ($studentUserId && $userIdColumn && $userName) {
                $studentJoin .= ' LEFT JOIN users u ON s.' .
                    safeIdentifier($studentUserId) . ' = u.' .
                    safeIdentifier($userIdColumn);

                if (!$studentName) {
                    $nameSelect = 'u.' . safeIdentifier($userName) . ' AS applicant_name';
                }

                if (!$studentEmail && $userEmail) {
                    $emailSelect = 'u.' . safeIdentifier($userEmail) . ' AS applicant_email';
                }
            }
        }

        $profileJoin = '';

        if ($profileStudentId && $studentId) {
            $profileJoin = ' LEFT JOIN student_profiles sp ON sp.' .
                safeIdentifier($profileStudentId) . ' = s.' .
                safeIdentifier($studentId);
        } elseif ($profileStudentId && $studentUserId) {
            $profileJoin = ' LEFT JOIN student_profiles sp ON sp.' .
                safeIdentifier($profileStudentId) . ' = s.' .
                safeIdentifier($studentUserId);
        }

        $skillsSelect = $profileJoin && $profileSkills
            ? 'sp.' . safeIdentifier($profileSkills) . ' AS applicant_skills'
            : "'' AS applicant_skills";

        $linkedinSelect = $profileJoin && $profileLinkedIn
            ? 'sp.' . safeIdentifier($profileLinkedIn) . ' AS linkedin_url'
            : "'' AS linkedin_url";

        $githubSelect = $profileJoin && $profileGitHub
            ? 'sp.' . safeIdentifier($profileGitHub) . ' AS github_url'
            : "'' AS github_url";

        $portfolioSelect = $profileJoin && $profilePortfolio
            ? 'sp.' . safeIdentifier($profilePortfolio) . ' AS portfolio_url'
            : "'' AS portfolio_url";

        $sql = 'SELECT ' . implode(', ', $select) . ', ' .
            $nameSelect . ', ' . $emailSelect . ', ' . $phoneSelect . ', ' .
            $skillsSelect . ', ' . $linkedinSelect . ', ' . $githubSelect . ', ' .
            $portfolioSelect .
            ' FROM applications a INNER JOIN internships i ON a.' .
            safeIdentifier($applicationInternshipId) . ' = i.' .
            safeIdentifier($internshipId) .
            $studentJoin . $profileJoin .
            ' WHERE i.' . safeIdentifier($internshipCompanyId) . ' = :company_id';

        $params = ['company_id' => $companyId];

        if ($search !== '') {
            $searchConditions = [];

            foreach ([
                'applicant_name',
                'applicant_email',
                'internship_title',
                'applicant_skills',
            ] as $field) {
                $searchConditions[] = "$field LIKE :search";
            }

            $sql .= ' AND (' . implode(' OR ', $searchConditions) . ')';
            $params['search'] = '%' . $search . '%';
        }

        if ($filterStatus !== '' && $filterStatus !== 'all') {
            $sql .= ' AND LOWER(REPLACE(a.' . safeIdentifier($applicationStatus) .
                ", '_', ' ')) = :filter_status";
            $params['filter_status'] = $filterStatus;
        }

        $sql .= $applicationDate
            ? ' ORDER BY a.' . safeIdentifier($applicationDate) . ' DESC'
            : ' ORDER BY a.' . safeIdentifier($applicationId) . ' DESC';

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $applicants = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (Throwable $e) {
    error_log('InternPro applicants page: ' . $e->getMessage());
    $errors[] = 'Applicants could not be loaded. Please verify your database table structure and relationships.';
}

$counts = [
    'total' => 0,
    'review' => 0,
    'shortlisted' => 0,
    'interview' => 0,
];

foreach ($applicants as $applicant) {
    $status = strtolower(trim((string) ($applicant['application_status'] ?? 'applied')));
    $counts['total']++;

    if (in_array($status, ['under review', 'under_review', 'reviewing'], true)) {
        $counts['review']++;
    } elseif ($status === 'shortlisted') {
        $counts['shortlisted']++;
    } elseif ($status === 'interview') {
        $counts['interview']++;
    }
}

$firstName = preg_split('/\s+/', trim((string) $companyName))[0] ?? 'Company';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#070b18">
    <title>Applicants | InternPro</title>
    <link rel="icon" type="image/jpeg" href="../assets/logo.jpg">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg:#070b18;
            --panel:rgba(13,22,43,.86);
            --line:rgba(86,164,255,.18);
            --blue:#438bff;
            --cyan:#35e5ff;
            --text:#eef6ff;
            --muted:#8fa4c4;
            --green:#4df5bd;
            --red:#ff648b;
            --purple:#a98aff;
        }

        *{box-sizing:border-box}
        html{scroll-behavior:smooth}
        body{
            margin:0;
            min-height:100vh;
            overflow-x:hidden;
            color:var(--text);
            font-family:Inter,sans-serif;
            background:
                radial-gradient(ellipse at 8% 0%,rgba(36,105,232,.16),transparent 34%),
                radial-gradient(ellipse at 95% 45%,rgba(31,212,255,.08),transparent 32%),
                var(--bg)
        }
        body::before{
            content:"";
            position:fixed;
            inset:0;
            z-index:-1;
            pointer-events:none;
            opacity:.18;
            background-image:
                linear-gradient(rgba(74,143,255,.11) 1px,transparent 1px),
                linear-gradient(90deg,rgba(74,143,255,.11) 1px,transparent 1px);
            background-size:48px 48px;
            mask-image:linear-gradient(to bottom,black,transparent 85%)
        }
        a{color:inherit;text-decoration:none}
        button,input,select{font:inherit}
        :focus-visible{outline:2px solid var(--cyan);outline-offset:4px}

        .ambient{
            position:fixed;
            width:300px;
            height:300px;
            border-radius:50%;
            filter:blur(90px);
            opacity:.13;
            pointer-events:none;
            z-index:-1;
            animation:ambientFloat 12s ease-in-out infinite alternate
        }
        .ambient.one{top:15%;left:-160px;background:#287bff}
        .ambient.two{right:-170px;bottom:4%;background:#00e5ff;animation-delay:-5s}
        .corner{position:fixed;width:28px;height:28px;z-index:20;pointer-events:none;opacity:.65}
        .corner::before,.corner::after{content:"";position:absolute;background:var(--cyan);box-shadow:0 0 12px rgba(53,229,255,.65)}
        .corner::before{width:25px;height:2px}
        .corner::after{width:2px;height:25px}
        .corner.tl{top:12px;left:12px}
        .corner.tr{top:12px;right:12px;transform:rotate(90deg)}
        .corner.bl{bottom:12px;left:12px;transform:rotate(-90deg)}
        .corner.br{bottom:12px;right:12px;transform:rotate(180deg)}

        .topbar{position:sticky;top:0;z-index:15;border-bottom:1px solid var(--line);background:rgba(7,11,24,.86);backdrop-filter:blur(20px)}
        .nav-inner{max-width:1440px;min-height:78px;margin:auto;padding:12px 34px;display:flex;align-items:center;justify-content:space-between;gap:24px}
        .brand{display:flex;align-items:center;gap:12px;min-width:170px}
        .brand img{width:45px;height:45px;object-fit:cover;border-radius:13px;border:1px solid rgba(53,229,255,.4);box-shadow:0 0 24px rgba(53,229,255,.13);transition:transform .35s,box-shadow .35s}
        .brand:hover img{transform:rotate(-5deg) scale(1.08);box-shadow:0 0 28px rgba(53,229,255,.35)}
        .brand-name{font:700 22px 'Space Grotesk',sans-serif;letter-spacing:-.8px}
        .brand-name span{color:var(--cyan)}
        .nav-links{display:flex;align-items:center;justify-content:center;flex-wrap:wrap;gap:7px}
        .nav-link{display:inline-flex;align-items:center;gap:8px;padding:11px 13px;border:1px solid transparent;border-radius:12px;color:var(--muted);font-size:13px;font-weight:600;transition:color .25s,background .25s,border-color .25s,transform .25s}
        .nav-icon{display:inline-block;transition:transform .3s,filter .3s}
        .nav-link:hover,.nav-link.active{color:var(--cyan);border-color:rgba(53,229,255,.18);background:rgba(53,229,255,.07);transform:translateY(-2px)}
        .nav-link:hover .nav-icon{transform:scale(1.2) rotate(-8deg);filter:drop-shadow(0 0 5px var(--cyan))}
        .nav-user{display:flex;align-items:center;gap:10px}
        .avatar{width:39px;height:39px;display:grid;place-items:center;border:1px solid rgba(53,229,255,.35);border-radius:13px;color:var(--cyan);font-weight:800;background:linear-gradient(135deg,rgba(67,139,255,.22),rgba(53,229,255,.08));transition:transform .3s,box-shadow .3s}
        .nav-user:hover .avatar{transform:rotate(5deg) scale(1.08);box-shadow:0 0 20px rgba(53,229,255,.2)}
        .user-name{max-width:145px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12px;font-weight:700}
        .user-caption{margin-top:3px;color:var(--muted);font-size:11px}

        .page{width:min(1372px,calc(100% - 68px));margin:0 auto;padding:38px 0 60px}
        .reveal{opacity:0;transform:translateY(18px);animation:reveal .65s cubic-bezier(.2,.75,.25,1) forwards}
        .delay-1{animation-delay:.08s}
        .delay-2{animation-delay:.16s}
        .delay-3{animation-delay:.24s}
        .eyebrow{display:inline-flex;align-items:center;gap:8px;color:var(--cyan);text-transform:uppercase;font-size:10px;font-weight:800;letter-spacing:2px}
        .pulse-dot{width:7px;height:7px;border-radius:50%;background:var(--green);box-shadow:0 0 12px var(--green);animation:pulse 1.8s ease-in-out infinite}
        .heading{display:flex;align-items:flex-end;justify-content:space-between;gap:20px;margin-bottom:26px}
        .heading h1{margin:13px 0 9px;font:700 clamp(28px,3vw,40px)/1.15 'Space Grotesk',sans-serif;letter-spacing:-1.4px}
        .heading h1 span{color:var(--cyan);text-shadow:0 0 28px rgba(53,229,255,.18)}
        .heading p{max-width:640px;margin:0;color:var(--muted);font-size:13px;line-height:1.8}
        .btn{display:inline-flex;align-items:center;justify-content:center;gap:9px;min-height:44px;padding:12px 16px;border:1px solid transparent;border-radius:12px;cursor:pointer;font-size:11px;font-weight:800;transition:transform .25s,box-shadow .25s,background .25s,border-color .25s,color .25s}
        .btn-icon{display:inline-block;transition:transform .3s}
        .btn-primary{color:#04121e;background:linear-gradient(115deg,var(--cyan),#6ba6ff);box-shadow:0 7px 24px rgba(53,229,255,.16)}
        .btn-primary:hover{transform:translateY(-3px);box-shadow:0 12px 30px rgba(53,229,255,.2)}
        .btn-primary:hover .btn-icon{transform:rotate(-10deg) scale(1.2)}

        .stats-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:16px}
        .stat-card{position:relative;overflow:hidden;min-height:137px;padding:21px;border:1px solid var(--line);border-radius:20px;background:linear-gradient(145deg,rgba(17,30,55,.91),rgba(10,18,35,.9));transition:transform .3s,border-color .3s,box-shadow .3s}
        .stat-card::before{content:"";position:absolute;top:0;left:15%;width:70%;height:1px;background:linear-gradient(90deg,transparent,var(--accent,var(--cyan)),transparent);opacity:.6}
        .stat-card::after{content:"";position:absolute;right:-45px;bottom:-55px;width:125px;height:125px;border-radius:50%;background:var(--glow,rgba(53,229,255,.13));filter:blur(40px);transition:transform .4s}
        .stat-card:hover{transform:translateY(-6px);border-color:rgba(53,229,255,.4);box-shadow:0 18px 38px rgba(0,0,0,.17)}
        .stat-card:hover::after{transform:scale(1.4)}
        .stat-top{display:flex;align-items:center;justify-content:space-between;gap:10px}
        .stat-icon{width:40px;height:40px;display:grid;place-items:center;border:1px solid rgba(53,229,255,.18);border-radius:13px;color:var(--accent,var(--cyan));background:rgba(53,229,255,.07);font-size:19px;transition:transform .3s,box-shadow .3s}
        .stat-card:hover .stat-icon{transform:rotate(-8deg) scale(1.12);box-shadow:0 0 20px var(--glow,rgba(53,229,255,.14))}
        .stat-caption{color:var(--muted);font-size:10px}
        .stat-number{position:relative;z-index:1;margin-top:15px;font:700 28px 'Space Grotesk',sans-serif}
        .stat-label{position:relative;z-index:1;margin-top:4px;color:var(--muted);font-size:11px}

        .toolbar{display:flex;align-items:center;justify-content:space-between;gap:15px;flex-wrap:wrap;margin:26px 0 18px;padding:17px;border:1px solid var(--line);border-radius:18px;background:rgba(13,22,43,.72)}
        .toolbar-title{font:700 16px 'Space Grotesk',sans-serif}
        .toolbar-subtitle{margin-top:5px;color:var(--muted);font-size:11px}
        .filters{display:flex;align-items:center;justify-content:flex-end;gap:10px;flex-wrap:wrap}
        .search-box{display:flex;align-items:center;gap:9px;min-width:220px;padding:0 13px;border:1px solid rgba(86,164,255,.2);border-radius:11px;background:rgba(4,12,27,.6);transition:border-color .25s,box-shadow .25s}
        .search-box:focus-within{border-color:var(--cyan);box-shadow:0 0 0 3px rgba(53,229,255,.06)}
        .search-symbol{color:var(--cyan);transition:transform .25s}
        .search-box:focus-within .search-symbol{transform:scale(1.15)}
        .search-box input{width:100%;min-height:42px;color:var(--text);background:transparent;border:0;outline:0;font-size:11px}
        .search-box input::placeholder{color:#6e82a1}
        .filter-select{min-height:44px;padding:0 30px 0 12px;color:var(--text);border:1px solid rgba(86,164,255,.2);border-radius:11px;background:#0b152a;font-size:11px;cursor:pointer}
        .filter-select option{background:#0b152a;color:var(--text)}
        .filter-submit{min-height:44px;padding:0 15px;color:var(--cyan);border:1px solid rgba(53,229,255,.24);border-radius:11px;background:rgba(53,229,255,.06);font-size:11px;font-weight:800;cursor:pointer;transition:transform .25s,background .25s,box-shadow .25s}
        .filter-submit:hover{transform:translateY(-2px);background:rgba(53,229,255,.12);box-shadow:0 8px 22px rgba(53,229,255,.08)}

        .notice{margin-bottom:18px;padding:14px 17px;border:1px solid rgba(77,245,189,.23);border-radius:12px;background:rgba(77,245,189,.06);color:#a8f6d8;font-size:12px;line-height:1.7}
        .error-box{margin-bottom:18px;padding:14px 17px;border:1px solid rgba(255,100,139,.25);border-radius:12px;background:rgba(255,100,139,.06);color:#ffb4c8;font-size:12px;line-height:1.8}
        .error-box ul{margin:5px 0 0;padding-left:20px}
        .results-line{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:0 2px 15px;color:var(--muted);font-size:11px}
        .results-line strong{color:var(--text)}
        .text-link{color:var(--cyan);font-size:11px;font-weight:800;transition:color .25s,transform .25s}
        .text-link:hover{color:white;transform:translateX(3px)}

        .applicant-list{display:grid;gap:15px}
        .applicant-card{position:relative;overflow:hidden;padding:22px;border:1px solid var(--line);border-radius:20px;background:linear-gradient(145deg,rgba(15,26,48,.94),rgba(9,16,31,.93));transition:transform .3s,border-color .3s,box-shadow .3s}
        .applicant-card::before{content:"";position:absolute;top:0;left:12%;width:76%;height:1px;background:linear-gradient(90deg,transparent,var(--cyan),transparent);opacity:.35;transition:opacity .3s}
        .applicant-card:hover{transform:translateY(-4px);border-color:rgba(53,229,255,.35);box-shadow:0 18px 42px rgba(0,0,0,.16)}
        .applicant-card:hover::before{opacity:1}
        .applicant-main{display:flex;align-items:flex-start;gap:15px}
        .candidate-avatar{flex:0 0 49px;height:49px;display:grid;place-items:center;border:1px solid rgba(53,229,255,.25);border-radius:15px;color:var(--cyan);background:linear-gradient(135deg,rgba(67,139,255,.17),rgba(53,229,255,.07));font:700 18px 'Space Grotesk',sans-serif;transition:transform .3s,box-shadow .3s}
        .applicant-card:hover .candidate-avatar{transform:rotate(-6deg) scale(1.08);box-shadow:0 0 19px rgba(53,229,255,.12)}
        .candidate-details{flex:1;min-width:0}
        .candidate-name{margin:0 0 6px;font:700 17px 'Space Grotesk',sans-serif;overflow-wrap:anywhere}
        .candidate-email{color:var(--muted);font-size:11px;overflow-wrap:anywhere}
        .candidate-contact{display:flex;flex-wrap:wrap;gap:12px;margin-top:8px;color:#8fa4c4;font-size:10px}
        .candidate-contact span{display:inline-flex;align-items:center;gap:6px}
        .candidate-contact b{color:var(--cyan);font-weight:600}
        .applicant-side{display:flex;flex-direction:column;align-items:flex-end;gap:10px}
        .status{display:inline-flex;align-items:center;gap:6px;padding:7px 9px;border:1px solid transparent;border-radius:9px;font-size:9px;font-weight:800;white-space:nowrap}
        .status::before{content:"";width:5px;height:5px;border-radius:50%;background:currentColor}
        .status-success{color:var(--green);background:rgba(77,245,189,.07);border-color:rgba(77,245,189,.16)}
        .status-interview{color:var(--purple);background:rgba(169,138,255,.08);border-color:rgba(169,138,255,.17)}
        .status-danger{color:var(--red);background:rgba(255,100,139,.07);border-color:rgba(255,100,139,.16)}
        .status-review{color:#91b1ff;background:rgba(67,139,255,.08);border-color:rgba(67,139,255,.17)}
        .status-applied{color:var(--cyan);background:rgba(53,229,255,.06);border-color:rgba(53,229,255,.15)}
        .status-neutral{color:#c5d3e7;background:rgba(197,211,231,.06);border-color:rgba(197,211,231,.12)}
        .applied-date{color:var(--muted);font-size:10px}
        .card-divider{height:1px;margin:19px 0;background:rgba(86,164,255,.11)}
        .internship-label{color:var(--muted);font-size:10px}
        .internship-value{margin-top:6px;color:#dfeeff;font-size:12px;font-weight:700;overflow-wrap:anywhere}
        .skills-label{margin-top:15px;color:var(--muted);font-size:10px}
        .skills-list{display:flex;flex-wrap:wrap;gap:7px;margin-top:8px}
        .skill-chip{padding:6px 9px;border:1px solid rgba(86,164,255,.14);border-radius:8px;color:#b8cce7;background:rgba(255,255,255,.02);font-size:10px;overflow-wrap:anywhere;transition:background .25s,border-color .25s}
        .skill-chip:hover{background:rgba(53,229,255,.05);border-color:rgba(53,229,255,.25)}
        .profile-links{display:flex;flex-wrap:wrap;gap:13px;margin-top:13px}
        .profile-link{display:inline-flex;align-items:center;gap:6px;color:var(--cyan);font-size:10px;font-weight:700;overflow-wrap:anywhere;transition:color .2s,transform .2s}
        .profile-link:hover{color:white;transform:translateY(-2px)}
        .cover-letter{margin-top:15px;padding:13px 15px;border:1px solid rgba(86,164,255,.12);border-radius:12px;background:rgba(255,255,255,.018)}
        .cover-letter summary{color:#d8e7fa;font-size:11px;font-weight:800;cursor:pointer}
        .cover-letter summary::marker{color:var(--cyan)}
        .cover-letter p{margin:12px 0 0;color:var(--muted);font-size:11px;line-height:1.8;white-space:pre-wrap;overflow-wrap:anywhere}
        .card-actions{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-top:17px}
        .action-links{display:flex;flex-wrap:wrap;gap:9px}
        .outline-link{display:inline-flex;align-items:center;gap:7px;min-height:36px;padding:9px 12px;border:1px solid rgba(86,164,255,.18);border-radius:10px;color:#c9dbf2;background:rgba(255,255,255,.02);font-size:10px;font-weight:800;transition:transform .25s,border-color .25s,color .25s,box-shadow .25s}
        .outline-link:hover{transform:translateY(-2px);border-color:rgba(53,229,255,.4);color:var(--cyan);box-shadow:0 6px 18px rgba(53,229,255,.05)}
        .status-form{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
        .status-form select{min-height:38px;max-width:180px;padding:0 28px 0 10px;border:1px solid rgba(86,164,255,.2);border-radius:10px;color:var(--text);background:#0b152a;font-size:10px}
        .status-form select option{background:#0b152a;color:var(--text)}
        .status-form button{min-height:38px;padding:0 12px;border:1px solid rgba(53,229,255,.22);border-radius:10px;color:var(--cyan);background:rgba(53,229,255,.06);font-size:10px;font-weight:800;cursor:pointer;transition:transform .25s,background .25s,box-shadow .25s}
        .status-form button:hover{transform:translateY(-2px);background:rgba(53,229,255,.12);box-shadow:0 7px 20px rgba(53,229,255,.08)}
        .status-form button:disabled{opacity:.6;cursor:wait}
        .empty-state{padding:55px 22px;text-align:center;border:1px dashed rgba(86,164,255,.25);border-radius:22px;background:rgba(13,22,43,.45)}
        .empty-icon{display:inline-grid;place-items:center;width:65px;height:65px;margin-bottom:17px;border:1px solid rgba(53,229,255,.2);border-radius:20px;color:var(--cyan);background:rgba(53,229,255,.06);font-size:28px;transition:transform .35s,box-shadow .35s}
        .empty-state:hover .empty-icon{transform:translateY(-5px) rotate(7deg);box-shadow:0 0 25px rgba(53,229,255,.13)}
        .empty-state h2{margin:0;font:700 21px 'Space Grotesk',sans-serif}
        .empty-state p{max-width:460px;margin:10px auto 21px;color:var(--muted);font-size:12px;line-height:1.8}
        footer{display:flex;justify-content:space-between;gap:16px;margin-top:35px;padding-top:20px;border-top:1px solid rgba(86,164,255,.12);color:#667c9d;font-size:10px}
        footer span{transition:color .25s}
        footer span:hover{color:var(--cyan)}

        @keyframes reveal{to{opacity:1;transform:translateY(0)}}
        @keyframes pulse{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.55;transform:scale(.75)}}
        @keyframes ambientFloat{from{transform:translate(0,0) scale(1)}to{transform:translate(45px,-35px) scale(1.12)}}

        @media(max-width:1150px){
            .nav-inner{padding:12px 24px;flex-wrap:wrap}
            .brand{min-width:auto}
            .nav-links{order:3;width:100%;justify-content:flex-start;overflow-x:auto;padding-bottom:3px}
            .page{width:calc(100% - 48px)}
        }
        @media(max-width:800px){
            .page{width:calc(100% - 32px);padding-top:27px}
            .heading{align-items:flex-start;flex-direction:column}
            .stats-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
            .toolbar{align-items:flex-start}
            .filters{width:100%;justify-content:flex-start}
            .search-box{flex:1 1 210px}
            .applicant-main{flex-wrap:wrap}
            .applicant-side{flex-direction:row;align-items:center;justify-content:space-between;width:100%}
            .card-actions{align-items:flex-start;flex-direction:column}
            .status-form{width:100%}
        }
        @media(max-width:540px){
            .nav-inner{padding:12px 18px;gap:12px}
            .brand img{width:38px;height:38px}
            .brand-name{font-size:19px}
            .nav-user .user-details{display:none}
            .nav-link{padding:10px 11px;font-size:11px}
            .heading h1{font-size:32px}
            .stats-grid{gap:10px}
            .stat-card{padding:15px;min-height:126px}
            .stat-number{font-size:25px}
            .toolbar{padding:14px}
            .filters{display:grid;grid-template-columns:1fr 1fr}
            .search-box{grid-column:1/-1;min-width:0}
            .filter-select,.filter-submit{width:100%}
            .applicant-card{padding:17px}
            .candidate-name{font-size:15px}
            .status-form{display:grid;grid-template-columns:1fr auto}
            .status-form select{max-width:none;width:100%}
            .action-links{width:100%}
            .outline-link{flex:1;justify-content:center}
            footer{flex-direction:column}
            .corner{opacity:.35}
        }
        @media(prefers-reduced-motion:reduce){
            *,*::before,*::after{scroll-behavior:auto!important;animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}
            .reveal{opacity:1;transform:none}
        }
    </style>
</head>
<body>
    <div class="ambient one" aria-hidden="true"></div>
    <div class="ambient two" aria-hidden="true"></div>
    <div class="corner tl" aria-hidden="true"></div>
    <div class="corner tr" aria-hidden="true"></div>
    <div class="corner bl" aria-hidden="true"></div>
    <div class="corner br" aria-hidden="true"></div>

    <header class="topbar">
        <div class="nav-inner">
            <a class="brand" href="dashboard.php" aria-label="InternPro company dashboard">
                <img src="../assets/logo.jpg" alt="InternPro logo">
                <span class="brand-name">Intern<span>Pro</span></span>
            </a>

            <nav class="nav-links" aria-label="Company navigation">
                <a class="nav-link" href="dashboard.php"><span class="nav-icon">⌂</span> Dashboard</a>
                <a class="nav-link" href="internships.php"><span class="nav-icon">▤</span> My Internships</a>
                <a class="nav-link" href="add_internship.php"><span class="nav-icon">＋</span> Post Internship</a>
                <a class="nav-link active" href="applicants.php" aria-current="page"><span class="nav-icon">♙</span> Applicants</a>
            </nav>

            <div class="nav-user">
                <div class="avatar" aria-hidden="true"><?= h(strtoupper(substr((string) $firstName, 0, 1))) ?></div>
                <div class="user-details">
                    <div class="user-name"><?= h($companyName) ?></div>
                    <div class="user-caption">Company workspace</div>
                </div>
            </div>
        </div>
    </header>

    <main class="page">
        <section class="heading reveal">
            <div>
                <div class="eyebrow"><span class="pulse-dot"></span> TALENT MANAGEMENT</div>
                <h1>Candidate <span>Hub</span></h1>
                <p>Discover promising candidates, review their applications, and move the right people through your hiring process.</p>
            </div>
            <a class="btn btn-primary" href="internships.php">
                <span class="btn-icon">▤</span> Manage internships
            </a>
        </section>

        <?php if ($flashMessage !== ''): ?>
            <div class="notice reveal" role="status"><?= h($flashMessage) ?></div>
        <?php endif; ?>

        <?php if ($errors): ?>
            <div class="error-box reveal" role="alert">
                <strong>Something needs attention:</strong>
                <ul>
                    <?php foreach (array_unique($errors) as $error): ?>
                        <li><?= h($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <section class="stats-grid reveal delay-1" aria-label="Applicant overview">
            <article class="stat-card" style="--accent:#35e5ff;--glow:rgba(53,229,255,.14)">
                <div class="stat-top">
                    <span class="stat-icon" aria-hidden="true">♙</span>
                    <span class="stat-caption">CANDIDATES</span>
                </div>
                <div class="stat-number"><?= number_format($counts['total']) ?></div>
                <div class="stat-label">Matching applications</div>
            </article>

            <article class="stat-card" style="--accent:#91b1ff;--glow:rgba(67,139,255,.14)">
                <div class="stat-top">
                    <span class="stat-icon" aria-hidden="true">◷</span>
                    <span class="stat-caption">IN PROGRESS</span>
                </div>
                <div class="stat-number"><?= number_format($counts['review']) ?></div>
                <div class="stat-label">Under review</div>
            </article>

            <article class="stat-card" style="--accent:#4df5bd;--glow:rgba(77,245,189,.14)">
                <div class="stat-top">
                    <span class="stat-icon" aria-hidden="true">✧</span>
                    <span class="stat-caption">TOP PICKS</span>
                </div>
                <div class="stat-number"><?= number_format($counts['shortlisted']) ?></div>
                <div class="stat-label">Shortlisted</div>
            </article>

            <article class="stat-card" style="--accent:#a98aff;--glow:rgba(169,138,255,.14)">
                <div class="stat-top">
                    <span class="stat-icon" aria-hidden="true">◉</span>
                    <span class="stat-caption">NEXT STAGE</span>
                </div>
                <div class="stat-number"><?= number_format($counts['interview']) ?></div>
                <div class="stat-label">Interview stage</div>
            </article>
        </section>

        <section class="toolbar reveal delay-2" aria-label="Search and filter applicants">
            <div>
                <div class="toolbar-title">Applicant directory</div>
                <div class="toolbar-subtitle">Search candidates and review their current status.</div>
            </div>

            <form class="filters" method="get" action="applicants.php">
                <label class="search-box">
                    <span class="search-symbol" aria-hidden="true">⌕</span>
                    <input type="search" name="q" value="<?= h($search) ?>" placeholder="Search candidate, email, skills..." aria-label="Search applicants">
                </label>

                <select class="filter-select" name="status" aria-label="Filter applicants by status">
                    <option value="all" <?= $filterStatus === 'all' ? 'selected' : '' ?>>All statuses</option>
                    <option value="applied" <?= $filterStatus === 'applied' ? 'selected' : '' ?>>Applied</option>
                    <option value="under review" <?= $filterStatus === 'under review' ? 'selected' : '' ?>>Under Review</option>
                    <option value="shortlisted" <?= $filterStatus === 'shortlisted' ? 'selected' : '' ?>>Shortlisted</option>
                    <option value="interview" <?= $filterStatus === 'interview' ? 'selected' : '' ?>>Interview</option>
                    <option value="selected" <?= $filterStatus === 'selected' ? 'selected' : '' ?>>Selected</option>
                    <option value="rejected" <?= $filterStatus === 'rejected' ? 'selected' : '' ?>>Rejected</option>
                </select>

                <button class="filter-submit" type="submit">⌕ Filter</button>
            </form>
        </section>

        <section class="reveal delay-3" aria-label="Applicant results">
            <div class="results-line">
                <span>Showing <strong><?= count($applicants) ?></strong> applicants</span>
                <?php if ($search !== '' || $filterStatus !== 'all'): ?>
                    <a class="text-link" href="applicants.php">Clear filters ↻</a>
                <?php endif; ?>
            </div>

            <?php if ($applicants): ?>
                <div class="applicant-list">
                    <?php foreach ($applicants as $applicant): ?>
                        <?php
                        $name = trim((string) ($applicant['applicant_name'] ?? 'Student applicant'));
                        $status = trim((string) ($applicant['application_status'] ?? 'Applied'));
                        $email = trim((string) ($applicant['applicant_email'] ?? ''));
                        $phone = trim((string) ($applicant['applicant_phone'] ?? ''));
                        $skills = trim((string) ($applicant['applicant_skills'] ?? ''));
                        $coverLetter = trim((string) ($applicant['cover_letter'] ?? ''));
                        $resumePath = trim((string) ($applicant['resume_path'] ?? ''));
                        $safeResumePath = '';

                        if (
                            $resumePath !== '' &&
                            !str_contains($resumePath, "\0") &&
                            !preg_match('/^[a-z][a-z0-9+.-]*:/i', $resumePath) &&
                            !str_starts_with($resumePath, '/') &&
                            !str_contains($resumePath, '..') &&
                            preg_match('/^[a-zA-Z0-9_\/.-]+$/', $resumePath)
                        ) {
                            $safeResumePath = '../' . ltrim($resumePath, '/');
                        }

                        $initial = strtoupper(substr($name !== '' ? $name : 'S', 0, 1));
                        $skillItems = preg_split('/[,;\n]+/', $skills) ?: [];
                        $skillItems = array_slice(array_filter(array_map('trim', $skillItems)), 0, 12);
                        ?>
                        <article class="applicant-card">
                            <div class="applicant-main">
                                <div class="candidate-avatar" aria-hidden="true"><?= h($initial) ?></div>

                                <div class="candidate-details">
                                    <h2 class="candidate-name"><?= h($name) ?></h2>
                                    <div class="candidate-email"><?= h($email !== '' ? $email : 'Email not available') ?></div>

                                    <div class="candidate-contact">
                                        <?php if ($phone !== ''): ?>
                                            <span><b aria-hidden="true">☎</b> <?= h($phone) ?></span>
                                        <?php endif; ?>
                                        <span><b aria-hidden="true">▤</b> Application #<?= (int) $applicant['application_id'] ?></span>
                                    </div>
                                </div>

                                <div class="applicant-side">
                                    <span class="status <?= h(applicantStatusClass($status)) ?>"><?= h(applicantStatusLabel($status)) ?></span>
                                    <span class="applied-date">Applied <?= h(applicantDate($applicant['applied_date'] ?? null)) ?></span>
                                </div>
                            </div>

                            <div class="card-divider"></div>

                            <div class="internship-label">APPLIED FOR</div>
                            <div class="internship-value"><?= h($applicant['internship_title'] ?? 'Internship') ?></div>

                            <?php if ($skillItems): ?>
                                <div class="skills-label">SKILLS</div>
                                <div class="skills-list">
                                    <?php foreach ($skillItems as $skill): ?>
                                        <span class="skill-chip"><?= h($skill) ?></span>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>

                            <?php
                            $profileUrls = [
                                'LinkedIn' => $applicant['linkedin_url'] ?? '',
                                'GitHub' => $applicant['github_url'] ?? '',
                                'Portfolio' => $applicant['portfolio_url'] ?? '',
                            ];
                            ?>

                            <?php if (array_filter($profileUrls, static fn($url) => is_string($url) && trim($url) !== '')): ?>
                                <div class="profile-links">
                                    <?php foreach ($profileUrls as $label => $url): ?>
                                        <?php
                                        $url = trim((string) $url);
                                        $parsedUrl = $url !== '' ? parse_url($url) : false;
                                        $scheme = is_array($parsedUrl) ? strtolower((string) ($parsedUrl['scheme'] ?? '')) : '';
                                        $validProfileUrl = $url !== '' && in_array($scheme, ['http', 'https'], true) && !empty($parsedUrl['host']);
                                        ?>
                                        <?php if ($validProfileUrl): ?>
                                            <a class="profile-link" href="<?= h($url) ?>" target="_blank" rel="noopener noreferrer">
                                                <span aria-hidden="true">↗</span> <?= h($label) ?>
                                            </a>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>

                            <?php if ($coverLetter !== ''): ?>
                                <details class="cover-letter">
                                    <summary>Read cover letter</summary>
                                    <p><?= h($coverLetter) ?></p>
                                </details>
                            <?php endif; ?>

                            <div class="card-actions">
                                <div class="action-links">
                                    <?php if ($safeResumePath !== ''): ?>
                                        <a class="outline-link" href="<?= h($safeResumePath) ?>" target="_blank" rel="noopener noreferrer">
                                            <span aria-hidden="true">↗</span> Open resume
                                        </a>
                                    <?php endif; ?>
                                    <?php if ($email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL)): ?>
                                        <a class="outline-link" href="mailto:<?= h($email) ?>">
                                            <span aria-hidden="true">✉</span> Contact candidate
                                        </a>
                                    <?php endif; ?>
                                </div>

                                <form class="status-form" method="post" action="applicants.php" data-application-id="<?= (int) $applicant['application_id'] ?>">
                                    <input type="hidden" name="csrf_token" value="<?= h($_SESSION['internpro_applicants_csrf']) ?>">
                                    <input type="hidden" name="application_id" value="<?= (int) $applicant['application_id'] ?>">

                                    <label for="status-<?= (int) $applicant['application_id'] ?>" style="position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0">New status</label>

                                    <select id="status-<?= (int) $applicant['application_id'] ?>" name="new_status" required>
                                        <?php foreach ([
                                            'applied' => 'Applied',
                                            'under review' => 'Under Review',
                                            'shortlisted' => 'Shortlisted',
                                            'interview' => 'Interview',
                                            'selected' => 'Selected',
                                            'rejected' => 'Rejected',
                                        ] as $value => $label): ?>
                                            <option value="<?= h($value) ?>" <?= strtolower(str_replace('_', ' ', $status)) === $value ? 'selected' : '' ?>><?= h($label) ?></option>
                                        <?php endforeach; ?>
                                    </select>

                                    <button type="submit">Update status <span aria-hidden="true">↗</span></button>
                                </form>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <div class="empty-icon" aria-hidden="true">♙</div>

                    <?php if ($search !== '' || $filterStatus !== 'all'): ?>
                        <h2>No matching applicants</h2>
                        <p>Try another search term or status filter. Applicants outside your current filters may still be available.</p>
                        <a class="btn btn-primary" href="applicants.php"><span class="btn-icon">↻</span> Reset filters</a>
                    <?php else: ?>
                        <h2>Your candidate pipeline starts here</h2>
                        <p>When students apply to internships posted by your company, their applications will appear here for review.</p>
                        <a class="btn btn-primary" href="internships.php"><span class="btn-icon">▤</span> View internships</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </section>

        <footer>
            <span>© <?= date('Y') ?> InternPro · Company workspace</span>
            <span>Built for talent. Designed for the future. <span style="color:var(--cyan)">◆</span></span>
        </footer>
    </main>

    <script>
        (() => {
            document.querySelectorAll('.status-form').forEach((form) => {
                form.addEventListener('submit', (event) => {
                    const select = form.querySelector('select[name="new_status"]');
                    const button = form.querySelector('button[type="submit"]');

                    if (!select || !button) {
                        return;
                    }

                    if (!select.value) {
                        event.preventDefault();
                        select.focus();
                        return;
                    }

                    const confirmed = window.confirm(
                        `Update this application to "${select.options[select.selectedIndex].text}"?`
                    );

                    if (!confirmed) {
                        event.preventDefault();
                        return;
                    }

                    button.disabled = true;
                    button.textContent = 'Updating...';
                });
            });
        })();
    </script>
</body>
</html>