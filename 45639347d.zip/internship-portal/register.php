<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . '/config/database.php';

$error = '';
$success = '';
$name = '';
$full_name = '';
$email = '';
$role = 'student';

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function e(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $submittedToken = $_POST['csrf_token'] ?? '';

    if (
        !is_string($submittedToken) ||
        !hash_equals($_SESSION['csrf_token'], $submittedToken)
    ) {
        http_response_code(400);
        $error = 'Your session has expired. Please refresh the page and try again.';
    } else {
        $name = trim((string) ($_POST['name'] ?? ''));
        $full_name = trim((string) ($_POST['full_name'] ?? ''));
        $email = strtolower(trim((string) ($_POST['email'] ?? '')));
        $password = (string) ($_POST['password'] ?? '');
        $confirm_password = (string) ($_POST['confirm_password'] ?? '');
        $role = (string) ($_POST['role'] ?? 'student');
        $terms = isset($_POST['terms']);

        // Support older forms that used "recruiter" as the company role.
        if ($role === 'recruiter') {
            $role = 'company';
        }

        if (!in_array($role, ['student', 'company'], true)) {
            $role = 'student';
        }

        if (
            $name === '' ||
            $full_name === '' ||
            $email === '' ||
            $password === '' ||
            $confirm_password === ''
        ) {
            $error = 'Please fill in all required fields.';
        } elseif (mb_strlen($full_name) > 100) {
            $error = 'Full name must not exceed 100 characters.';
        } elseif (!$terms) {
            $error = 'Please agree to the Terms of Service and Privacy Policy.';
        } elseif ($password !== $confirm_password) {
            $error = 'Passwords do not match.';
        } elseif (strlen($password) < 8) {
            $error = 'Password must contain at least 8 characters.';
        } elseif (!preg_match('/^[A-Za-z0-9_]{3,30}$/', $name)) {
            $error = 'Username must be 3–30 characters and contain only letters, numbers, or underscores.';
        } elseif (strlen($email) > 254 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Please enter a valid email address.';
        } else {
            try {
                $stmt = $pdo->prepare(
                    'SELECT id FROM users WHERE email = ? LIMIT 1'
                );
                $stmt->execute([$email]);

                if ($stmt->fetch(PDO::FETCH_ASSOC)) {
                    $error = 'Email is already registered.';
                } else {
                    $stmt = $pdo->prepare(
                        'SELECT id FROM users WHERE name = ? LIMIT 1'
                    );
                    $stmt->execute([$name]);

                    if ($stmt->fetch(PDO::FETCH_ASSOC)) {
                        $error = 'Username is already taken. Please choose another one.';
                    } else {
                        $hashedPassword = password_hash(
                            $password,
                            PASSWORD_DEFAULT
                        );

                        $stmt = $pdo->prepare(
                            'INSERT INTO users
                                (name, full_name, email, password, role, created_at)
                             VALUES (?, ?, ?, ?, ?, NOW())'
                        );

                        $stmt->execute([
                            $name,
                            $full_name,
                            $email,
                            $hashedPassword,
                            $role
                        ]);

                        $success = 'Registration successful!';

                        $name = '';
                        $full_name = '';
                        $email = '';
                        $role = 'student';

                        // Rotate the token after successful registration.
                        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                    }
                }
            } catch (PDOException $exception) {
                error_log(
                    'InternPro registration database error: ' .
                    $exception->getMessage()
                );
                $error = 'We could not complete your registration. Please try again.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#071E3D">
    <meta name="description" content="Create your InternPro account and start your internship journey.">

    <title>Create Account | InternPro</title>

    <link rel="icon" type="image/jpeg" href="assets/logo.jpg">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        :root {
            --navy: #071E3D;
            --navy-light: #0D3B66;
            --primary: #00B4D8;
            --primary-dark: #0077B6;
            --primary-hover: #0096C7;
            --bright-blue: #38BDF8;
            --white: #FFFFFF;
            --text: #E2E8F0;
            --muted: #94A3B8;
            --border: rgba(255,255,255,.12);
            --glass: rgba(255,255,255,.055);
            --success: #10B981;
            --success-light: #34D399;
            --error: #EF4444;
            --radius: 20px;
            --ease: cubic-bezier(.2,.75,.25,1);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
        }

        html {
            min-height: 100%;
            scroll-behavior: smooth;
        }

        body {
            min-height: 100vh;
            overflow-x: hidden;
            color: var(--white);
            background:
                radial-gradient(ellipse at 15% 15%, rgba(0,180,216,.17), transparent 35%),
                radial-gradient(ellipse at 85% 85%, rgba(56,189,248,.12), transparent 35%),
                linear-gradient(135deg, #071E3D 0%, #0D3B66 52%, #0096C7 100%);
        }

        body::before {
            content: "";
            position: fixed;
            inset: 0;
            z-index: 0;
            pointer-events: none;
            opacity: .13;
            background-image:
                linear-gradient(rgba(255,255,255,.09) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255,255,255,.09) 1px, transparent 1px);
            background-size: 48px 48px;
            mask-image: linear-gradient(to bottom, black, transparent 95%);
        }

        button,
        input {
            font: inherit;
        }

        button,
        a,
        input,
        label {
            -webkit-tap-highlight-color: transparent;
        }

        a {
            color: inherit;
        }

        button:focus-visible,
        a:focus-visible,
        input:focus-visible,
        label:has(input:focus-visible) {
            outline: 2px solid var(--bright-blue);
            outline-offset: 4px;
        }

        .background-glow {
            position: fixed;
            z-index: 0;
            top: 50%;
            left: 50%;
            width: min(650px, 90vw);
            aspect-ratio: 1;
            border-radius: 50%;
            pointer-events: none;
            background: radial-gradient(circle, rgba(0,180,216,.16), transparent 68%);
            transform: translate(-50%, -50%);
            transition: transform .5s var(--ease);
            will-change: transform;
        }

        .ambient-text {
            position: fixed;
            z-index: 0;
            top: 8%;
            left: 50%;
            transform: translateX(-50%);
            white-space: nowrap;
            pointer-events: none;
            user-select: none;
            font-size: clamp(48px, 10vw, 130px);
            font-weight: 800;
            letter-spacing: .12em;
            color: rgba(255,255,255,.025);
        }

        .particles {
            position: fixed;
            inset: 0;
            z-index: 0;
            overflow: hidden;
            pointer-events: none;
        }

        .particle {
            position: absolute;
            width: 4px;
            height: 4px;
            border-radius: 50%;
            background: var(--bright-blue);
            box-shadow: 0 0 12px rgba(0,180,216,.9);
            opacity: .45;
            animation: floatParticle 13s ease-in-out infinite;
        }

        .particle:nth-child(1) { top: 18%; left: 12%; }
        .particle:nth-child(2) { top: 72%; left: 82%; animation-delay: -3s; }
        .particle:nth-child(3) { top: 40%; left: 88%; animation-delay: -6s; }
        .particle:nth-child(4) { top: 82%; left: 20%; animation-delay: -8s; }
        .particle:nth-child(5) { top: 30%; left: 70%; animation-delay: -4s; }
        .particle:nth-child(6) { top: 58%; left: 40%; animation-delay: -9s; }
        .particle:nth-child(7) { top: 12%; left: 76%; animation-delay: -2s; }

        @keyframes floatParticle {
            0%, 100% { transform: translate3d(0,0,0); opacity: .2; }
            50% { transform: translate3d(25px,-65px,0); opacity: .8; }
        }

        .back-home {
            position: fixed;
            z-index: 20;
            top: 25px;
            left: 30px;
            display: inline-flex;
            align-items: center;
            gap: 9px;
            padding: 10px 15px;
            border: 1px solid transparent;
            border-radius: 12px;
            color: var(--text);
            background: rgba(7,30,61,.22);
            text-decoration: none;
            font-size: 13px;
            font-weight: 500;
            backdrop-filter: blur(12px);
            transition: color .25s ease, background .25s ease,
                border-color .25s ease, transform .25s var(--ease);
        }

        .back-home .arrow {
            display: inline-block;
            transition: transform .25s var(--ease);
        }

        .back-home:hover {
            color: var(--bright-blue);
            background: rgba(0,180,216,.08);
            border-color: rgba(0,180,216,.25);
            transform: translateX(-2px);
        }

        .back-home:hover .arrow {
            transform: translateX(-4px);
        }

        .page-container {
            position: relative;
            z-index: 2;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 85px 20px 45px;
        }

        .register-container {
            width: 100%;
            max-width: 540px;
            perspective: 1200px;
        }

        .register-card {
            position: relative;
            overflow: hidden;
            padding: 38px;
            border: 1px solid rgba(255,255,255,.15);
            border-radius: var(--radius);
            background: linear-gradient(145deg, rgba(13,59,102,.88), rgba(7,30,61,.91));
            backdrop-filter: blur(22px);
            -webkit-backdrop-filter: blur(22px);
            box-shadow: 0 30px 80px rgba(0,0,0,.32),
                0 0 40px rgba(0,180,216,.075),
                inset 0 1px 0 rgba(255,255,255,.08);
            animation: cardAppear .8s var(--ease) both;
            transition: border-color .35s ease, box-shadow .35s ease,
                transform .35s var(--ease);
        }

        .register-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: -110%;
            width: 70%;
            height: 1px;
            background: linear-gradient(90deg, transparent, var(--primary), transparent);
            animation: borderSweep 5s ease-in-out infinite;
            pointer-events: none;
        }

        .register-card::after {
            content: "";
            position: absolute;
            top: -120px;
            right: -120px;
            width: 230px;
            height: 230px;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(0,180,216,.1), transparent 70%);
            pointer-events: none;
        }

        @keyframes cardAppear {
            from { opacity: 0; transform: translateY(28px) scale(.975); }
            to { opacity: 1; transform: translateY(0) scale(1); }
        }

        @keyframes borderSweep {
            0%, 15% { left: -110%; }
            65%, 100% { left: 150%; }
        }

        .register-header {
            position: relative;
            z-index: 1;
            text-align: center;
            margin-bottom: 28px;
        }

        .logo-mark {
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 72px;
            height: 72px;
            margin: 0 auto 17px;
            padding: 8px;
            overflow: hidden;
            border: 1px solid rgba(255,255,255,.19);
            border-radius: 20px;
            background: linear-gradient(135deg, rgba(0,180,216,.22), rgba(0,119,182,.18));
            box-shadow: 0 0 28px rgba(0,180,216,.18);
            animation: logoFloat 4s ease-in-out infinite;
            transition: transform .3s var(--ease), box-shadow .3s ease,
                border-color .3s ease;
        }

        .logo-mark:hover {
            transform: translateY(-4px) rotate(-3deg) scale(1.045);
            border-color: rgba(0,180,216,.7);
            box-shadow: 0 0 38px rgba(0,180,216,.35);
        }

        .logo-mark img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            filter: drop-shadow(0 0 8px rgba(0,180,216,.16));
            transition: transform .3s var(--ease), filter .3s ease;
        }

        .logo-mark:hover img {
            transform: scale(1.08);
            filter: drop-shadow(0 0 10px rgba(0,180,216,.4));
        }

        @keyframes logoFloat {
            0%, 100% { translate: 0 0; }
            50% { translate: 0 -4px; }
        }

        .brand-caption {
            margin-bottom: 8px;
            color: var(--bright-blue);
            font-size: 10px;
            font-weight: 600;
            letter-spacing: .22em;
            text-transform: uppercase;
        }

        .register-header h1 {
            margin-bottom: 8px;
            font-size: clamp(24px, 5vw, 29px);
            font-weight: 700;
            letter-spacing: -.7px;
        }

        .register-header h1 span {
            color: var(--primary);
            text-shadow: 0 0 22px rgba(0,180,216,.16);
        }

        .register-header p {
            max-width: 330px;
            margin: 0 auto;
            color: var(--muted);
            font-size: 12px;
            font-weight: 300;
            line-height: 1.8;
        }

        .section-title {
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 23px 0 14px;
            color: var(--text);
            font-size: 11px;
            font-weight: 600;
            letter-spacing: 1.2px;
            text-transform: uppercase;
        }

        .section-title::before {
            content: "";
            width: 4px;
            height: 15px;
            border-radius: 4px;
            background: var(--primary);
            box-shadow: 0 0 12px rgba(0,180,216,.5);
        }

        .section-title::after {
            content: "";
            flex: 1;
            height: 1px;
            background: linear-gradient(90deg, rgba(255,255,255,.13), transparent);
        }

        .form-group {
            margin-bottom: 16px;
        }

        .form-group > label {
            display: block;
            margin-bottom: 7px;
            color: var(--text);
            font-size: 11px;
            font-weight: 500;
        }

        .required {
            color: var(--primary);
        }

        .input-wrapper {
            position: relative;
        }

        .form-control {
            width: 100%;
            height: 47px;
            padding: 0 14px;
            border: 1px solid rgba(255,255,255,.13);
            border-radius: 11px;
            outline: none;
            color: var(--white);
            background: rgba(255,255,255,.045);
            font-size: 12px;
            transition: border-color .25s ease, background .25s ease,
                box-shadow .25s ease, transform .25s var(--ease);
        }

        .form-control::placeholder {
            color: #718096;
        }

        .form-control:hover {
            border-color: rgba(0,180,216,.32);
            background: rgba(255,255,255,.06);
        }

        .form-control:focus {
            border-color: var(--primary);
            background: rgba(0,180,216,.055);
            box-shadow: 0 0 0 3px rgba(0,180,216,.09),
                0 0 22px rgba(0,180,216,.055);
        }

        .form-control.has-icon {
            padding-right: 48px;
        }

        .toggle-password {
            position: absolute;
            top: 50%;
            right: 9px;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 34px;
            height: 34px;
            padding: 7px;
            border: 1px solid transparent;
            border-radius: 9px;
            color: var(--muted);
            background: transparent;
            cursor: pointer;
            transform: translateY(-50%);
            transition: color .25s ease, background .25s ease,
                border-color .25s ease, transform .25s var(--ease);
        }

        .toggle-password svg {
            width: 18px;
            height: 18px;
            transition: transform .25s var(--ease), filter .25s ease;
        }

        .toggle-password:hover {
            color: var(--bright-blue);
            border-color: rgba(0,180,216,.22);
            background: rgba(0,180,216,.09);
        }

        .toggle-password:hover svg {
            transform: scale(1.12);
            filter: drop-shadow(0 0 5px rgba(0,180,216,.5));
        }

        .toggle-password:active {
            transform: translateY(-50%) scale(.94);
        }

        .role-options {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
        }

        .role-option {
            position: relative;
        }

        .role-option input {
            position: absolute;
            width: 1px;
            height: 1px;
            opacity: 0;
        }

        .role-card {
            position: relative;
            display: flex;
            min-height: 105px;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 6px;
            padding: 15px 10px;
            overflow: hidden;
            border: 1px solid rgba(255,255,255,.12);
            border-radius: 14px;
            background: rgba(255,255,255,.035);
            cursor: pointer;
            text-align: center;
            transition: border-color .25s ease, background .25s ease,
                transform .25s var(--ease), box-shadow .25s ease;
        }

        .role-card::before {
            content: "";
            position: absolute;
            inset: 0;
            opacity: 0;
            background: radial-gradient(circle at 50% 0%, rgba(0,180,216,.16), transparent 75%);
            transition: opacity .25s ease;
            pointer-events: none;
        }

        .role-card:hover {
            transform: translateY(-3px);
            border-color: rgba(0,180,216,.5);
            box-shadow: 0 8px 22px rgba(0,0,0,.12);
        }

        .role-card:hover::before {
            opacity: 1;
        }

        .role-option input:checked + .role-card {
            border-color: var(--primary);
            background: rgba(0,180,216,.09);
            box-shadow: inset 0 0 20px rgba(0,180,216,.035),
                0 0 20px rgba(0,180,216,.09);
        }

        .role-option input:checked + .role-card::after {
            content: "✓";
            position: absolute;
            top: 8px;
            right: 9px;
            display: grid;
            place-items: center;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            color: var(--navy);
            background: var(--primary);
            font-size: 11px;
            font-weight: 800;
            animation: checkPop .25s var(--ease);
        }

        .role-option input:focus-visible + .role-card {
            outline: 2px solid var(--bright-blue);
            outline-offset: 4px;
        }

        @keyframes checkPop {
            from { transform: scale(.5); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }

        .role-icon {
            display: inline-block;
            font-size: 26px;
            line-height: 1;
            transition: transform .25s var(--ease), filter .25s ease;
        }

        .role-card:hover .role-icon,
        .role-option input:checked + .role-card .role-icon {
            transform: translateY(-2px) scale(1.1);
            filter: drop-shadow(0 0 8px rgba(0,180,216,.35));
        }

        .role-name {
            color: var(--white);
            font-size: 12px;
            font-weight: 600;
        }

        .role-description {
            color: var(--muted);
            font-size: 9px;
            line-height: 1.5;
        }

        .password-strength {
            margin-top: 9px;
        }

        .strength-bar {
            display: flex;
            gap: 5px;
            margin-bottom: 7px;
        }

        .strength-segment {
            flex: 1;
            height: 4px;
            border-radius: 8px;
            background: rgba(255,255,255,.1);
            transition: background .25s ease, box-shadow .25s ease;
        }

        .strength-text {
            color: var(--muted);
            font-size: 10px;
            transition: color .25s ease;
        }

        .password-match {
            display: none;
            margin-top: 7px;
            font-size: 10px;
            font-weight: 500;
            animation: fadeIn .2s ease;
        }

        .password-match.match {
            display: block;
            color: var(--success-light);
        }

        .password-match.no-match {
            display: block;
            color: #F87171;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-3px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .terms-container {
            display: flex;
            align-items: flex-start;
            gap: 10px;
            margin: 19px 0 21px;
        }

        .terms-container input {
            flex: 0 0 auto;
            width: 16px;
            height: 16px;
            margin-top: 3px;
            accent-color: var(--primary);
            cursor: pointer;
        }

        .terms-container label {
            color: var(--muted);
            font-size: 10px;
            line-height: 1.8;
            cursor: pointer;
        }

        .terms-container a,
        .auth-footer a {
            color: var(--primary);
            text-decoration: none;
            font-weight: 600;
            transition: color .2s ease, text-shadow .2s ease;
        }

        .terms-container a:hover,
        .auth-footer a:hover {
            color: var(--bright-blue);
            text-shadow: 0 0 12px rgba(0,180,216,.3);
        }

        .btn-register {
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            width: 100%;
            min-height: 49px;
            padding: 12px 18px;
            overflow: hidden;
            border: 1px solid rgba(255,255,255,.12);
            border-radius: 11px;
            color: var(--white);
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            box-shadow: 0 9px 24px rgba(0,180,216,.2);
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: transform .25s var(--ease), box-shadow .25s ease,
                filter .25s ease;
        }

        .btn-register::before {
            content: "";
            position: absolute;
            top: -80%;
            left: -45%;
            width: 30%;
            height: 260%;
            transform: rotate(25deg);
            background: rgba(255,255,255,.18);
            transition: left .6s var(--ease);
        }

        .btn-register > span {
            position: relative;
            z-index: 1;
        }

        .btn-register .button-arrow {
            display: inline-block;
            transition: transform .25s var(--ease);
        }

        .btn-register:hover {
            transform: translateY(-3px);
            filter: brightness(1.08);
            box-shadow: 0 14px 34px rgba(0,180,216,.3);
        }

        .btn-register:hover::before {
            left: 125%;
        }

        .btn-register:hover .button-arrow {
            transform: translateX(5px);
        }

        .btn-register:active {
            transform: translateY(0) scale(.99);
        }

        .btn-register:disabled {
            cursor: wait;
            opacity: .8;
            transform: none;
        }

        .auth-footer {
            margin-top: 22px;
            color: var(--muted);
            text-align: center;
            font-size: 11px;
        }

        .auth-footer a {
            margin-left: 3px;
        }

        .security-note {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 7px;
            margin-top: 20px;
            color: rgba(226,232,240,.65);
            font-size: 9px;
            letter-spacing: .2px;
        }

        .security-note svg {
            width: 13px;
            height: 13px;
            color: var(--success-light);
            transition: transform .25s var(--ease), filter .25s ease;
        }

        .security-note:hover svg {
            transform: scale(1.16);
            filter: drop-shadow(0 0 5px rgba(52,211,153,.5));
        }

        .feedback-overlay {
            position: fixed;
            inset: 0;
            z-index: 9999;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            background: rgba(2,6,23,.84);
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            animation: overlayFade .3s ease;
        }

        .feedback-card {
            width: 100%;
            max-width: 390px;
            padding: 34px 28px;
            border: 1px solid rgba(255,255,255,.13);
            border-radius: 21px;
            background: linear-gradient(145deg, rgba(13,59,102,.98), rgba(7,30,61,.98));
            box-shadow: 0 25px 75px rgba(0,0,0,.45);
            text-align: center;
            animation: popupScale .4s var(--ease);
        }

        .feedback-icon {
            display: grid;
            place-items: center;
            width: 78px;
            height: 78px;
            margin: 0 auto 20px;
            border: 2px solid var(--error);
            border-radius: 50%;
            color: var(--error);
            background: rgba(239,68,68,.1);
            box-shadow: 0 0 27px rgba(239,68,68,.15);
            transition: transform .25s var(--ease), box-shadow .25s ease;
        }

        .feedback-icon:hover {
            transform: scale(1.05);
            box-shadow: 0 0 35px rgba(239,68,68,.27);
        }

        .feedback-icon svg {
            width: 35px;
            height: 35px;
            fill: none;
            stroke: currentColor;
            stroke-width: 2;
            stroke-linecap: round;
            stroke-linejoin: round;
        }

        .feedback-card h2 {
            margin-bottom: 9px;
            font-size: 21px;
        }

        .feedback-card p {
            margin-bottom: 22px;
            color: var(--muted);
            font-size: 12px;
            line-height: 1.8;
            overflow-wrap: anywhere;
        }

        .btn-error {
            width: 100%;
            min-height: 44px;
            border: 1px solid rgba(255,255,255,.1);
            border-radius: 10px;
            color: var(--white);
            background: var(--error);
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            transition: transform .2s var(--ease), background .2s ease,
                box-shadow .2s ease;
        }

        .btn-error:hover {
            transform: translateY(-2px);
            background: #DC2626;
            box-shadow: 0 8px 20px rgba(239,68,68,.2);
        }

        .success-card .feedback-icon {
            border-color: var(--success);
            color: var(--success-light);
            background: rgba(16,185,129,.1);
            box-shadow: 0 0 35px rgba(16,185,129,.18);
            animation: successPulse 2s ease-in-out infinite;
        }

        .success-card .feedback-icon svg {
            width: 42px;
            height: 42px;
            stroke-dasharray: 55;
            stroke-dashoffset: 55;
            animation: drawCheck .7s ease .2s forwards;
        }

        .success-card h2 {
            color: var(--success-light);
        }

        .success-progress {
            height: 3px;
            margin-top: 20px;
            overflow: hidden;
            border-radius: 5px;
            background: rgba(255,255,255,.1);
        }

        .success-progress span {
            display: block;
            width: 100%;
            height: 100%;
            transform-origin: left;
            background: linear-gradient(90deg, var(--success), var(--primary));
            animation: progressDrain 3s linear forwards;
        }

        @keyframes overlayFade {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes popupScale {
            from { opacity: 0; transform: translateY(12px) scale(.94); }
            to { opacity: 1; transform: translateY(0) scale(1); }
        }

        @keyframes drawCheck {
            to { stroke-dashoffset: 0; }
        }

        @keyframes successPulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.04); }
        }

        @keyframes progressDrain {
            from { transform: scaleX(1); }
            to { transform: scaleX(0); }
        }

        @media (max-width: 600px) {
            .page-container {
                padding: 82px 14px 30px;
            }

            .register-container {
                max-width: 470px;
            }

            .register-card {
                padding: 29px 21px;
                border-radius: 18px;
            }

            .back-home {
                top: 15px;
                left: 13px;
                padding: 8px 10px;
                font-size: 11px;
            }

            .ambient-text {
                top: 12%;
                font-size: 15vw;
            }

            .logo-mark {
                width: 64px;
                height: 64px;
            }
        }

        @media (max-width: 380px) {
            .register-card {
                padding: 25px 16px;
            }

            .role-options {
                gap: 8px;
            }

            .role-card {
                min-height: 100px;
                padding: 12px 6px;
            }

            .role-description {
                font-size: 8px;
            }

            .register-header h1 {
                font-size: 24px;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                scroll-behavior: auto !important;
                animation-duration: .01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: .01ms !important;
            }

            .background-glow {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="background-glow" id="backgroundGlow" aria-hidden="true"></div>
    <div class="ambient-text" id="ambientText" aria-hidden="true">INTERNPRO</div>

    <div class="particles" aria-hidden="true">
        <span class="particle"></span>
        <span class="particle"></span>
        <span class="particle"></span>
        <span class="particle"></span>
        <span class="particle"></span>
        <span class="particle"></span>
        <span class="particle"></span>
    </div>

    <a href="index.php" class="back-home">
        <span class="arrow" aria-hidden="true">←</span>
        <span>Back to Home</span>
    </a>

    <?php if ($success !== ''): ?>
        <div class="feedback-overlay" role="dialog" aria-modal="true" aria-labelledby="successTitle">
            <div class="feedback-card success-card">
                <div class="feedback-icon" aria-hidden="true">
                    <svg viewBox="0 0 52 52">
                        <path d="M14 27l8 8 16-16"></path>
                    </svg>
                </div>
                <h2 id="successTitle">Account Created!</h2>
                <p>
                    Your InternPro account has been created successfully.
                    <br>
                    Redirecting you to login...
                </p>
                <div class="success-progress" aria-hidden="true">
                    <span></span>
                </div>
            </div>
        </div>

        <script>
            window.setTimeout(function () {
                window.location.href = 'login.php';
            }, 3000);
        </script>
    <?php endif; ?>

    <?php if ($error !== ''): ?>
        <div class="feedback-overlay" id="errorOverlay" role="dialog" aria-modal="true" aria-labelledby="errorTitle">
            <div class="feedback-card">
                <div class="feedback-icon" aria-hidden="true">
                    <svg viewBox="0 0 24 24">
                        <circle cx="12" cy="12" r="10"></circle>
                        <path d="M12 8v4"></path>
                        <path d="M12 16h.01"></path>
                    </svg>
                </div>
                <h2 id="errorTitle">Action Required</h2>
                <p><?= e($error) ?></p>
                <button type="button" class="btn-error" onclick="closeErrorModal()">
                    Try Again
                </button>
            </div>
        </div>
    <?php endif; ?>

    <main class="page-container">
        <div class="register-container">
            <section class="register-card" aria-labelledby="registerTitle">
                <header class="register-header">
                    <div class="logo-mark">
                        <img src="assets/logo.jpg" alt="InternPro logo" width="56" height="56">
                    </div>

                    <div class="brand-caption">Your career starts here</div>

                    <h1 id="registerTitle">
                        Create <span>Account</span>
                    </h1>

                    <p>
                        Build your future, discover opportunities, and start your
                        internship journey with InternPro.
                    </p>
                </header>

                <form id="registerForm" action="register.php" method="POST" novalidate>
                    <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">

                    <div class="section-title">Personal Information</div>

                    <div class="form-group">
                        <label for="full_name">
                            Full Name <span class="required">*</span>
                        </label>
                        <input
                            type="text"
                            id="full_name"
                            name="full_name"
                            class="form-control"
                            placeholder="Enter your full name"
                            value="<?= e($full_name) ?>"
                            autocomplete="name"
                            maxlength="100"
                            required
                        >
                    </div>

                    <div class="form-group">
                        <label for="name">
                            Username <span class="required">*</span>
                        </label>
                        <input
                            type="text"
                            id="name"
                            name="name"
                            class="form-control"
                            placeholder="Choose a username"
                            value="<?= e($name) ?>"
                            autocomplete="username"
                            minlength="3"
                            maxlength="30"
                            pattern="[A-Za-z0-9_]{3,30}"
                            required
                        >
                    </div>

                    <div class="form-group">
                        <label for="email">
                            College Email Address <span class="required">*</span>
                        </label>
                        <input
                            type="email"
                            id="email"
                            name="email"
                            class="form-control"
                            placeholder="Enter your college email"
                            value="<?= e($email) ?>"
                            autocomplete="email"
                            maxlength="254"
                            required
                        >
                    </div>

                    <div class="section-title">Account Type</div>

                    <div class="role-options" role="radiogroup" aria-label="Choose your account type">
                        <div class="role-option">
                            <input
                                type="radio"
                                id="studentRole"
                                name="role"
                                value="student"
                                <?= $role === 'student' ? 'checked' : '' ?>
                            >
                            <label for="studentRole" class="role-card">
                                <span class="role-icon" aria-hidden="true">🎓</span>
                                <span class="role-name">Student</span>
                                <span class="role-description">Find internships &amp; apply</span>
                            </label>
                        </div>

                        <div class="role-option">
                            <input
                                type="radio"
                                id="companyRole"
                                name="role"
                                value="company"
                                <?= $role === 'company' ? 'checked' : '' ?>
                            >
                            <label for="companyRole" class="role-card">
                                <span class="role-icon" aria-hidden="true">🏢</span>
                                <span class="role-name">Recruiter</span>
                                <span class="role-description">Post &amp; manage internships</span>
                            </label>
                        </div>
                    </div>

                    <div class="section-title">Account Security</div>

                    <div class="form-group">
                        <label for="password">
                            Password <span class="required">*</span>
                        </label>

                        <div class="input-wrapper">
                            <input
                                type="password"
                                name="password"
                                id="password"
                                class="form-control has-icon"
                                placeholder="Create a strong password"
                                autocomplete="new-password"
                                minlength="8"
                                required
                            >

                            <button
                                type="button"
                                class="toggle-password"
                                data-target="password"
                                aria-label="Show password"
                                aria-pressed="false"
                            >
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                     stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"
                                     aria-hidden="true">
                                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z"></path>
                                    <circle cx="12" cy="12" r="3"></circle>
                                </svg>
                            </button>
                        </div>

                        <div class="password-strength" aria-live="polite">
                            <div class="strength-bar" aria-hidden="true">
                                <span class="strength-segment"></span>
                                <span class="strength-segment"></span>
                                <span class="strength-segment"></span>
                                <span class="strength-segment"></span>
                            </div>
                            <div class="strength-text" id="strengthText">
                                Use at least 8 characters.
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="confirm_password">
                            Confirm Password <span class="required">*</span>
                        </label>

                        <div class="input-wrapper">
                            <input
                                type="password"
                                name="confirm_password"
                                id="confirm_password"
                                class="form-control has-icon"
                                placeholder="Confirm your password"
                                autocomplete="new-password"
                                required
                            >

                            <button
                                type="button"
                                class="toggle-password"
                                data-target="confirm_password"
                                aria-label="Show confirm password"
                                aria-pressed="false"
                            >
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                     stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"
                                     aria-hidden="true">
                                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z"></path>
                                    <circle cx="12" cy="12" r="3"></circle>
                                </svg>
                            </button>
                        </div>

                        <div class="password-match" id="passwordMatch" aria-live="polite"></div>
                    </div>

                    <div class="terms-container">
                        <input type="checkbox" id="terms" name="terms" required>
                        <label for="terms">
                            I agree to the
                            <a href="#" onclick="return false;">Terms of Service</a>
                            and
                            <a href="#" onclick="return false;">Privacy Policy</a>.
                        </label>
                    </div>

                    <button type="submit" class="btn-register" id="registerButton">
                        <span>Create Account</span>
                        <span class="button-arrow" aria-hidden="true">→</span>
                    </button>
                </form>

                <div class="auth-footer">
                    Already have an account?
                    <a href="login.php">Login here</a>
                </div>

                <div class="security-note">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"
                         stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                         aria-hidden="true">
                        <path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11z"></path>
                        <path d="m9 12 2 2 4-4"></path>
                    </svg>
                    <span>Your password is securely hashed</span>
                </div>
            </section>
        </div>
    </main>

    <script>
        (() => {
            'use strict';

            const reducedMotion = window.matchMedia(
                '(prefers-reduced-motion: reduce)'
            ).matches;

            const form = document.getElementById('registerForm');
            const fullName = document.getElementById('full_name');
            const username = document.getElementById('name');
            const email = document.getElementById('email');
            const password = document.getElementById('password');
            const confirmPassword = document.getElementById('confirm_password');
            const terms = document.getElementById('terms');
            const passwordMatch = document.getElementById('passwordMatch');
            const strengthText = document.getElementById('strengthText');
            const strengthSegments = Array.from(
                document.querySelectorAll('.strength-segment')
            );
            const registerButton = document.getElementById('registerButton');

            const strengthColors = {
                weak: '#EF4444',
                fair: '#F59E0B',
                good: '#38BDF8',
                strong: '#10B981'
            };

            // Password visibility controls.
            document.querySelectorAll('.toggle-password').forEach((button) => {
                button.addEventListener('click', () => {
                    const field = document.getElementById(button.dataset.target);
                    if (!field) return;

                    const showPassword = field.type === 'password';
                    field.type = showPassword ? 'text' : 'password';

                    button.setAttribute(
                        'aria-pressed',
                        showPassword ? 'true' : 'false'
                    );

                    const fieldLabel = field.id === 'password'
                        ? 'password'
                        : 'confirm password';

                    button.setAttribute(
                        'aria-label',
                        `${showPassword ? 'Hide' : 'Show'} ${fieldLabel}`
                    );

                    button.innerHTML = showPassword
                        ? `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"
                               stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"
                               aria-hidden="true">
                               <path d="M3 3l18 18"></path>
                               <path d="M10.6 10.6a2 2 0 0 0 2.8 2.8"></path>
                               <path d="M9.9 5.2A11 11 0 0 1 12 5c7 0 11 7 11 7a18 18 0 0 1-4 4.8"></path>
                               <path d="M6.2 6.2C2.9 8.2 1 12 1 12s4 7 11 7c1.3 0 2.5-.3 3.6-.7"></path>
                           </svg>`
                        : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"
                               stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"
                               aria-hidden="true">
                               <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z"></path>
                               <circle cx="12" cy="12" r="3"></circle>
                           </svg>`;
                });
            });

            // Password strength indicator.
            function updatePasswordStrength() {
                const value = password.value;
                let score = 0;

                if (value.length >= 8) score++;
                if (/[A-Z]/.test(value)) score++;
                if (/[a-z]/.test(value)) score++;
                if (/[0-9]/.test(value)) score++;
                if (/[^A-Za-z0-9]/.test(value)) score++;

                strengthSegments.forEach((segment) => {
                    segment.style.background = 'rgba(255,255,255,.1)';
                    segment.style.boxShadow = 'none';
                });

                if (value.length === 0) {
                    strengthText.textContent = 'Use at least 8 characters.';
                    strengthText.style.color = '#94A3B8';
                    checkPasswordMatch();
                    return;
                }

                let activeCount;
                let label;
                let color;

                if (score <= 2) {
                    activeCount = 1;
                    label = 'Weak password';
                    color = strengthColors.weak;
                } else if (score === 3) {
                    activeCount = 2;
                    label = 'Fair password';
                    color = strengthColors.fair;
                } else if (score === 4) {
                    activeCount = 3;
                    label = 'Good password';
                    color = strengthColors.good;
                } else {
                    activeCount = 4;
                    label = 'Strong password';
                    color = strengthColors.strong;
                }

                strengthSegments.slice(0, activeCount).forEach((segment) => {
                    segment.style.background = color;

                    if (!reducedMotion) {
                        segment.style.boxShadow = `0 0 8px ${color}66`;
                    }
                });

                strengthText.textContent = label;
                strengthText.style.color = color;

                checkPasswordMatch();
            }

            // Live confirmation feedback.
            function checkPasswordMatch() {
                const confirmation = confirmPassword.value;

                if (confirmation === '') {
                    passwordMatch.textContent = '';
                    passwordMatch.className = 'password-match';
                    return;
                }

                if (password.value === confirmation) {
                    passwordMatch.textContent = '✓ Passwords match';
                    passwordMatch.className = 'password-match match';
                } else {
                    passwordMatch.textContent = '✕ Passwords do not match';
                    passwordMatch.className = 'password-match no-match';
                }
            }

            password.addEventListener('input', updatePasswordStrength);
            confirmPassword.addEventListener('input', checkPasswordMatch);

            window.closeErrorModal = function () {
                const overlay = document.getElementById('errorOverlay');
                if (!overlay) return;

                overlay.style.opacity = '0';
                overlay.style.transition = 'opacity .2s ease';

                window.setTimeout(() => overlay.remove(), 210);
            };

            function showError(message, field) {
                let overlay = document.getElementById('errorOverlay');

                if (!overlay) {
                    overlay = document.createElement('div');
                    overlay.id = 'errorOverlay';
                    overlay.className = 'feedback-overlay';
                    overlay.setAttribute('role', 'dialog');
                    overlay.setAttribute('aria-modal', 'true');
                    overlay.setAttribute('aria-labelledby', 'dynamicErrorTitle');

                    const card = document.createElement('div');
                    card.className = 'feedback-card';

                    const icon = document.createElement('div');
                    icon.className = 'feedback-icon';
                    icon.setAttribute('aria-hidden', 'true');
                    icon.innerHTML = `<svg viewBox="0 0 24 24">
                        <circle cx="12" cy="12" r="10"></circle>
                        <path d="M12 8v4"></path>
                        <path d="M12 16h.01"></path>
                    </svg>`;

                    const heading = document.createElement('h2');
                    heading.id = 'dynamicErrorTitle';
                    heading.textContent = 'Action Required';

                    const messageElement = document.createElement('p');
                    messageElement.id = 'dynamicErrorMessage';

                    const button = document.createElement('button');
                    button.type = 'button';
                    button.className = 'btn-error';
                    button.textContent = 'Try Again';
                    button.addEventListener('click', window.closeErrorModal);

                    card.append(icon, heading, messageElement, button);
                    overlay.appendChild(card);
                    document.body.appendChild(overlay);
                }

                const messageElement = overlay.querySelector(
                    '#dynamicErrorMessage'
                );

                if (messageElement) {
                    messageElement.textContent = message;
                }

                const tryAgain = overlay.querySelector('.btn-error');
                if (tryAgain) {
                    tryAgain.focus();
                }

                if (field) {
                    field.focus({ preventScroll: true });
                }
            }

            // Client-side validation mirrors the server-side rules.
            form.addEventListener('submit', (event) => {
                const fullNameValue = fullName.value.trim();
                const usernameValue = username.value.trim();
                const emailValue = email.value.trim();
                const passwordValue = password.value;
                const confirmationValue = confirmPassword.value;

                let message = '';
                let focusTarget = null;

                if (
                    !fullNameValue ||
                    !usernameValue ||
                    !emailValue ||
                    !passwordValue ||
                    !confirmationValue
                ) {
                    message = 'Please fill in all required fields.';
                    focusTarget = [
                        fullName,
                        username,
                        email,
                        password,
                        confirmPassword
                    ].find((field) => !field.value.trim());
                } else if (fullNameValue.length > 100) {
                    message = 'Full name must not exceed 100 characters.';
                    focusTarget = fullName;
                } else if (!/^[A-Za-z0-9_]{3,30}$/.test(usernameValue)) {
                    message = 'Username must be 3–30 characters and contain only letters, numbers, or underscores.';
                    focusTarget = username;
                } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailValue)) {
                    message = 'Please enter a valid email address.';
                    focusTarget = email;
                } else if (passwordValue.length < 8) {
                    message = 'Password must contain at least 8 characters.';
                    focusTarget = password;
                } else if (passwordValue !== confirmationValue) {
                    message = 'Passwords do not match.';
                    focusTarget = confirmPassword;
                } else if (!terms.checked) {
                    message = 'Please agree to the Terms of Service and Privacy Policy.';
                    focusTarget = terms;
                }

                if (message !== '') {
                    event.preventDefault();
                    showError(message, focusTarget);
                    return;
                }

                // Avoid accidental double-click submissions.
                registerButton.disabled = true;
                registerButton.querySelector('span').textContent = 'Creating Account...';
            });

            // Gentle mouse-responsive background, disabled for touch/reduced motion.
            const isTouchDevice =
                ('ontouchstart' in window) ||
                navigator.maxTouchPoints > 0;

            if (!reducedMotion && !isTouchDevice) {
                const glow = document.getElementById('backgroundGlow');
                const ambient = document.getElementById('ambientText');

                document.addEventListener('mousemove', (event) => {
                    const x = event.clientX / window.innerWidth - 0.5;
                    const y = event.clientY / window.innerHeight - 0.5;

                    glow.style.transform =
                        `translate(calc(-50% + ${x * 28}px), calc(-50% + ${y * 28}px))`;

                    ambient.style.transform =
                        `translateX(calc(-50% + ${x * 12}px)) translateY(${y * 12}px)`;
                });
            }

            document.addEventListener('keydown', (event) => {
                if (event.key === 'Escape') {
                    window.closeErrorModal();
                }
            });
        })();
    </script>
</body>
</html>