<?php
$host = 'db01.dbhost.dev';
$dbname = 'db_456394cqe';
$username = 'user_456394cqe';
$password = 'p456394cqe';

try {
    $pdo = new PDO("mysql:host=$host;port=5051;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database Connection Failed: " . $e->getMessage());
}

// Automatically start session if one isn't already active
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>